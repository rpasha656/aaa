export const MAIN = {
    APP: {
        BRAND: 'Schwab'
    }
};
