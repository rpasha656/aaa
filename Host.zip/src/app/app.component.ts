import { Component } from '@angular/core';
import { PubSubServiceContract } from 'microui-contracts';
import { CONSTANTS } from './shared';
import './app.html';

@Component({
    selector: 'as-main-app',
    template: require('./app.html')
})
export class AppComponent {
    public appBrand: string;

    constructor(pubsub: PubSubServiceContract) {
        this.appBrand = CONSTANTS.MAIN.APP.BRAND;
        pubsub.subscribe('Todo', (val) => {
            console.log('TODO', val);
        });
    }
}
