﻿namespace Word
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Xml;

    using Word.Core;

    public class WordOpenXmlReader : IWordReader
    {
        private XmlReader _xmlReader;

        private bool disposed;

        private ZipWorker _zipWorker;

        private IList<Exception> _exceptionMessages;

        private string _documentLocation;

        private bool _isValid;

        private const string ContentTypeNamespace = @"http://schemas.openxmlformats.org/package/2006/content-types";

        private const string WordprocessingMlNamespace = @"http://schemas.openxmlformats.org/wordprocessingml/2006/main";

        private const string DocumentXmlXPath =
            "/t:Types/t:Override[@ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"]";

        private const string BodyXPath = "/w:document/w:body";

        #region Properties

        public bool IsValid
        {
            get
            {
                return this._isValid;
            }
        }

        public IList<Exception> Exceptions
        {
            get
            {
                return this._exceptionMessages;
            }
        }

        #endregion

        public void Initialize(Stream fileStream)
        {
            this._zipWorker = new ZipWorker().Load(fileStream);
            if (!this._zipWorker.IsValid)
            {
                this._isValid = false;
                this._exceptionMessages = this._zipWorker.Exceptions;

                this.Close();
                return;
            }

            this.ReadGlobals();
        }

        private void ReadGlobals()
        {
            this._documentLocation = this.ReadContentTypeFileForDocumentLocation(this._zipWorker.GetContentTypeStream());

            if (string.IsNullOrWhiteSpace(this._documentLocation))
            {
                throw new Exception("File is not a valid Word Open Xml file (.docx).");
            }
        }

        private string ReadContentTypeFileForDocumentLocation(Stream xmlFileStream)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.PreserveWhitespace = true;
            xmlDoc.Load(xmlFileStream);
            xmlFileStream.Close();

            var nsmgr = new XmlNamespaceManager(xmlDoc.NameTable);
            nsmgr.AddNamespace("t", ContentTypeNamespace);

            var node = xmlDoc.DocumentElement.SelectSingleNode(DocumentXmlXPath, nsmgr);
            if (node != null)
            {
                string location = ((XmlElement)node).GetAttribute("PartName");
                return location.TrimStart(new[] { '/' });
            }

            return null;
        }

        private void Close()
        {
            if (this._xmlReader != null)
            {
                this._xmlReader.Close();
            }

            if (this._zipWorker != null)
            {
                this._zipWorker.Dispose();
            }
        }

        public string AsString()
        {
            return this.ReadDocumentXml();
        }

        private string ReadDocumentXml()
        {
            var sb = new StringBuilder();
            var xmlFileStream = this._zipWorker.GetFileStream(this._documentLocation);

            var xmlDoc = new XmlDocument();
            xmlDoc.PreserveWhitespace = true;
            xmlDoc.Load(xmlFileStream);
            xmlFileStream.Close();

            var nsmgr = new XmlNamespaceManager(xmlDoc.NameTable);
            nsmgr.AddNamespace("w", WordprocessingMlNamespace);

            var node = xmlDoc.DocumentElement.SelectSingleNode(BodyXPath, nsmgr);

            if (node == null)
            {
                return string.Empty;
            }

            sb.Append(this.ReadNode(node));
            return sb.ToString();
        }

        /// 
        /// Reads content of the node and its nested childs.
        /// 
        /// XmlNode.
        /// Text containing in the node.
        private string ReadNode(XmlNode node)
        {
            if ((node == null) || (node.NodeType != XmlNodeType.Element))
            {
                return string.Empty;
            }

            var sb = new StringBuilder();
            foreach (XmlNode child in node.ChildNodes)
            {
                if (child.NodeType != XmlNodeType.Element)
                {
                    continue;
                }

                switch (child.LocalName)
                {
                    case "t": // Text
                        sb.Append(child.InnerText.TrimEnd());

                        string space = ((XmlElement)child).GetAttribute("xml:space");
                        if (!string.IsNullOrEmpty(space) && (space == "preserve"))
                        {
                            sb.Append(' ');
                        }

                        break;

                    case "cr": // Carriage return
                    case "br": // Page break
                        sb.Append(Environment.NewLine);
                        break;

                    case "tab": // Tab
                        sb.Append("\t");
                        break;

                    case "p": // Paragraph
                        sb.Append(this.ReadNode(child));
                        sb.Append(Environment.NewLine);
                        sb.Append(Environment.NewLine);
                        break;

                    default:
                        sb.Append(this.ReadNode(child));
                        break;
                }
            }

            return sb.ToString();
        }

        #region IDisposable Members

        public void Dispose()
        {
            this.Dispose(true);

            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (!this.disposed)
            {
                if (disposing)
                {
                    if (this._xmlReader != null)
                    {
                        ((IDisposable)this._xmlReader).Dispose();
                    }

                    // if (_zipWorker != null) _zipWorker.Dispose();
                }

                // _zipWorker = null;
                this._xmlReader = null;
                this.disposed = true;
            }
        }

        ~WordOpenXmlReader()
        {
            this.Dispose(false);
        }

        #endregion
    }
}