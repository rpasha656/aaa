﻿namespace Word
{
    using System.IO;

    public static class WordReaderFactory
    {
        public static IWordReader CreateBinaryReader(string filePath)
        {
            var stream = new FileStream(filePath, FileMode.Open, FileAccess.ReadWrite);
            return CreateBinaryReader(stream);
        }

        public static IWordReader CreateBinaryReader(Stream fileStream)
        {
            IWordReader reader = new WordBinaryReader();
            reader.Initialize(fileStream);
            return reader;
        }

        public static IWordReader CreateOpenXmlReader(string filePath)
        {
            var stream = new FileStream(filePath, FileMode.Open, FileAccess.ReadWrite);
            return CreateOpenXmlReader(stream);
        }

        public static IWordReader CreateOpenXmlReader(Stream fileStream)
        {
            IWordReader reader = new WordOpenXmlReader();
            reader.Initialize(fileStream);
            return reader;
        }
    }
}