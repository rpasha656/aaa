﻿namespace Word.Core.BinaryFormat
{
    using System.IO;

    internal class FileOffset
    {
        public static readonly int Size;

        private static readonly uint UnicodeMask;

        private uint _value;

        public uint Value
        {
            get
            {
                return this._value;
            }

            set
            {
                this._value = value;
            }
        }

        static FileOffset()
        {
            Size = 4;
            UnicodeMask = 1073741824U;
        }

        public FileOffset()
            : this(0U)
        {
        }

        public FileOffset(uint value)
        {
            this._value = value;
        }

        public void Read(BinaryReader reader)
        {
            this._value = reader.ReadUInt32();
        }

        public void Write(BinaryWriter writer)
        {
            writer.Write(this._value);
        }

        public static bool IsUnicode(uint fc)
        {
            return ((int)fc & (int)UnicodeMask) == 0;
        }

        public static uint NormalizeFc(uint fc)
        {
            if (((int)fc & (int)UnicodeMask) == 0)
            {
                return fc;
            }

            return (fc & ~UnicodeMask) / 2U;
        }

        public static uint GetFcDelta(bool isUnicode)
        {
            return isUnicode ? 2U : 1U;
        }
    }
}