﻿namespace Word.Core.BinaryFormat
{
    using System.Collections;
    using System.IO;

    public class PieceDescriptorCollection
    {
        private int _offset;

        private uint _length;

        private PieceDescriptor[] _descriptors;

        private FileOffsetCollection _descriptorOffsets;

        public int Count
        {
            get
            {
                return this._descriptors.Length;
            }
        }

        public PieceDescriptorCollection(int offset, uint length)
        {
            this._offset = offset;
            this._length = length;
        }

        private int GetOffsetsCount(int size, int structureSize)
        {
            return this.GetDescriptorsCount(size, structureSize) + 1;
        }

        private int GetDescriptorsCount(int size, int structureSize)
        {
            const int num = 4;
            return (size - num) / (structureSize + num);
        }

        private PieceDescriptor[] ReadDescriptors(BinaryReader reader, int count)
        {
            var arrayList = new ArrayList();
            for (var index = 0; index < count; ++index)
            {
                var pieceDescriptor = new PieceDescriptor();
                pieceDescriptor.Read(reader);
                arrayList.Add((object)pieceDescriptor);
            }

            return (PieceDescriptor[])arrayList.ToArray(typeof(PieceDescriptor));
        }

        public void Read(BinaryReader reader)
        {
            reader.BaseStream.Seek((long)this._offset, SeekOrigin.Begin);
            while (reader.BaseStream.Position < (long)this._offset + (long)this._length)
            {
                switch (reader.ReadByte())
                {
                    case (byte)0:
                        var num1 = (int)reader.ReadByte();
                        break;
                    case (byte)1:
                        var num2 = reader.ReadInt16();
                        reader.ReadBytes((int)num2);
                        break;
                    case (byte)2:
                        var size = reader.ReadInt32();
                        this._descriptorOffsets = new FileOffsetCollection();
                        this._descriptorOffsets.Read(reader, this.GetOffsetsCount(size, PieceDescriptor.Size));
                        this._descriptors = this.ReadDescriptors(reader, this.GetDescriptorsCount(size, PieceDescriptor.Size));
                        break;
                }
            }
        }

        public bool GetPieceFileBounds(int piece, out uint start, out uint end)
        {
            start = uint.MaxValue;
            end = uint.MaxValue;
            var fc = this._descriptors[piece].Fc;
            var isUnicode = FileOffset.IsUnicode(fc);
            start = FileOffset.NormalizeFc(fc);
            var num = this._descriptorOffsets[piece + 1].Value - this._descriptorOffsets[piece].Value;
            end = start + (num * FileOffset.GetFcDelta(isUnicode));
            return isUnicode;
        }
    }
}