﻿namespace Word.Core.BinaryFormat
{
    using System.IO;
    using System.Text;

    using OpenMcdf;

    internal class McdfReader
    {
        private Stream _fileStream;

        private static readonly Encoding Encoder;

        static McdfReader()
        {
            Encoder = (Encoding)new UnicodeEncoding();
        }

        public McdfReader(Stream stream)
        {
            this._fileStream = stream;
        }

        public BinaryReader GetReader(CFStream stream)
        {
            if (stream == null)
            {
                return null as BinaryReader;
            }

            return new BinaryReader((Stream)new MemoryStream(stream.GetData()));
        }

        private BinaryReader GetStreamReader(CFStorage storage, string streamName)
        {
            var stream = storage.GetStream(streamName);
            if (stream == null)
            {
                return null as BinaryReader;
            }

            return this.GetReader(stream);
        }

        private BinaryReader GetDocumentStreamReader(CFStorage storage)
        {
            return this.GetStreamReader(storage, "WordDocument");
        }

        private BinaryReader GetTableStreamReader(CFStorage storage, string tableName)
        {
            return this.GetStreamReader(storage, tableName);
        }

        private void GetDataFromFib(BinaryReader reader, out string tableName, out int pdcOffset, out uint pdcLength)
        {
            reader.BaseStream.Seek(10L, SeekOrigin.Begin);
            ushort target = reader.ReadUInt16();
            tableName = BitUtils.IsSet(target, (byte)9) ? "1Table" : "0Table";
            reader.BaseStream.Seek(418L, SeekOrigin.Begin);
            pdcOffset = reader.ReadInt32();
            pdcLength = reader.ReadUInt32();
        }

        private PieceDescriptorCollection GetPieceDescriptors(BinaryReader reader, int offset, uint length)
        {
            var descriptorCollection = new PieceDescriptorCollection(offset, length);
            descriptorCollection.Read(reader);
            return descriptorCollection;
        }

        private string ReadString(BinaryReader reader, uint length, bool isUnicode)
        {
            if ((int)length == 0)
            {
                return string.Empty;
            }

            if (isUnicode)
            {
                length /= 2U;
            }

            var stringBuilder = new StringBuilder((int)length);
            try
            {
                if (isUnicode)
                {
                    var bytes = reader.ReadBytes((int)length);
                    stringBuilder.Append(Encoder.GetString(bytes));
                }
                else
                {
                    for (var index = 0; (long)index < (long)length; ++index)
                    {
                        var iValue = reader.ReadByte();
                        stringBuilder.Append(CharFromByte(iValue));
                    }
                }

                return ((object)stringBuilder).ToString();
            }
            finally
            {
                stringBuilder.Length = 0;
            }
        }

        private static char CharFromByte(byte iValue)
        {
            switch (iValue)
            {
                case (byte)58:
                    return ':';
                case 0x80:
                    return '€';
                case (byte)130:
                    return '‚';
                case (byte)131:
                    return 'ƒ';
                case (byte)132:
                    return '„';
                case (byte)133:
                    return '…';
                case (byte)134:
                    return '†';
                case (byte)135:
                    return '‡';
                case (byte)136:
                    return '\x02C6';
                case (byte)137:
                    return '‰';
                case (byte)138:
                    return 'Š';
                case (byte)139:
                    return '‹';
                case (byte)140:
                    return 'Œ';
                case (byte)142:
                    return 'Ž';
                case (byte)145:
                    return '‘';
                case (byte)146:
                    return '’';
                case (byte)147:
                    return '“';
                case (byte)148:
                    return '”';
                case (byte)149:
                    return '•';
                case (byte)150:
                    return '–';
                case (byte)151:
                    return '—';
                case (byte)152:
                    return '˜';
                case (byte)153:
                    return '™';
                case (byte)154:
                    return 'š';
                case (byte)155:
                    return '›';
                case (byte)156:
                    return 'œ';
                case (byte)158:
                    return 'ž';
                case (byte)159:
                    return 'Ÿ';
                default:
                    return (char)iValue;
            }
        }

        private bool LoadText(CFStorage storage, out string text)
        {
            text = string.Empty;
            if (storage == null)
            {
                return false;
            }

            var documentStreamReader = this.GetDocumentStreamReader(storage);
            if (documentStreamReader == null)
            {
                return false;
            }

            string tableName;
            int pdcOffset;
            uint pdcLength;
            this.GetDataFromFib(documentStreamReader, out tableName, out pdcOffset, out pdcLength);
            var tableStreamReader = this.GetTableStreamReader(storage, tableName);
            if (tableStreamReader == null)
            {
                return false;
            }

            var pieceDescriptors = this.GetPieceDescriptors(tableStreamReader, pdcOffset, pdcLength);
            if (pieceDescriptors == null)
            {
                return false;
            }

            var count = pieceDescriptors.Count;
            var local = @text;
            for (var piece = 0; piece < count; ++piece)
            {
                uint start;
                uint end;
                bool pieceFileBounds = pieceDescriptors.GetPieceFileBounds(piece, out start, out end);
                documentStreamReader.BaseStream.Seek((long)start, SeekOrigin.Begin);
                local += this.ReadString(documentStreamReader, end - start, pieceFileBounds);
            }

            if (text != local)
            {
                text = local;
            }

            return true;
        }

        private bool LoadText(out string text)
        {
            text = string.Empty;

            if (this._fileStream == null)
            {
                return false;
            }

            var cfFile = new CompoundFile(this._fileStream);

            if (cfFile.RootStorage == null)
            {
                return false;
            }

            try
            {
                return this.LoadText(cfFile.RootStorage, out text);
            }
            finally
            {
                cfFile.Close();
            }
        }

        public string ExtractText()
        {
            string text;
            return this.LoadText(out text) ? text : string.Empty;
        }
    }
}