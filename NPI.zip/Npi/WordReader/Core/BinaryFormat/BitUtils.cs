﻿namespace Word.Core.BinaryFormat
{
    public class BitUtils
    {
        public static bool IsSet(ushort target, byte bit)
        {
            return ((int)target & (1 << (int)bit)) > 0;
        }
    }
}