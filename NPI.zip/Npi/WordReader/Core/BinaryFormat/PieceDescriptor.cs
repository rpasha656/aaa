﻿namespace Word.Core.BinaryFormat
{
    using System.IO;

    internal class PieceDescriptor
    {
        private const int strSize = 8;

        private byte _Flags;

        private byte _Fn;

        public static int Size
        {
            get
            {
                return 8;
            }
        }

        public uint Fc { get; set; }

        public short Prm { get; set; }

        public void Read(BinaryReader reader)
        {
            this._Flags = reader.ReadByte();
            this._Fn = reader.ReadByte();
            this.Fc = reader.ReadUInt32();
            this.Prm = reader.ReadInt16();
        }

        public void Write(BinaryWriter writer)
        {
            writer.Write(this._Flags);
            writer.Write(this._Fn);
            writer.Write(this.Fc);
            writer.Write(this.Prm);
        }
    }
}