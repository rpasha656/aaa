﻿namespace Word.Core.BinaryFormat
{
    using System.Collections;
    using System.IO;

    internal class FileOffsetCollection : CollectionBase
    {
        public FileOffset this[int index]
        {
            get
            {
                return (FileOffset)this.InnerList[index];
            }

            set
            {
                this.InnerList[index] = (object)value;
            }
        }

        public int Add(FileOffset offset)
        {
            return this.InnerList.Add((object)offset);
        }

        public int Add(uint offset)
        {
            return this.Add(new FileOffset(offset));
        }

        public void AddRange(FileOffsetCollection offsets)
        {
            this.InnerList.AddRange((ICollection)offsets);
        }

        public void Remove(FileOffset offset)
        {
            this.InnerList.Remove((object)offset);
        }

        public void Read(BinaryReader reader, int count)
        {
            if (reader == null)
            {
                return;
            }

            this.Clear();
            for (var index = 0; index < count; ++index)
            {
                var offset = new FileOffset();
                offset.Read(reader);
                this.Add(offset);
            }
        }

        public void Write(BinaryWriter writer)
        {
            if (writer == null)
            {
                return;
            }

            var count = this.Count;
            for (var index = 0; index < count; ++index)
            {
                this[index].Write(writer);
            }
        }
    }
}