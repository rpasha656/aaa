﻿namespace Word.Core
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    using Ionic.Zip;

    public class ZipWorker : IDisposable
    {
        private Stream _fileStream;

        private ZipFile _zipFile;

        private bool _isValid;

        private readonly IList<Exception> _exceptions = new List<Exception>();

        private bool disposed;

        private const string Folder_word = "word";

        private const string File_Document = "document.{0}";

        private const string File_ContentType = "[Content_Types].{0}";

        private string _format = "xml";

        #region Properties

        public bool IsValid
        {
            get
            {
                return this._isValid;
            }
        }

        public IList<Exception> Exceptions
        {
            get
            {
                return this._exceptions;
            }
        }

        public bool IsDisposed
        {
            get
            {
                return this.disposed;
            }
        }

        #endregion

        public ZipWorker Load(string filePath)
        {
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException("File didn't exist.", filePath);
            }

            return this.Load(new FileStream(filePath, FileMode.Open, FileAccess.Read));
        }

        public ZipWorker Load(Stream fileStream)
        {
            if (fileStream == null)
            {
                throw new FileLoadException("Stream must be load with the file.");
            }

            this._fileStream = fileStream;
            this._isValid = true;

            try
            {
                this._zipFile = ZipFile.Read(fileStream);
            }
            catch (Exception ex)
            {
                this._isValid = false;
                this._exceptions.Add(ex);
            }

            return this;
        }

        public Stream GetContentTypeStream()
        {
            return this.GetStream(string.Format(File_ContentType, this._format));
        }

        /// <summary>
        /// This will return the stream of the file in the zip file.
        /// </summary>
        /// <param name="filePath">must be the path of a file in the zip.</param>
        /// <returns></returns>
        public Stream GetFileStream(string filePath)
        {
            return this.GetStream(filePath);
        }

        private Stream GetStream(string filePath)
        {
            if (this._zipFile == null)
            {
                throw new ZipException(
                          "No zip file was loaded. Please make sure to use the Load function before attempting to get an object from the file.");
            }

            var entry = this._zipFile[filePath];
            if (entry == null)
            {
                return null;
            }

            var stream = new MemoryStream();
            entry.Extract(stream);
            if (stream.CanSeek)
            {
                stream.Seek(0, SeekOrigin.Begin);
            }

            return stream;
        }

        #region IDisposable Members

        public void Dispose()
        {
            this.Dispose(true);

            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (!this.disposed)
            {
                if (this._zipFile != null)
                {
                    this._zipFile.Dispose();
                }

                if (this._fileStream != null)
                {
                    this._fileStream.Close();
                    this._fileStream.Dispose();
                }

                this._zipFile = null;
                this._fileStream = null;

                this.disposed = true;
            }
        }

        ~ZipWorker()
        {
            this.Dispose(false);
        }

        #endregion
    }
}