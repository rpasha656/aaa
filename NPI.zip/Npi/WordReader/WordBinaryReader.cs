﻿namespace Word
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    using Word.Core.BinaryFormat;

    public class WordBinaryReader : IWordReader
    {
        private bool disposed;

        private McdfReader reader;

        public void Initialize(Stream fileStream)
        {
            this.reader = new McdfReader(fileStream);
        }

        public bool IsValid { get; private set; }

        public IList<Exception> Exceptions { get; private set; }

        public string AsString()
        {
            try
            {
                this.IsValid = true;
                return this.reader.ExtractText();
            }
            catch (Exception ex)
            {
                this.Exceptions = new List<Exception> { ex };
                this.IsValid = false;
            }

            return string.Empty;
        }

        #region IDisposable Members

        public void Dispose()
        {
            this.Dispose(true);

            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (!this.disposed)
            {
                if (disposing)
                {
                    this.reader = null;
                }

                this.disposed = true;
            }
        }

        ~WordBinaryReader()
        {
            this.Dispose(false);
        }

        #endregion
    }
}