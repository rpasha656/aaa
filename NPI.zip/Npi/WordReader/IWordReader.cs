﻿namespace Word
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    public interface IWordReader : IDisposable
    {
        /// <summary>
        /// Initializes the instance with specified file stream.
        /// </summary>
        /// <param name="fileStream">The file stream.</param>
        void Initialize(Stream fileStream);

        /// <summary>
        /// Gets a value indicating whether file stream is valid.
        /// </summary>
        /// <value><c>true</c> if file stream is valid; otherwise, <c>false</c>.</value>
        bool IsValid { get; }

        /// <summary>
        /// Gets the exception message in case of error.
        /// </summary>
        /// <value>The exception message.</value>
        IList<Exception> Exceptions { get; }

        /// <summary>
        /// Reads all the text out of the file stream and returns it.
        /// </summary>
        /// <returns></returns>
        string AsString();
    }
}