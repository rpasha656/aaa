namespace Excel.Core.OpenXmlFormat
{
    using System.Collections.Generic;

    internal class XlsxStyles
    {
        public XlsxStyles()
        {
            this._cellXfs = new List<XlsxXf>();
            this._NumFmts = new List<XlsxNumFmt>();
        }

        private List<XlsxXf> _cellXfs;

        public List<XlsxXf> CellXfs
        {
            get
            {
                return this._cellXfs;
            }

            set
            {
                this._cellXfs = value;
            }
        }

        private List<XlsxNumFmt> _NumFmts;

        public List<XlsxNumFmt> NumFmts
        {
            get
            {
                return this._NumFmts;
            }

            set
            {
                this._NumFmts = value;
            }
        }
    }
}