namespace Excel.Core.OpenXmlFormat
{
    using System.Collections.Generic;

    /// <summary>
    /// Shared string table
    /// </summary>
    internal class XlsxSST : List<string>
    {
    }
}