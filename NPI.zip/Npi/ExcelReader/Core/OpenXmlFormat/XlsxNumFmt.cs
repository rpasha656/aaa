namespace Excel.Core.OpenXmlFormat
{
    internal class XlsxNumFmt
    {
        public const string N_numFmt = "numFmt";

        public const string A_numFmtId = "numFmtId";

        public const string A_formatCode = "formatCode";

        private int _Id;

        public int Id
        {
            get
            {
                return this._Id;
            }

            set
            {
                this._Id = value;
            }
        }

        private string _FormatCode;

        public string FormatCode
        {
            get
            {
                return this._FormatCode;
            }

            set
            {
                this._FormatCode = value;
            }
        }

        public XlsxNumFmt(int id, string formatCode)
        {
            this._Id = id;
            this._FormatCode = formatCode;
        }
    }
}