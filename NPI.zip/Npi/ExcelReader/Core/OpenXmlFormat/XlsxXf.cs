namespace Excel.Core.OpenXmlFormat
{
    internal class XlsxXf
    {
        public const string N_xf = "xf";

        public const string A_numFmtId = "numFmtId";

        public const string A_xfId = "xfId";

        public const string A_applyNumberFormat = "applyNumberFormat";

        private int _Id;

        public int Id
        {
            get
            {
                return this._Id;
            }

            set
            {
                this._Id = value;
            }
        }

        private int _numFmtId;

        public int NumFmtId
        {
            get
            {
                return this._numFmtId;
            }

            set
            {
                this._numFmtId = value;
            }
        }

        private bool _applyNumberFormat;

        public bool ApplyNumberFormat
        {
            get
            {
                return this._applyNumberFormat;
            }

            set
            {
                this._applyNumberFormat = value;
            }
        }

        public XlsxXf(int id, int numFmtId, string applyNumberFormat)
        {
            this._Id = id;
            this._numFmtId = numFmtId;
            this._applyNumberFormat = (null != applyNumberFormat) && (applyNumberFormat == "1");
        }
    }
}