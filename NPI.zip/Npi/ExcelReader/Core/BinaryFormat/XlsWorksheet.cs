namespace Excel.Core.BinaryFormat
{
    /// <summary>
    /// Represents Worksheet section in workbook
    /// </summary>
    internal class XlsWorksheet
    {
        private readonly uint m_dataOffset;

        private readonly int m_Index;

        private readonly string m_Name = string.Empty;

        private XlsBiffSimpleValueRecord m_CalcCount;

        private XlsBiffSimpleValueRecord m_CalcMode;

        private XlsBiffRecord m_Delta;

        private XlsBiffDimensions m_Dimensions;

        private XlsBiffSimpleValueRecord m_Iteration;

        private XlsBiffSimpleValueRecord m_RefMode;

        private XlsBiffRecord m_Window;

        public XlsWorksheet(int index, XlsBiffBoundSheet refSheet)
        {
            this.m_Index = index;
            this.m_Name = refSheet.SheetName;
            this.m_dataOffset = refSheet.StartOffset;
        }

        /// <summary>
        /// Name of worksheet
        /// </summary>
        public string Name
        {
            get
            {
                return this.m_Name;
            }
        }

        /// <summary>
        /// Zero-based index of worksheet
        /// </summary>
        public int Index
        {
            get
            {
                return this.m_Index;
            }
        }

        /// <summary>
        /// Offset of worksheet data
        /// </summary>
        public uint DataOffset
        {
            get
            {
                return this.m_dataOffset;
            }
        }

        public XlsBiffSimpleValueRecord CalcMode
        {
            get
            {
                return this.m_CalcMode;
            }

            set
            {
                this.m_CalcMode = value;
            }
        }

        public XlsBiffSimpleValueRecord CalcCount
        {
            get
            {
                return this.m_CalcCount;
            }

            set
            {
                this.m_CalcCount = value;
            }
        }

        public XlsBiffSimpleValueRecord RefMode
        {
            get
            {
                return this.m_RefMode;
            }

            set
            {
                this.m_RefMode = value;
            }
        }

        public XlsBiffSimpleValueRecord Iteration
        {
            get
            {
                return this.m_Iteration;
            }

            set
            {
                this.m_Iteration = value;
            }
        }

        public XlsBiffRecord Delta
        {
            get
            {
                return this.m_Delta;
            }

            set
            {
                this.m_Delta = value;
            }
        }

        /// <summary>
        /// Dimensions of worksheet
        /// </summary>
        public XlsBiffDimensions Dimensions
        {
            get
            {
                return this.m_Dimensions;
            }

            set
            {
                this.m_Dimensions = value;
            }
        }

        public XlsBiffRecord Window
        {
            get
            {
                return this.m_Window;
            }

            set
            {
                this.m_Window = value;
            }
        }
    }
}