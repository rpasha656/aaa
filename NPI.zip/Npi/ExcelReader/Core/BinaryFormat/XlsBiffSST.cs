namespace Excel.Core.BinaryFormat
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    /// <summary>
    /// Represents a Shared String Table in BIFF8 format
    /// </summary>
    internal class XlsBiffSST : XlsBiffRecord
    {
        private readonly List<uint> continues = new List<uint>();

        private readonly List<string> m_strings;

        private uint m_size;

        internal XlsBiffSST(byte[] bytes, uint offset, ExcelBinaryReader reader)
            : base(bytes, offset, reader)
        {
            this.m_size = this.RecordSize;
            this.m_strings = new List<string>();
        }

        /// <summary>
        /// Returns count of strings in SST
        /// </summary>
        public uint Count
        {
            get
            {
                return this.ReadUInt32(0x0);
            }
        }

        /// <summary>
        /// Returns count of unique strings in SST
        /// </summary>
        public uint UniqueCount
        {
            get
            {
                return this.ReadUInt32(0x4);
            }
        }

        /// <summary>
        /// Reads strings from BIFF stream into SST array
        /// </summary>
        public void ReadStrings()
        {
            uint offset = (uint)this.m_readoffset + 8;
            uint last = (uint)this.m_readoffset + this.RecordSize;
            int lastcontinue = 0;
            uint count = this.UniqueCount;
            while (offset < last)
            {
                XlsFormattedUnicodeString str = new XlsFormattedUnicodeString(this.m_bytes, offset);
                uint prefix = str.HeadSize;
                uint postfix = str.TailSize;
                uint len = str.CharacterCount;
                uint size = prefix + postfix + len + (str.IsMultiByte ? len : 0);
                if (offset + size > last)
                {
                    if (lastcontinue >= this.continues.Count)
                    {
                        break;
                    }

                    uint contoffset = this.continues[lastcontinue];
                    byte encoding = Buffer.GetByte(this.m_bytes, (int)contoffset + 4);
                    byte[] buff = new byte[size * 2];
                    Buffer.BlockCopy(this.m_bytes, (int)offset, buff, 0, (int)(last - offset));
                    if ((encoding == 0) && str.IsMultiByte)
                    {
                        len -= (last - prefix - offset) / 2;
                        string temp = Encoding.Default.GetString(this.m_bytes, (int)contoffset + 5, (int)len);
                        byte[] tempbytes = Encoding.Unicode.GetBytes(temp);
                        Buffer.BlockCopy(tempbytes, 0, buff, (int)(last - offset), tempbytes.Length);
                        Buffer.BlockCopy(this.m_bytes, (int)(contoffset + 5 + len), buff, (int)((last - offset) + len + len), (int)postfix);
                        offset = contoffset + 5 + len + postfix;
                    }
                    else if ((encoding == 1) && (str.IsMultiByte == false))
                    {
                        len -= last - offset - prefix;
                        string temp = Encoding.Unicode.GetString(this.m_bytes, (int)contoffset + 5, (int)(len + len));
                        byte[] tempbytes = Encoding.Default.GetBytes(temp);
                        Buffer.BlockCopy(tempbytes, 0, buff, (int)(last - offset), tempbytes.Length);
                        Buffer.BlockCopy(this.m_bytes, (int)(contoffset + 5 + len + len), buff, (int)((last - offset) + len), (int)postfix);
                        offset = contoffset + 5 + len + len + postfix;
                    }
                    else
                    {
                        Buffer.BlockCopy(this.m_bytes, (int)contoffset + 5, buff, (int)(last - offset), (int)((size - last) + offset));
                        offset = ((contoffset + 5 + size) - last) + offset;
                    }

                    last = contoffset + 4 + BitConverter.ToUInt16(this.m_bytes, (int)contoffset + 2);
                    lastcontinue++;

                    str = new XlsFormattedUnicodeString(buff, 0);
                }
                else
                {
                    offset += size;
                    if (offset == last)
                    {
                        if (lastcontinue < this.continues.Count)
                        {
                            uint contoffset = this.continues[lastcontinue];
                            offset = contoffset + 4;
                            last = offset + BitConverter.ToUInt16(this.m_bytes, (int)contoffset + 2);
                            lastcontinue++;
                        }
                        else
                        {
                            count = 1;
                        }
                    }
                }

                this.m_strings.Add(str.Value);
                count--;
                if (count == 0)
                {
                    break;
                }
            }
        }

        /// <summary>
        /// Returns string at specified index
        /// </summary>
        /// <param name="SSTIndex">Index of string to get</param>
        /// <returns>string value if it was found, empty string otherwise</returns>
        public string GetString(uint SSTIndex)
        {
            if (SSTIndex < this.m_strings.Count)
            {
                return this.m_strings[(int)SSTIndex];
            }

            return string.Empty;
        }

        /// <summary>
        /// Appends Continue record to SST
        /// </summary>
        /// <param name="fragment">Continue record</param>
        public void Append(XlsBiffContinue fragment)
        {
            this.continues.Add((uint)fragment.Offset);
            this.m_size += (uint)fragment.Size;
        }
    }
}