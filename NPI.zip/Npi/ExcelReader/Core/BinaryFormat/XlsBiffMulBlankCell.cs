namespace Excel.Core.BinaryFormat
{
    /// <summary>
    /// Represents multiple Blank cell
    /// </summary>
    internal class XlsBiffMulBlankCell : XlsBiffBlankCell
    {
        internal XlsBiffMulBlankCell(byte[] bytes, uint offset, ExcelBinaryReader reader)
            : base(bytes, offset, reader)
        {
        }

        /// <summary>
        /// Zero-based index of last described column
        /// </summary>
        public ushort LastColumnIndex
        {
            get
            {
                return this.ReadUInt16(this.RecordSize - 2);
            }
        }

        /// <summary>
        /// Returns format forspecified column, column must be between ColumnIndex and LastColumnIndex
        /// </summary>
        /// <param name="ColumnIdx">Index of column</param>
        /// <returns>Format</returns>
        public ushort GetXF(ushort ColumnIdx)
        {
            int ofs = 4 + (6 * (ColumnIdx - this.ColumnIndex));
            if (ofs > this.RecordSize - 2)
            {
                return 0;
            }

            return this.ReadUInt16(ofs);
        }
    }
}