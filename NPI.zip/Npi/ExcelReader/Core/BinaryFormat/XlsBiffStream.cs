namespace Excel.Core.BinaryFormat
{
    using System;
    using System.IO;
    using System.Runtime.CompilerServices;

    /// <summary>
    /// Represents a BIFF stream
    /// </summary>
    internal class XlsBiffStream : XlsStream
    {
        private readonly ExcelBinaryReader reader;

        private readonly byte[] bytes;

        private readonly int m_size;

        private int m_offset;

        public XlsBiffStream(XlsHeader hdr, uint streamStart, bool isMini, XlsRootDirectory rootDir, ExcelBinaryReader reader)
            : base(hdr, streamStart, isMini, rootDir)
        {
            this.reader = reader;
            this.bytes = base.ReadStream();
            this.m_size = this.bytes.Length;
            this.m_offset = 0;
        }

        /// <summary>
        /// Returns size of BIFF stream in bytes
        /// </summary>
        public int Size
        {
            get
            {
                return this.m_size;
            }
        }

        /// <summary>
        /// Returns current position in BIFF stream
        /// </summary>
        public int Position
        {
            get
            {
                return this.m_offset;
            }
        }

        // TODO:Remove ReadStream
        /// <summary>
        /// Always returns null, use biff-specific methods
        /// </summary>
        /// <returns></returns>
        [Obsolete("Use BIFF-specific methods for this stream")]
        public new byte[] ReadStream()
        {
            return this.bytes;
        }

        /// <summary>
        /// Sets stream pointer to the specified offset
        /// </summary>
        /// <param name="offset">Offset value</param>
        /// <param name="origin">Offset origin</param>
        [MethodImpl(MethodImplOptions.Synchronized)]
        public void Seek(int offset, SeekOrigin origin)
        {
            switch (origin)
            {
                case SeekOrigin.Begin:
                    this.m_offset = offset;
                    break;
                case SeekOrigin.Current:
                    this.m_offset += offset;
                    break;
                case SeekOrigin.End:
                    this.m_offset = this.m_size - offset;
                    break;
            }

            if (this.m_offset < 0)
            {
                throw new ArgumentOutOfRangeException(string.Format("{0} On offset={1}", Errors.ErrorBIFFIlegalBefore, offset));
            }

            if (this.m_offset > this.m_size)
            {
                throw new ArgumentOutOfRangeException(string.Format("{0} On offset={1}", Errors.ErrorBIFFIlegalAfter, offset));
            }
        }

        /// <summary>
        /// Reads record under cursor and advances cursor position to next record
        /// </summary>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.Synchronized)]
        public XlsBiffRecord Read()
        {
            XlsBiffRecord rec = XlsBiffRecord.GetRecord(this.bytes, (uint)this.m_offset, this.reader);
            this.m_offset += rec.Size;
            if (this.m_offset > this.m_size)
            {
                return null;
            }

            return rec;
        }

        /// <summary>
        /// Reads record at specified offset, does not change cursor position
        /// </summary>
        /// <param name="offset"></param>
        /// <returns></returns>
        public XlsBiffRecord ReadAt(int offset)
        {
            XlsBiffRecord rec = XlsBiffRecord.GetRecord(this.bytes, (uint)offset, this.reader);

            // choose ReadOption.Loose to skip this check (e.g. sql reporting services)
            if (this.reader.ReadOption == ReadOption.Strict)
            {
                if (this.m_offset + rec.Size > this.m_size)
                {
                    return null;
                }
            }

            return rec;
        }
    }
}