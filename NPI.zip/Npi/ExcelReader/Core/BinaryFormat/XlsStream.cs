namespace Excel.Core.BinaryFormat
{
    using System.IO;

    /// <summary>
    /// Represents an Excel file stream
    /// </summary>
    internal class XlsStream
    {
        protected XlsFat m_fat;

        protected XlsFat m_minifat;

        protected Stream m_fileStream;

        protected XlsHeader m_hdr;

        protected uint m_startSector;

        protected bool m_isMini;

        protected XlsRootDirectory m_rootDir;

        public XlsStream(XlsHeader hdr, uint startSector, bool isMini, XlsRootDirectory rootDir)
        {
            this.m_fileStream = hdr.FileStream;
            this.m_fat = hdr.FAT;
            this.m_hdr = hdr;
            this.m_startSector = startSector;
            this.m_isMini = isMini;
            this.m_rootDir = rootDir;

            this.CalculateMiniFat(rootDir);
        }

        public void CalculateMiniFat(XlsRootDirectory rootDir)
        {
            this.m_minifat = this.m_hdr.GetMiniFAT(rootDir);
        }

        /// <summary>
        /// Returns offset of first stream sector
        /// </summary>
        public uint BaseOffset
        {
            get
            {
                return (uint)((this.m_startSector + 1) * this.m_hdr.SectorSize);
            }
        }

        /// <summary>
        /// Returns number of first stream sector
        /// </summary>
        public uint BaseSector
        {
            get
            {
                return this.m_startSector;
            }
        }

        /// <summary>
        /// Reads stream data from file
        /// </summary>
        /// <returns>Stream data</returns>
        public byte[] ReadStream()
        {
            uint sector = this.m_startSector, prevSector = 0;
            int sectorSize = this.m_isMini ? this.m_hdr.MiniSectorSize : this.m_hdr.SectorSize;
            var fat = this.m_isMini ? this.m_minifat : this.m_fat;
            long offset = 0;
            if (this.m_isMini && (this.m_rootDir != null))
            {
                offset = (this.m_rootDir.RootEntry.StreamFirstSector + 1) * this.m_hdr.SectorSize;
            }

            byte[] buff = new byte[sectorSize];
            byte[] ret;

            using (MemoryStream ms = new MemoryStream(sectorSize * 8))
            {
                lock (this.m_fileStream)
                {
                    do
                    {
                        if ((prevSector == 0) || (sector - prevSector != 1))
                        {
                            var adjustedSector = this.m_isMini ? sector : sector + 1; // standard sector is + 1 because header is first
                            this.m_fileStream.Seek((adjustedSector * sectorSize) + offset, SeekOrigin.Begin);
                        }

                        prevSector = sector;
                        this.m_fileStream.Read(buff, 0, sectorSize);
                        ms.Write(buff, 0, sectorSize);
                    }
                    while ((sector = fat.GetNextSector(sector)) != (uint)FATMARKERS.FAT_EndOfChain);
                }

                ret = ms.ToArray();
            }

            return ret;
        }
    }
}