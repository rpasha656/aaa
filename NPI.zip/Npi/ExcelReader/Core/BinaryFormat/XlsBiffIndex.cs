namespace Excel.Core.BinaryFormat
{
    using System.Collections.Generic;

    /// <summary>
    /// Represents a worksheet index
    /// </summary>
    internal class XlsBiffIndex : XlsBiffRecord
    {
        private bool isV8 = true;

        internal XlsBiffIndex(byte[] bytes, uint offset, ExcelBinaryReader reader)
            : base(bytes, offset, reader)
        {
        }

        /// <summary>
        /// Gets or sets if BIFF8 addressing is used
        /// </summary>
        public bool IsV8
        {
            get
            {
                return this.isV8;
            }

            set
            {
                this.isV8 = value;
            }
        }

        /// <summary>
        /// Returns zero-based index of first existing row
        /// </summary>
        public uint FirstExistingRow
        {
            get
            {
                return this.isV8 ? this.ReadUInt32(0x4) : this.ReadUInt16(0x4);
            }
        }

        /// <summary>
        /// Returns zero-based index of last existing row
        /// </summary>
        public uint LastExistingRow
        {
            get
            {
                return this.isV8 ? this.ReadUInt32(0x8) : this.ReadUInt16(0x6);
            }
        }

        /// <summary>
        /// Returns addresses of DbCell records
        /// </summary>
        public uint[] DbCellAddresses
        {
            get
            {
                int size = this.RecordSize;
                int firstIdx = this.isV8 ? 16 : 12;
                if (size <= firstIdx)
                {
                    return new uint[0];
                }

                List<uint> cells = new List<uint>((size - firstIdx) / 4);
                for (int i = firstIdx; i < size; i += 4)
                {
                    cells.Add(this.ReadUInt32(i));
                }

                return cells.ToArray();
            }
        }
    }
}