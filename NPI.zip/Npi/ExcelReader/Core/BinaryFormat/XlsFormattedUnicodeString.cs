namespace Excel.Core.BinaryFormat
{
    using System;
    using System.Text;

    /// <summary>
    /// Represents formatted unicode string in SST
    /// </summary>
    internal class XlsFormattedUnicodeString
    {
        #region FormattedUnicodeStringFlags enum

        [Flags]
        public enum FormattedUnicodeStringFlags : byte
        {
            MultiByte = 0x01,

            HasExtendedString = 0x04,

            HasFormatting = 0x08,
        }

        #endregion

        protected byte[] m_bytes;

        protected uint m_offset;

        public XlsFormattedUnicodeString(byte[] bytes, uint offset)
        {
            this.m_bytes = bytes;
            this.m_offset = offset;
        }

        /// <summary>
        /// Count of characters in string
        /// </summary>
        public ushort CharacterCount
        {
            get
            {
                return BitConverter.ToUInt16(this.m_bytes, (int)this.m_offset);
            }
        }

        /// <summary>
        /// String flags
        /// </summary>
        public FormattedUnicodeStringFlags Flags
        {
            get
            {
                return (FormattedUnicodeStringFlags)Buffer.GetByte(this.m_bytes, (int)this.m_offset + 2);
            }
        }

        /// <summary>
        /// Checks if string has Extended record
        /// </summary>
        public bool HasExtString
        {
            get
            {
                return false;
            }

            // ((Flags & FormattedUnicodeStringFlags.HasExtendedString) == FormattedUnicodeStringFlags.HasExtendedString); }
        }

        /// <summary>
        /// Checks if string has formatting
        /// </summary>
        public bool HasFormatting
        {
            get
            {
                return (this.Flags & FormattedUnicodeStringFlags.HasFormatting) == FormattedUnicodeStringFlags.HasFormatting;
            }
        }

        /// <summary>
        /// Checks if string is unicode
        /// </summary>
        public bool IsMultiByte
        {
            get
            {
                return (this.Flags & FormattedUnicodeStringFlags.MultiByte) == FormattedUnicodeStringFlags.MultiByte;
            }
        }

        /// <summary>
        /// Returns length of string in bytes
        /// </summary>
        private uint ByteCount
        {
            get
            {
                return (uint)(this.CharacterCount * (this.IsMultiByte ? 2 : 1));
            }
        }

        /// <summary>
        /// Returns number of formats used for formatting (0 if string has no formatting)
        /// </summary>
        public ushort FormatCount
        {
            get
            {
                return this.HasFormatting ? BitConverter.ToUInt16(this.m_bytes, (int)this.m_offset + 3) : (ushort)0;
            }
        }

        /// <summary>
        /// Returns size of extended string in bytes, 0 if there is no one
        /// </summary>
        public uint ExtendedStringSize
        {
            get
            {
                return this.HasExtString ? (uint)BitConverter.ToUInt16(this.m_bytes, (int)this.m_offset + (this.HasFormatting ? 5 : 3)) : 0;
            }
        }

        /// <summary>
        /// Returns head (before string data) size in bytes
        /// </summary>
        public uint HeadSize
        {
            get
            {
                return (uint)(this.HasFormatting ? 2 : 0) + (uint)(this.HasExtString ? 4 : 0) + 3;
            }
        }

        /// <summary>
        /// Returns tail (after string data) size in bytes
        /// </summary>
        public uint TailSize
        {
            get
            {
                return (uint)(this.HasFormatting ? 4 * this.FormatCount : 0) + (this.HasExtString ? this.ExtendedStringSize : 0);
            }
        }

        /// <summary>
        /// Returns size of whole record in bytes
        /// </summary>
        public uint Size
        {
            get
            {
                uint extraSize = (uint)(this.HasFormatting ? 2 + (this.FormatCount * 4) : 0) + (this.HasExtString ? 4 + this.ExtendedStringSize : 0)
                                 + 3;
                if (!this.IsMultiByte)
                {
                    return extraSize + this.CharacterCount;
                }

                return extraSize + ((uint)this.CharacterCount * 2);
            }
        }

        /// <summary>
        /// Returns string represented by this instance
        /// </summary>
        public string Value
        {
            get
            {
                return this.IsMultiByte
                           ? Encoding.Unicode.GetString(this.m_bytes, (int)(this.m_offset + this.HeadSize), (int)this.ByteCount)
                           : Encoding.Default.GetString(this.m_bytes, (int)(this.m_offset + this.HeadSize), (int)this.ByteCount);
            }
        }
    }
}