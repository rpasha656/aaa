namespace Excel.Core.BinaryFormat
{
    /// <summary>
    /// Represents multiple RK number cells
    /// </summary>
    internal class XlsBiffMulRKCell : XlsBiffBlankCell
    {
        internal XlsBiffMulRKCell(byte[] bytes, uint offset, ExcelBinaryReader reader)
            : base(bytes, offset, reader)
        {
        }

        /// <summary>
        /// Returns zero-based index of last described column
        /// </summary>
        public ushort LastColumnIndex
        {
            get
            {
                return this.ReadUInt16(this.RecordSize - 2);
            }
        }

        /// <summary>
        /// Returns format for specified column
        /// </summary>
        /// <param name="ColumnIdx">Index of column, must be between ColumnIndex and LastColumnIndex</param>
        /// <returns></returns>
        public ushort GetXF(ushort ColumnIdx)
        {
            int ofs = 4 + (6 * (ColumnIdx - this.ColumnIndex));
            if (ofs > this.RecordSize - 2)
            {
                return 0;
            }

            return this.ReadUInt16(ofs);
        }

        /// <summary>
        /// Returns value for specified column
        /// </summary>
        /// <param name="ColumnIdx">Index of column, must be between ColumnIndex and LastColumnIndex</param>
        /// <returns></returns>
        public double GetValue(ushort ColumnIdx)
        {
            int ofs = 6 + (6 * (ColumnIdx - this.ColumnIndex));
            if (ofs > this.RecordSize)
            {
                return 0;
            }

            return XlsBiffRKCell.NumFromRK(this.ReadUInt32(ofs));
        }
    }
}