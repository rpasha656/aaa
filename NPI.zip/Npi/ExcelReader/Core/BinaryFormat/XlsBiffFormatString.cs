namespace Excel.Core.BinaryFormat
{
    using System.Text;

    /// <summary>
    /// Represents a string value of formula
    /// </summary>
    internal class XlsBiffFormatString : XlsBiffRecord
    {
        private Encoding m_UseEncoding = Encoding.Default;

        private string m_value = null;

        internal XlsBiffFormatString(byte[] bytes, uint offset, ExcelBinaryReader reader)
            : base(bytes, offset, reader)
        {
        }

        /// <summary>
        /// Encoding used to deal with strings
        /// </summary>
        public Encoding UseEncoding
        {
            get
            {
                return this.m_UseEncoding;
            }

            set
            {
                this.m_UseEncoding = value;
            }
        }

        /// <summary>
        /// Length of the string
        /// </summary>
        public ushort Length
        {
            get
            {
                switch (this.ID)
                {
                    case BIFFRECORDTYPE.FORMAT_V23:
                        return this.ReadByte(0x0);
                    default:
                        return this.ReadUInt16(2);
                }
            }
        }

        /// <summary>
        /// String text
        /// </summary>
        public string Value
        {
            get
            {
                if (this.m_value == null)
                {
                    switch (this.ID)
                    {
                        case BIFFRECORDTYPE.FORMAT_V23:
                            this.m_value = this.m_UseEncoding.GetString(this.m_bytes, this.m_readoffset + 1, this.Length);
                            break;
                        case BIFFRECORDTYPE.FORMAT:
                            var offset = this.m_readoffset + 5;
                            var flags = this.ReadByte(3);
                            this.m_UseEncoding = (flags & 0x01) == 0x01 ? Encoding.Unicode : Encoding.Default;
                            if ((flags & 0x04) == 0x01)
                            {
                                // asian phonetic block size
                                offset += 4;
                            }

                            if ((flags & 0x08) == 0x01)
                            {
                                // number of rtf blocks
                                offset += 2;
                            }

                            this.m_value = this.m_UseEncoding.IsSingleByte
                                               ? this.m_UseEncoding.GetString(this.m_bytes, offset, this.Length)
                                               : this.m_UseEncoding.GetString(this.m_bytes, offset, this.Length * 2);

                            break;
                    }
                }

                return this.m_value;
            }
        }

        public ushort Index
        {
            get
            {
                switch (this.ID)
                {
                    case BIFFRECORDTYPE.FORMAT_V23:
                        return 0;
                    default:
                        return this.ReadUInt16(0);
                }
            }
        }
    }
}