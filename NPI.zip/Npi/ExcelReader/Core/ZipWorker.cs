// using ICSharpCode.SharpZipLib.Zip;
namespace Excel.Core
{
    using System;
    using System.IO;

    using Ionic.Zip;

    public class ZipWorker : IDisposable
    {
        #region Members and Properties

        private Stream _fileStream;

        private ZipFile _zipFile;

        private byte[] buffer;

        private bool disposed;

        private bool _isCleaned;

        private const string TMP = "TMP_Z";

        private const string FOLDER_xl = "xl";

        private const string FOLDER_worksheets = "worksheets";

        private const string FILE_sharedStrings = "sharedStrings.{0}";

        private const string FILE_styles = "styles.{0}";

        private const string FILE_workbook = "workbook.{0}";

        private const string FILE_sheet = "sheet{0}.{1}";

        private const string FOLDER_rels = "_rels";

        private const string FILE_rels = "workbook.{0}.rels";

        private string _tempPath;

        private string _tempEnv;

        private string _exceptionMessage;

        private string _xlPath;

        private string _format = "xml";

        private bool _isValid;

        // private bool _isBinary12Format;

        /// <summary>
        /// Gets a value indicating whether this instance is valid.
        /// </summary>
        /// <value><c>true</c> if this instance is valid; otherwise, <c>false</c>.</value>
        public bool IsValid
        {
            get
            {
                return this._isValid;
            }
        }

        /// <summary>
        /// Gets the temp path for extracted files.
        /// </summary>
        /// <value>The temp path for extracted files.</value>
        public string TempPath
        {
            get
            {
                return this._tempPath;
            }
        }

        /// <summary>
        /// Gets the exception message.
        /// </summary>
        /// <value>The exception message.</value>
        public string ExceptionMessage
        {
            get
            {
                return this._exceptionMessage;
            }
        }

        #endregion

        public ZipWorker()
        {
            this._tempEnv = Path.GetTempPath();
        }

        /// <summary>
        /// Extracts the specified zip file stream.
        /// </summary>
        /// <param name="fileStream">The zip file stream.</param>
        /// <returns></returns>
        public bool Extract(Stream fileStream)
        {
            if (null == fileStream)
            {
                return false;
            }

            this._fileStream = fileStream;

            this.CleanFromTemp(false);

            // NewTempPath();
            this._isValid = true;

            ZipFile zipFile = null;

            try
            {
                zipFile = ZipFile.Read(this._fileStream);
                if (zipFile != null)
                {
                    this._zipFile = zipFile;
                }

                this._xlPath = FOLDER_xl;

                // IEnumerator enumerator = zipFile.GetEnumerator();

                // while ( enumerator.MoveNext() )
                // {
                // ZipEntry entry = (ZipEntry)enumerator.Current;

                // ExtractZipEntry( zipFile, entry );
                // }
            }
            catch (Exception ex)
            {
                this._isValid = false;
                this._exceptionMessage = ex.Message;

                this.CleanFromTemp(true);

                    // true tells CleanFromTemp not to raise an IO Exception if this operation fails. If it did then the real error here would be masked
            }
            finally
            {
                // fileStream.Close();

                // if ( null != zipFile ) zipFile.Dispose();
            }

            return this._isValid && (this._zipFile != null);
        }

        /// <summary>
        /// Gets the shared strings stream.
        /// </summary>
        /// <returns></returns>
        public Stream GetSharedStringsStream()
        {
            return this.GetStream(Path.Combine(this._xlPath, string.Format(FILE_sharedStrings, this._format)));
        }

        /// <summary>
        /// Gets the styles stream.
        /// </summary>
        /// <returns></returns>
        public Stream GetStylesStream()
        {
            return this.GetStream(Path.Combine(this._xlPath, string.Format(FILE_styles, this._format)));
        }

        /// <summary>
        /// Gets the workbook stream.
        /// </summary>
        /// <returns></returns>
        public Stream GetWorkbookStream()
        {
            return this.GetStream(Path.Combine(this._xlPath, string.Format(FILE_workbook, this._format)));
        }

        /// <summary>
        /// Gets the worksheet stream.
        /// </summary>
        /// <param name="sheetId">The sheet id.</param>
        /// <returns></returns>
        public Stream GetWorksheetStream(int sheetId)
        {
            return this.GetStream(Path.Combine(Path.Combine(this._xlPath, FOLDER_worksheets), string.Format(FILE_sheet, sheetId, this._format)));
        }

        public Stream GetWorksheetStream(string sheetPath)
        {
            // its possible sheetPath starts with /xl. in this case trim the /xl
            if (sheetPath.StartsWith("/xl/"))
            {
                sheetPath = sheetPath.Substring(4);
            }

            return this.GetStream(Path.Combine(this._xlPath, sheetPath));
        }

        /// <summary>
        /// Gets the workbook rels stream.
        /// </summary>
        /// <returns></returns>
        public Stream GetWorkbookRelsStream()
        {
            return this.GetStream(Path.Combine(this._xlPath, Path.Combine(FOLDER_rels, string.Format(FILE_rels, this._format))));
        }

        private void CleanFromTemp(bool catchIoError)
        {
            if (string.IsNullOrEmpty(this._tempPath))
            {
                return;
            }

            this._isCleaned = true;

            try
            {
                if (Directory.Exists(this._tempPath))
                {
                    Directory.Delete(this._tempPath, true);
                }
            }
            catch (IOException ex)
            {
                this._exceptionMessage = ex.Message;
                if (!catchIoError)
                {
                    throw;
                }
            }
        }

        private void ExtractZipEntry(ZipFile zipFile, ZipEntry entry)
        {
            if (string.IsNullOrEmpty(entry.FileName))
            {
                return;
            }

            string tPath = Path.Combine(this._tempPath, entry.FileName);
            string path = entry.IsDirectory ? tPath : Path.GetDirectoryName(Path.GetFullPath(tPath));

            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            // if ( !entry.IsFile ) return;

            // 			try
            // 			{
            using (FileStream stream = File.Create(tPath))
            {
                if (this.buffer == null)
                {
                    this.buffer = new byte[0x1000];
                }

                using (var inputStream = new MemoryStream())
                {
                    entry.Extract(inputStream);
                    inputStream.Seek(0, SeekOrigin.Begin);
                    int count;
                    while ((count = inputStream.Read(this.buffer, 0, this.buffer.Length)) > 0)
                    {
                        stream.Write(this.buffer, 0, count);
                    }
                }

                stream.Flush();
            }

            // 			}
            // 			catch
            // 			{
            // 				throw;
            // 			}
        }

        private void NewTempPath()
        {
            this._tempPath = Path.Combine(this._tempEnv, TMP + DateTime.Now.ToFileTimeUtc().ToString());

            this._isCleaned = false;

            Directory.CreateDirectory(this._tempPath);
        }

        private bool CheckFolderTree()
        {
            return Directory.Exists(this._xlPath) && Directory.Exists(Path.Combine(this._xlPath, FOLDER_worksheets))
                   && File.Exists(Path.Combine(this._xlPath, FILE_workbook)) && File.Exists(Path.Combine(this._xlPath, FILE_styles));
        }

        private Stream GetStream(string filePath)
        {
            if (this._zipFile == null)
            {
                throw new ZipException("No zip file provided.");
            }

            var entry = this._zipFile[filePath];
            if (entry == null)
            {
                return null;
            }

            var stream = new MemoryStream();
            entry.Extract(stream);
            stream.Seek(0, SeekOrigin.Begin);
            return stream;

            // if ( File.Exists( filePath ) )
            // {
            // return File.Open( filePath, FileMode.Open, FileAccess.Read );
            // }
            // else
            // {
            // return null;
            // }
        }

        #region IDisposable Members

        public void Dispose()
        {
            this.Dispose(true);

            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (!this.disposed)
            {
                if (this._zipFile != null)
                {
                    this._zipFile.Dispose();
                }

                if (this._fileStream != null)
                {
                    this._fileStream.Close();
                    this._fileStream.Dispose();
                }

                if (disposing)
                {
                    if (!this._isCleaned)
                    {
                        this.CleanFromTemp(false);
                    }
                }

                this.buffer = null;
                this._zipFile = null;
                this._fileStream = null;

                this.disposed = true;
            }
        }

        ~ZipWorker()
        {
            this.Dispose(false);
        }

        #endregion
    }
}