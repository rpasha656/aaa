namespace Excel
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Text;

    using Excel.Core;
    using Excel.Core.BinaryFormat;
    using Excel.Exceptions;
    using Excel.Log;

    /// <summary>
    /// ExcelDataReader Class
    /// </summary>
    public class ExcelBinaryReader : IExcelDataReader
    {
        #region Members

        private Stream m_file;

        private XlsHeader m_hdr;

        private List<XlsWorksheet> m_sheets;

        private XlsBiffStream m_stream;

        private DataSet m_workbookData;

        private XlsWorkbookGlobals m_globals;

        private ushort m_version;

        private bool m_ConvertOADate;

        private Encoding m_encoding;

        private bool m_isValid;

        private bool m_isClosed;

        private readonly Encoding m_Default_Encoding = Encoding.UTF8;

        private string m_exceptionMessage;

        private object[] m_cellsValues;

        private uint[] m_dbCellAddrs;

        private int m_dbCellAddrsIndex;

        private bool m_canRead;

        private int m_SheetIndex;

        private int m_depth;

        private int m_cellOffset;

        private int m_maxCol;

        private int m_maxRow;

        private bool m_noIndex;

        private XlsBiffRow m_currentRowRecord;

        private readonly ReadOption m_ReadOption = ReadOption.Strict;

        private bool m_IsFirstRead;

        private bool _isFirstRowAsColumnNames;

        private const string WORKBOOK = "Workbook";

        private const string BOOK = "Book";

        private const string COLUMN = "Column";

        private bool disposed;

        #endregion

        internal ExcelBinaryReader()
        {
            this.m_encoding = this.m_Default_Encoding;
            this.m_version = 0x0600;
            this.m_isValid = true;
            this.m_SheetIndex = -1;
            this.m_IsFirstRead = true;
        }

        internal ExcelBinaryReader(ReadOption readOption)
            : this()
        {
            this.m_ReadOption = readOption;
        }

        #region IDisposable Members

        public void Dispose()
        {
            this.Dispose(true);

            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (!this.disposed)
            {
                if (disposing)
                {
                    if (this.m_workbookData != null)
                    {
                        this.m_workbookData.Dispose();
                    }

                    if (this.m_sheets != null)
                    {
                        this.m_sheets.Clear();
                    }
                }

                this.m_workbookData = null;
                this.m_sheets = null;
                this.m_stream = null;
                this.m_globals = null;
                this.m_encoding = null;
                this.m_hdr = null;

                this.disposed = true;
            }
        }

        ~ExcelBinaryReader()
        {
            this.Dispose(false);
        }

        #endregion

        #region Private methods

        private int findFirstDataCellOffset(int startOffset)
        {
            // seek to the first dbcell record
            var record = this.m_stream.ReadAt(startOffset);
            while (!(record is XlsBiffDbCell))
            {
                if (this.m_stream.Position >= this.m_stream.Size)
                {
                    return -1;
                }

                if (record is XlsBiffEOF)
                {
                    return -1;
                }

                record = this.m_stream.Read();
            }

            XlsBiffDbCell startCell = (XlsBiffDbCell)record;
            XlsBiffRow row = null;

            int offs = startCell.RowAddress;

            do
            {
                row = this.m_stream.ReadAt(offs) as XlsBiffRow;
                if (row == null)
                {
                    break;
                }

                offs += row.Size;
            }
            while (null != row);

            return offs;
        }

        private void readWorkBookGlobals()
        {
            // Read Header
            try
            {
                this.m_hdr = XlsHeader.ReadHeader(this.m_file);
            }
            catch (HeaderException ex)
            {
                this.fail(ex.Message);
                return;
            }
            catch (FormatException ex)
            {
                this.fail(ex.Message);
                return;
            }

            XlsRootDirectory dir = new XlsRootDirectory(this.m_hdr);
            XlsDirectoryEntry workbookEntry = dir.FindEntry(WORKBOOK) ?? dir.FindEntry(BOOK);

            if (workbookEntry == null)
            {
                this.fail(Errors.ErrorStreamWorkbookNotFound);
                return;
            }

            if (workbookEntry.EntryType != STGTY.STGTY_STREAM)
            {
                this.fail(Errors.ErrorWorkbookIsNotStream);
                return;
            }

            this.m_stream = new XlsBiffStream(this.m_hdr, workbookEntry.StreamFirstSector, workbookEntry.IsEntryMiniStream, dir, this);

            this.m_globals = new XlsWorkbookGlobals();

            this.m_stream.Seek(0, SeekOrigin.Begin);

            XlsBiffRecord rec = this.m_stream.Read();
            XlsBiffBOF bof = rec as XlsBiffBOF;

            if ((bof == null) || (bof.Type != BIFFTYPE.WorkbookGlobals))
            {
                this.fail(Errors.ErrorWorkbookGlobalsInvalidData);
                return;
            }

            bool sst = false;

            this.m_version = bof.Version;
            this.m_sheets = new List<XlsWorksheet>();

            while (null != (rec = this.m_stream.Read()))
            {
                switch (rec.ID)
                {
                    case BIFFRECORDTYPE.INTERFACEHDR:
                        this.m_globals.InterfaceHdr = (XlsBiffInterfaceHdr)rec;
                        break;
                    case BIFFRECORDTYPE.BOUNDSHEET:
                        XlsBiffBoundSheet sheet = (XlsBiffBoundSheet)rec;

                        if (sheet.Type != XlsBiffBoundSheet.SheetType.Worksheet)
                        {
                            break;
                        }

                        sheet.IsV8 = this.isV8();
                        sheet.UseEncoding = this.m_encoding;
                        LogManager.Log(this).Debug("BOUNDSHEET IsV8={0}", sheet.IsV8);

                        this.m_sheets.Add(new XlsWorksheet(this.m_globals.Sheets.Count, sheet));
                        this.m_globals.Sheets.Add(sheet);

                        break;
                    case BIFFRECORDTYPE.MMS:
                        this.m_globals.MMS = rec;
                        break;
                    case BIFFRECORDTYPE.COUNTRY:
                        this.m_globals.Country = rec;
                        break;
                    case BIFFRECORDTYPE.CODEPAGE:

                        this.m_globals.CodePage = (XlsBiffSimpleValueRecord)rec;

                        try
                        {
                            this.m_encoding = Encoding.GetEncoding(this.m_globals.CodePage.Value);
                        }
                        catch (ArgumentException)
                        {
                            // Warning - Password protection
                            // TODO: Attach to ILog
                        }

                        break;
                    case BIFFRECORDTYPE.FONT:
                    case BIFFRECORDTYPE.FONT_V34:
                        this.m_globals.Fonts.Add(rec);
                        break;
                    case BIFFRECORDTYPE.FORMAT_V23:
                        {
                            var fmt = (XlsBiffFormatString)rec;
                            fmt.UseEncoding = this.m_encoding;
                            this.m_globals.Formats.Add((ushort)this.m_globals.Formats.Count, fmt);
                        }

                        break;
                    case BIFFRECORDTYPE.FORMAT:
                        {
                            var fmt = (XlsBiffFormatString)rec;
                            this.m_globals.Formats.Add(fmt.Index, fmt);
                        }

                        break;
                    case BIFFRECORDTYPE.XF:
                    case BIFFRECORDTYPE.XF_V4:
                    case BIFFRECORDTYPE.XF_V3:
                    case BIFFRECORDTYPE.XF_V2:
                        this.m_globals.ExtendedFormats.Add(rec);
                        break;
                    case BIFFRECORDTYPE.SST:
                        this.m_globals.SST = (XlsBiffSST)rec;
                        sst = true;
                        break;
                    case BIFFRECORDTYPE.CONTINUE:
                        if (!sst)
                        {
                            break;
                        }

                        XlsBiffContinue contSST = (XlsBiffContinue)rec;
                        this.m_globals.SST.Append(contSST);
                        break;
                    case BIFFRECORDTYPE.EXTSST:
                        this.m_globals.ExtSST = rec;
                        sst = false;
                        break;
                    case BIFFRECORDTYPE.PROTECT:
                    case BIFFRECORDTYPE.PASSWORD:
                    case BIFFRECORDTYPE.PROT4REVPASSWORD:

                        // IsProtected
                        break;
                    case BIFFRECORDTYPE.EOF:
                        if (this.m_globals.SST != null)
                        {
                            this.m_globals.SST.ReadStrings();
                        }

                        return;

                    default:
                        continue;
                }
            }
        }

        private bool readWorkSheetGlobals(XlsWorksheet sheet, out XlsBiffIndex idx, out XlsBiffRow row)
        {
            idx = null;
            row = null;

            this.m_stream.Seek((int)sheet.DataOffset, SeekOrigin.Begin);

            XlsBiffBOF bof = this.m_stream.Read() as XlsBiffBOF;
            if ((bof == null) || (bof.Type != BIFFTYPE.Worksheet))
            {
                return false;
            }

            // DumpBiffRecords();
            XlsBiffRecord rec = this.m_stream.Read();
            if (rec == null)
            {
                return false;
            }

            if (rec is XlsBiffIndex)
            {
                idx = rec as XlsBiffIndex;
            }
            else if (rec is XlsBiffUncalced)
            {
                // Sometimes this come before the index...
                idx = this.m_stream.Read() as XlsBiffIndex;
            }

            // if (null == idx)
            // {
            // 	// There is a record before the index! Chech his type and see the MS Biff Documentation
            // 	return false;
            // }
            if (idx != null)
            {
                idx.IsV8 = this.isV8();
                LogManager.Log(this).Debug("INDEX IsV8={0}", idx.IsV8);
            }

            XlsBiffRecord trec;
            XlsBiffDimensions dims = null;

            do
            {
                trec = this.m_stream.Read();
                if (trec.ID == BIFFRECORDTYPE.DIMENSIONS)
                {
                    dims = (XlsBiffDimensions)trec;
                    break;
                }
            }
            while ((trec != null) && (trec.ID != BIFFRECORDTYPE.ROW));

            // if we are already on row record then set that as the row, otherwise step forward till we get to a row record
            if (trec.ID == BIFFRECORDTYPE.ROW)
            {
                row = (XlsBiffRow)trec;
            }

            XlsBiffRow rowRecord = null;
            while (rowRecord == null)
            {
                if (this.m_stream.Position >= this.m_stream.Size)
                {
                    break;
                }

                var thisRec = this.m_stream.Read();

                LogManager.Log(this).Debug("finding rowRecord offset {0}, rec: {1}", thisRec.Offset, thisRec.ID);
                if (thisRec is XlsBiffEOF)
                {
                    break;
                }

                rowRecord = thisRec as XlsBiffRow;
            }

            if (rowRecord != null)
            {
                LogManager.Log(this)
                    .Debug(
                        "Got row {0}, rec: id={1},rowindex={2}, rowColumnStart={3}, rowColumnEnd={4}",
                        rowRecord.Offset,
                        rowRecord.ID,
                        rowRecord.RowIndex,
                        rowRecord.FirstDefinedColumn,
                        rowRecord.LastDefinedColumn);
            }

            row = rowRecord;

            if (dims != null)
            {
                dims.IsV8 = this.isV8();
                LogManager.Log(this).Debug("dims IsV8={0}", dims.IsV8);
                this.m_maxCol = dims.LastColumn - 1;

                // handle case where sheet reports last column is 1 but there are actually more
                if ((this.m_maxCol <= 0) && (rowRecord != null))
                {
                    this.m_maxCol = rowRecord.LastDefinedColumn;
                }

                this.m_maxRow = (int)dims.LastRow;
                sheet.Dimensions = dims;
            }
            else
            {
                this.m_maxCol = 256;
                this.m_maxRow = (int)idx.LastExistingRow;
            }

            if ((idx != null) && (idx.LastExistingRow <= idx.FirstExistingRow))
            {
                return false;
            }
            else if (row == null)
            {
                return false;
            }

            this.m_depth = 0;

            return true;
        }

        private void DumpBiffRecords()
        {
            XlsBiffRecord rec = null;
            var startPos = this.m_stream.Position;

            do
            {
                rec = this.m_stream.Read();
                LogManager.Log(this).Debug(rec.ID.ToString());
            }
            while ((rec != null) && (this.m_stream.Position < this.m_stream.Size));

            this.m_stream.Seek(startPos, SeekOrigin.Begin);
        }

        private bool readWorkSheetRow()
        {
            this.m_cellsValues = new object[this.m_maxCol];

            while (this.m_cellOffset < this.m_stream.Size)
            {
                XlsBiffRecord rec = this.m_stream.ReadAt(this.m_cellOffset);
                this.m_cellOffset += rec.Size;

                if (rec is XlsBiffDbCell)
                {
                    break;
                }

                ; // break;
                if (rec is XlsBiffEOF)
                {
                    return false;
                }

                ;

                XlsBiffBlankCell cell = rec as XlsBiffBlankCell;

                if ((null == cell) || (cell.ColumnIndex >= this.m_maxCol))
                {
                    continue;
                }

                if (cell.RowIndex != this.m_depth)
                {
                    this.m_cellOffset -= rec.Size;
                    break;
                }

                ;

                this.pushCellValue(cell);
            }

            this.m_depth++;

            return this.m_depth < this.m_maxRow;
        }

        private DataTable readWholeWorkSheet(XlsWorksheet sheet)
        {
            XlsBiffIndex idx;

            if (!this.readWorkSheetGlobals(sheet, out idx, out this.m_currentRowRecord))
            {
                return null;
            }

            DataTable table = new DataTable(sheet.Name);

            bool triggerCreateColumns = true;

            if (idx != null)
            {
                this.readWholeWorkSheetWithIndex(idx, triggerCreateColumns, table);
            }
            else
            {
                this.readWholeWorkSheetNoIndex(triggerCreateColumns, table);
            }

            table.EndLoadData();
            return table;
        }

        // TODO: quite a bit of duplication with the noindex version
        private void readWholeWorkSheetWithIndex(XlsBiffIndex idx, bool triggerCreateColumns, DataTable table)
        {
            this.m_dbCellAddrs = idx.DbCellAddresses;

            for (int index = 0; index < this.m_dbCellAddrs.Length; index++)
            {
                if (this.m_depth == this.m_maxRow)
                {
                    break;
                }

                // init reading data
                this.m_cellOffset = this.findFirstDataCellOffset((int)this.m_dbCellAddrs[index]);
                if (this.m_cellOffset < 0)
                {
                    return;
                }

                // DataTable columns
                if (triggerCreateColumns)
                {
                    if ((this._isFirstRowAsColumnNames && this.readWorkSheetRow()) || (this._isFirstRowAsColumnNames && (this.m_maxRow == 1)))
                    {
                        for (int i = 0; i < this.m_maxCol; i++)
                        {
                            if ((this.m_cellsValues[i] != null) && (this.m_cellsValues[i].ToString().Length > 0))
                            {
                                Helpers.AddColumnHandleDuplicate(table, this.m_cellsValues[i].ToString());
                            }
                            else
                            {
                                Helpers.AddColumnHandleDuplicate(table, string.Concat(COLUMN, i));
                            }
                        }
                    }
                    else
                    {
                        for (int i = 0; i < this.m_maxCol; i++)
                        {
                            table.Columns.Add(null, typeof(Object));
                        }
                    }

                    triggerCreateColumns = false;

                    table.BeginLoadData();
                }

                while (this.readWorkSheetRow())
                {
                    table.Rows.Add(this.m_cellsValues);
                }

                // add the row
                if ((this.m_depth > 0) && !(this._isFirstRowAsColumnNames && (this.m_maxRow == 1)))
                {
                    table.Rows.Add(this.m_cellsValues);
                }
            }
        }

        private void readWholeWorkSheetNoIndex(bool triggerCreateColumns, DataTable table)
        {
            while (this.Read())
            {
                if (this.m_depth == this.m_maxRow)
                {
                    break;
                }

                bool justAddedColumns = false;

                // DataTable columns
                if (triggerCreateColumns)
                {
                    if (this._isFirstRowAsColumnNames || (this._isFirstRowAsColumnNames && (this.m_maxRow == 1)))
                    {
                        for (int i = 0; i < this.m_maxCol; i++)
                        {
                            if ((this.m_cellsValues[i] != null) && (this.m_cellsValues[i].ToString().Length > 0))
                            {
                                Helpers.AddColumnHandleDuplicate(table, this.m_cellsValues[i].ToString());
                            }
                            else
                            {
                                Helpers.AddColumnHandleDuplicate(table, string.Concat(COLUMN, i));
                            }
                        }
                    }
                    else
                    {
                        for (int i = 0; i < this.m_maxCol; i++)
                        {
                            table.Columns.Add(null, typeof(Object));
                        }
                    }

                    triggerCreateColumns = false;
                    justAddedColumns = true;
                    table.BeginLoadData();
                }

                if (!justAddedColumns && (this.m_depth > 0) && !(this._isFirstRowAsColumnNames && (this.m_maxRow == 1)))
                {
                    table.Rows.Add(this.m_cellsValues);
                }
            }

            if ((this.m_depth > 0) && !(this._isFirstRowAsColumnNames && (this.m_maxRow == 1)))
            {
                table.Rows.Add(this.m_cellsValues);
            }
        }

        private void pushCellValue(XlsBiffBlankCell cell)
        {
            double _dValue;
            LogManager.Log(this).Debug("pushCellValue {0}", cell.ID);
            switch (cell.ID)
            {
                case BIFFRECORDTYPE.BOOLERR:
                    if (cell.ReadByte(7) == 0)
                    {
                        this.m_cellsValues[cell.ColumnIndex] = cell.ReadByte(6) != 0;
                    }

                    break;
                case BIFFRECORDTYPE.BOOLERR_OLD:
                    if (cell.ReadByte(8) == 0)
                    {
                        this.m_cellsValues[cell.ColumnIndex] = cell.ReadByte(7) != 0;
                    }

                    break;
                case BIFFRECORDTYPE.INTEGER:
                case BIFFRECORDTYPE.INTEGER_OLD:
                    this.m_cellsValues[cell.ColumnIndex] = ((XlsBiffIntegerCell)cell).Value;
                    break;
                case BIFFRECORDTYPE.NUMBER:
                case BIFFRECORDTYPE.NUMBER_OLD:

                    _dValue = ((XlsBiffNumberCell)cell).Value;

                    this.m_cellsValues[cell.ColumnIndex] = !this.ConvertOaDate ? _dValue : this.tryConvertOADateTime(_dValue, cell.XFormat);

                    LogManager.Log(this).Debug("VALUE: {0}", _dValue);
                    break;
                case BIFFRECORDTYPE.LABEL:
                case BIFFRECORDTYPE.LABEL_OLD:
                case BIFFRECORDTYPE.RSTRING:

                    this.m_cellsValues[cell.ColumnIndex] = ((XlsBiffLabelCell)cell).Value;

                    LogManager.Log(this).Debug("VALUE: {0}", this.m_cellsValues[cell.ColumnIndex]);
                    break;
                case BIFFRECORDTYPE.LABELSST:
                    string tmp = this.m_globals.SST.GetString(((XlsBiffLabelSSTCell)cell).SSTIndex);
                    LogManager.Log(this).Debug("VALUE: {0}", tmp);
                    this.m_cellsValues[cell.ColumnIndex] = tmp;
                    break;
                case BIFFRECORDTYPE.RK:

                    _dValue = ((XlsBiffRKCell)cell).Value;

                    this.m_cellsValues[cell.ColumnIndex] = !this.ConvertOaDate ? _dValue : this.tryConvertOADateTime(_dValue, cell.XFormat);

                    LogManager.Log(this).Debug("VALUE: {0}", _dValue);
                    break;
                case BIFFRECORDTYPE.MULRK:

                    XlsBiffMulRKCell _rkCell = (XlsBiffMulRKCell)cell;
                    for (ushort j = cell.ColumnIndex; j <= _rkCell.LastColumnIndex; j++)
                    {
                        _dValue = _rkCell.GetValue(j);
                        LogManager.Log(this).Debug("VALUE[{1}]: {0}", _dValue, j);
                        this.m_cellsValues[j] = !this.ConvertOaDate ? _dValue : this.tryConvertOADateTime(_dValue, _rkCell.GetXF(j));
                    }

                    break;
                case BIFFRECORDTYPE.BLANK:
                case BIFFRECORDTYPE.BLANK_OLD:
                case BIFFRECORDTYPE.MULBLANK:

                    // Skip blank cells
                    break;
                case BIFFRECORDTYPE.FORMULA:
                case BIFFRECORDTYPE.FORMULA_OLD:

                    object _oValue = ((XlsBiffFormulaCell)cell).Value;

                    if ((null != _oValue) && _oValue is FORMULAERROR)
                    {
                        _oValue = null;
                    }
                    else
                    {
                        this.m_cellsValues[cell.ColumnIndex] = !this.ConvertOaDate
                                                                   ? _oValue
                                                                   : this.tryConvertOADateTime(_oValue, (ushort)cell.XFormat); // date time offset
                    }

                    break;
                default:
                    break;
            }
        }

        private bool moveToNextRecord()
        {
            // if sheet has no index
            if (this.m_noIndex)
            {
                LogManager.Log(this).Debug("No index");
                return this.moveToNextRecordNoIndex();
            }

            // if sheet has index
            if ((null == this.m_dbCellAddrs) || (this.m_dbCellAddrsIndex == this.m_dbCellAddrs.Length) || (this.m_depth == this.m_maxRow))
            {
                return false;
            }

            this.m_canRead = this.readWorkSheetRow();

            // read last row
            if (!this.m_canRead && (this.m_depth > 0))
            {
                this.m_canRead = true;
            }

            if (!this.m_canRead && (this.m_dbCellAddrsIndex < this.m_dbCellAddrs.Length - 1))
            {
                this.m_dbCellAddrsIndex++;
                this.m_cellOffset = this.findFirstDataCellOffset((int)this.m_dbCellAddrs[this.m_dbCellAddrsIndex]);
                if (this.m_cellOffset < 0)
                {
                    return false;
                }

                this.m_canRead = this.readWorkSheetRow();
            }

            return this.m_canRead;
        }

        private bool moveToNextRecordNoIndex()
        {
            // seek from current row record to start of cell data where that cell relates to the next row record
            XlsBiffRow rowRecord = this.m_currentRowRecord;

            if (rowRecord == null)
            {
                return false;
            }

            if (rowRecord.RowIndex < this.m_depth)
            {
                this.m_stream.Seek(rowRecord.Offset + rowRecord.Size, SeekOrigin.Begin);
                do
                {
                    if (this.m_stream.Position >= this.m_stream.Size)
                    {
                        return false;
                    }

                    var record = this.m_stream.Read();
                    if (record is XlsBiffEOF)
                    {
                        return false;
                    }

                    rowRecord = record as XlsBiffRow;
                }
                while ((rowRecord == null) || (rowRecord.RowIndex < this.m_depth));
            }

            this.m_currentRowRecord = rowRecord;

            // m_depth = m_currentRowRecord.RowIndex;

            // we have now found the row record for the new row, the we need to seek forward to the first cell record
            XlsBiffBlankCell cell = null;
            do
            {
                if (this.m_stream.Position >= this.m_stream.Size)
                {
                    return false;
                }

                var record = this.m_stream.Read();
                if (record is XlsBiffEOF)
                {
                    return false;
                }

                if (record.IsCell)
                {
                    var candidateCell = record as XlsBiffBlankCell;
                    if (candidateCell != null)
                    {
                        if (candidateCell.RowIndex == this.m_currentRowRecord.RowIndex)
                        {
                            cell = candidateCell;
                        }
                    }
                }
            }
            while (cell == null);

            this.m_cellOffset = cell.Offset;
            this.m_canRead = this.readWorkSheetRow();

            // read last row
            // if (!m_canRead && m_depth > 0) m_canRead = true;

            // if (!m_canRead && m_dbCellAddrsIndex < (m_dbCellAddrs.Length - 1))
            // {
            // 	m_dbCellAddrsIndex++;
            // 	m_cellOffset = findFirstDataCellOffset((int)m_dbCellAddrs[m_dbCellAddrsIndex]);

            // 	m_canRead = readWorkSheetRow();
            // }
            return this.m_canRead;
        }

        private void initializeSheetRead()
        {
            if (this.m_SheetIndex == this.ResultsCount)
            {
                return;
            }

            this.m_dbCellAddrs = null;

            this.m_IsFirstRead = false;

            if (this.m_SheetIndex == -1)
            {
                this.m_SheetIndex = 0;
            }

            XlsBiffIndex idx;

            if (!this.readWorkSheetGlobals(this.m_sheets[this.m_SheetIndex], out idx, out this.m_currentRowRecord))
            {
                // read next sheet
                this.m_SheetIndex++;
                this.initializeSheetRead();
                return;
            }

            ;

            if (idx == null)
            {
                // no index, but should have the first row record
                this.m_noIndex = true;
            }
            else
            {
                this.m_dbCellAddrs = idx.DbCellAddresses;
                this.m_dbCellAddrsIndex = 0;
                this.m_cellOffset = this.findFirstDataCellOffset((int)this.m_dbCellAddrs[this.m_dbCellAddrsIndex]);
                if (this.m_cellOffset < 0)
                {
                    this.fail("Badly formed binary file. Has INDEX but no DBCELL");
                    return;
                }
            }
        }

        private void fail(string message)
        {
            this.m_exceptionMessage = message;
            this.m_isValid = false;

            this.m_file.Close();
            this.m_isClosed = true;

            this.m_workbookData = null;
            this.m_sheets = null;
            this.m_stream = null;
            this.m_globals = null;
            this.m_encoding = null;
            this.m_hdr = null;
        }

        private object tryConvertOADateTime(double value, ushort XFormat)
        {
            ushort format = 0;
            if ((XFormat >= 0) && (XFormat < this.m_globals.ExtendedFormats.Count))
            {
                var rec = this.m_globals.ExtendedFormats[XFormat];
                switch (rec.ID)
                {
                    case BIFFRECORDTYPE.XF_V2:
                        format = (ushort)(rec.ReadByte(2) & 0x3F);
                        break;
                    case BIFFRECORDTYPE.XF_V3:
                        if ((rec.ReadByte(3) & 4) == 0)
                        {
                            return value;
                        }

                        format = rec.ReadByte(1);
                        break;
                    case BIFFRECORDTYPE.XF_V4:
                        if ((rec.ReadByte(5) & 4) == 0)
                        {
                            return value;
                        }

                        format = rec.ReadByte(1);
                        break;

                    default:
                        if ((rec.ReadByte(this.m_globals.Sheets[this.m_globals.Sheets.Count - 1].IsV8 ? 9 : 7) & 4) == 0)
                        {
                            return value;
                        }

                        format = rec.ReadUInt16(2);
                        break;
                }
            }
            else
            {
                format = XFormat;
            }

            switch (format)
            {
                // numeric built in formats
                case 0: // "General";
                case 1: // "0";
                case 2: // "0.00";
                case 3: // "#,##0";
                case 4: // "#,##0.00";
                case 5: // "\"$\"#,##0_);(\"$\"#,##0)";
                case 6: // "\"$\"#,##0_);[Red](\"$\"#,##0)";
                case 7: // "\"$\"#,##0.00_);(\"$\"#,##0.00)";
                case 8: // "\"$\"#,##0.00_);[Red](\"$\"#,##0.00)";
                case 9: // "0%";
                case 10: // "0.00%";
                case 11: // "0.00E+00";
                case 12: // "# ?/?";
                case 13: // "# ??/??";
                case 0x30: // "##0.0E+0";

                case 0x25: // "_(#,##0_);(#,##0)";
                case 0x26: // "_(#,##0_);[Red](#,##0)";
                case 0x27: // "_(#,##0.00_);(#,##0.00)";
                case 40: // "_(#,##0.00_);[Red](#,##0.00)";
                case 0x29: // "_(\"$\"* #,##0_);_(\"$\"* (#,##0);_(\"$\"* \"-\"_);_(@_)";
                case 0x2a: // "_(\"$\"* #,##0_);_(\"$\"* (#,##0);_(\"$\"* \"-\"_);_(@_)";
                case 0x2b: // "_(\"$\"* #,##0.00_);_(\"$\"* (#,##0.00);_(\"$\"* \"-\"??_);_(@_)";
                case 0x2c: // "_(* #,##0.00_);_(* (#,##0.00);_(* \"-\"??_);_(@_)";
                    return value;

                // date formats
                case 14: // this.GetDefaultDateFormat();
                case 15: // "D-MM-YY";
                case 0x10: // "D-MMM";
                case 0x11: // "MMM-YY";
                case 0x12: // "h:mm AM/PM";
                case 0x13: // "h:mm:ss AM/PM";
                case 20: // "h:mm";
                case 0x15: // "h:mm:ss";
                case 0x16: // string.Format("{0} {1}", this.GetDefaultDateFormat(), this.GetDefaultTimeFormat());

                case 0x2d: // "mm:ss";
                case 0x2e: // "[h]:mm:ss";
                case 0x2f: // "mm:ss.0";
                    return Helpers.ConvertFromOATime(value);
                case 0x31: // "@";
                    return value.ToString();

                default:
                    XlsBiffFormatString fmtString;
                    if (this.m_globals.Formats.TryGetValue(format, out fmtString))
                    {
                        var fmt = fmtString.Value;
                        var formatReader = new FormatReader() { FormatString = fmt };
                        if (formatReader.IsDateFormatString())
                        {
                            return Helpers.ConvertFromOATime(value);
                        }
                    }

                    return value;
            }
        }

        private object tryConvertOADateTime(object value, ushort XFormat)
        {
            double _dValue;

            if (double.TryParse(value.ToString(), out _dValue))
            {
                return this.tryConvertOADateTime(_dValue, XFormat);
            }

            return value;
        }

        public bool isV8()
        {
            return this.m_version >= 0x600;
        }

        #endregion

        #region IExcelDataReader Members

        public void Initialize(Stream fileStream)
        {
            this.m_file = fileStream;

            this.readWorkBookGlobals();

            // set the sheet index to the index of the first sheet.. this is so that properties such as Name which use m_sheetIndex reflect the first sheet in the file without having to perform a read() operation
            this.m_SheetIndex = 0;
        }

        public DataSet AsDataSet()
        {
            return this.AsDataSet(false);
        }

        public DataSet AsDataSet(bool convertOADateTime)
        {
            if (!this.m_isValid)
            {
                return null;
            }

            if (this.m_isClosed)
            {
                return this.m_workbookData;
            }

            this.ConvertOaDate = convertOADateTime;
            this.m_workbookData = new DataSet();

            for (int index = 0; index < this.ResultsCount; index++)
            {
                DataTable table = this.readWholeWorkSheet(this.m_sheets[index]);

                if (null != table)
                {
                    this.m_workbookData.Tables.Add(table);
                }
            }

            this.m_file.Close();
            this.m_isClosed = true;
            this.m_workbookData.AcceptChanges();
            Helpers.FixDataTypes(this.m_workbookData);

            return this.m_workbookData;
        }

        public string ExceptionMessage
        {
            get
            {
                return this.m_exceptionMessage;
            }
        }

        public string Name
        {
            get
            {
                if ((null != this.m_sheets) && (this.m_sheets.Count > 0))
                {
                    return this.m_sheets[this.m_SheetIndex].Name;
                }
                else
                {
                    return null;
                }
            }
        }

        public bool IsValid
        {
            get
            {
                return this.m_isValid;
            }
        }

        public void Close()
        {
            this.m_file.Close();
            this.m_isClosed = true;
        }

        public int Depth
        {
            get
            {
                return this.m_depth;
            }
        }

        public int ResultsCount
        {
            get
            {
                return this.m_globals.Sheets.Count;
            }
        }

        public bool IsClosed
        {
            get
            {
                return this.m_isClosed;
            }
        }

        public bool NextResult()
        {
            if (this.m_SheetIndex >= this.ResultsCount - 1)
            {
                return false;
            }

            this.m_SheetIndex++;

            this.m_IsFirstRead = true;

            return true;
        }

        public bool Read()
        {
            if (!this.m_isValid)
            {
                return false;
            }

            if (this.m_IsFirstRead)
            {
                this.initializeSheetRead();
            }

            return this.moveToNextRecord();
        }

        public int FieldCount
        {
            get
            {
                return this.m_maxCol;
            }
        }

        public bool GetBoolean(int i)
        {
            if (this.IsDBNull(i))
            {
                return false;
            }

            return bool.Parse(this.m_cellsValues[i].ToString());
        }

        public DateTime GetDateTime(int i)
        {
            if (this.IsDBNull(i))
            {
                return DateTime.MinValue;
            }

            // requested change: 3
            object val = this.m_cellsValues[i];

            if (val is DateTime)
            {
                // if the value is already a datetime.. return it without further conversion
                return (DateTime)val;
            }

            // otherwise proceed with conversion attempts
            string valString = val.ToString();
            double dVal;

            try
            {
                dVal = double.Parse(valString);
            }
            catch (FormatException)
            {
                return DateTime.Parse(valString);
            }

            return DateTime.FromOADate(dVal);
        }

        public decimal GetDecimal(int i)
        {
            if (this.IsDBNull(i))
            {
                return decimal.MinValue;
            }

            return decimal.Parse(this.m_cellsValues[i].ToString());
        }

        public double GetDouble(int i)
        {
            if (this.IsDBNull(i))
            {
                return double.MinValue;
            }

            return double.Parse(this.m_cellsValues[i].ToString());
        }

        public float GetFloat(int i)
        {
            if (this.IsDBNull(i))
            {
                return float.MinValue;
            }

            return float.Parse(this.m_cellsValues[i].ToString());
        }

        public short GetInt16(int i)
        {
            if (this.IsDBNull(i))
            {
                return short.MinValue;
            }

            return short.Parse(this.m_cellsValues[i].ToString());
        }

        public int GetInt32(int i)
        {
            if (this.IsDBNull(i))
            {
                return int.MinValue;
            }

            return int.Parse(this.m_cellsValues[i].ToString());
        }

        public long GetInt64(int i)
        {
            if (this.IsDBNull(i))
            {
                return long.MinValue;
            }

            return long.Parse(this.m_cellsValues[i].ToString());
        }

        public string GetString(int i)
        {
            if (this.IsDBNull(i))
            {
                return null;
            }

            return this.m_cellsValues[i].ToString();
        }

        public object GetValue(int i)
        {
            return this.m_cellsValues[i];
        }

        public bool IsDBNull(int i)
        {
            return (null == this.m_cellsValues[i]) || (DBNull.Value == this.m_cellsValues[i]);
        }

        public object this[int i]
        {
            get
            {
                return this.m_cellsValues[i];
            }
        }

        #endregion

        #region  Not Supported IDataReader Members

        public DataTable GetSchemaTable()
        {
            throw new NotSupportedException();
        }

        public int RecordsAffected
        {
            get
            {
                throw new NotSupportedException();
            }
        }

        #endregion

        #region Not Supported IDataRecord Members

        public byte GetByte(int i)
        {
            throw new NotSupportedException();
        }

        public long GetBytes(int i, long fieldOffset, byte[] buffer, int bufferoffset, int length)
        {
            throw new NotSupportedException();
        }

        public char GetChar(int i)
        {
            throw new NotSupportedException();
        }

        public long GetChars(int i, long fieldoffset, char[] buffer, int bufferoffset, int length)
        {
            throw new NotSupportedException();
        }

        public IDataReader GetData(int i)
        {
            throw new NotSupportedException();
        }

        public string GetDataTypeName(int i)
        {
            throw new NotSupportedException();
        }

        public Type GetFieldType(int i)
        {
            throw new NotSupportedException();
        }

        public Guid GetGuid(int i)
        {
            throw new NotSupportedException();
        }

        public string GetName(int i)
        {
            throw new NotSupportedException();
        }

        public int GetOrdinal(string name)
        {
            throw new NotSupportedException();
        }

        public int GetValues(object[] values)
        {
            throw new NotSupportedException();
        }

        public object this[string name]
        {
            get
            {
                throw new NotSupportedException();
            }
        }

        #endregion

        #region IExcelDataReader Members

        public bool IsFirstRowAsColumnNames
        {
            get
            {
                return this._isFirstRowAsColumnNames;
            }

            set
            {
                this._isFirstRowAsColumnNames = value;
            }
        }

        public bool ConvertOaDate
        {
            get
            {
                return this.m_ConvertOADate;
            }

            set
            {
                this.m_ConvertOADate = value;
            }
        }

        public ReadOption ReadOption
        {
            get
            {
                return this.m_ReadOption;
            }
        }

        #endregion
    }

    /// <summary>
    /// Strict is as normal, Loose is more forgiving and will not cause an exception if a record size takes it beyond the end of the file. It will be trunacted in this case (SQl Reporting Services)
    /// </summary>
    public enum ReadOption
    {
        Strict,

        Loose
    }
}