#define DEBUGREADERS

namespace Excel
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Globalization;
    using System.IO;
    using System.Xml;

    using Excel.Core;
    using Excel.Core.OpenXmlFormat;

    public class ExcelOpenXmlReader : IExcelDataReader
    {
        #region Members

        private XlsxWorkbook _workbook;

        private bool _isValid;

        private bool _isClosed;

        private bool _isFirstRead;

        private string _exceptionMessage;

        private int _depth;

        private int _resultIndex;

        private int _emptyRowCount;

        private ZipWorker _zipWorker;

        private XmlReader _xmlReader;

        private Stream _sheetStream;

        private object[] _cellsValues;

        private object[] _savedCellsValues;

        private bool disposed;

        private bool _isFirstRowAsColumnNames;

        private const string COLUMN = "Column";

        private string instanceId = Guid.NewGuid().ToString();

        private List<int> _defaultDateTimeStyles;

        private string _namespaceUri;

        #endregion

        internal ExcelOpenXmlReader()
        {
            this._isValid = true;
            this._isFirstRead = true;

            this._defaultDateTimeStyles = new List<int>(new[] { 14, 15, 16, 17, 18, 19, 20, 21, 22, 45, 46, 47 });
        }

        private void ReadGlobals()
        {
            this._workbook = new XlsxWorkbook(
                                 this._zipWorker.GetWorkbookStream(),
                                 this._zipWorker.GetWorkbookRelsStream(),
                                 this._zipWorker.GetSharedStringsStream(),
                                 this._zipWorker.GetStylesStream());

            this.CheckDateTimeNumFmts(this._workbook.Styles.NumFmts);
        }

        private void CheckDateTimeNumFmts(List<XlsxNumFmt> list)
        {
            if (list.Count == 0)
            {
                return;
            }

            foreach (XlsxNumFmt numFmt in list)
            {
                if (string.IsNullOrEmpty(numFmt.FormatCode))
                {
                    continue;
                }

                string fc = numFmt.FormatCode.ToLower();

                int pos;
                while ((pos = fc.IndexOf('"')) > 0)
                {
                    int endPos = fc.IndexOf('"', pos + 1);

                    if (endPos > 0)
                    {
                        fc = fc.Remove(pos, (endPos - pos) + 1);
                    }
                }

                // it should only detect it as a date if it contains
                // dd mm mmm yy yyyy
                // h hh ss
                // AM PM
                // and only if these appear as "words" so either contained in [ ]
                // or delimted in someway
                // updated to not detect as date if format contains a #
                var formatReader = new FormatReader() { FormatString = fc };
                if (formatReader.IsDateFormatString())
                {
                    this._defaultDateTimeStyles.Add(numFmt.Id);
                }
            }
        }

        private void ReadSheetGlobals(XlsxWorksheet sheet)
        {
            if (this._xmlReader != null)
            {
                this._xmlReader.Close();
            }

            if (this._sheetStream != null)
            {
                this._sheetStream.Close();
            }

            this._sheetStream = this._zipWorker.GetWorksheetStream(sheet.Path);

            if (null == this._sheetStream)
            {
                return;
            }

            this._xmlReader = XmlReader.Create(this._sheetStream);

            // count rows and cols in case there is no dimension elements
            int rows = 0;
            int cols = 0;

            this._namespaceUri = null;

            while (this._xmlReader.Read())
            {
                if ((this._xmlReader.NodeType == XmlNodeType.Element) && (this._xmlReader.LocalName == XlsxWorksheet.N_worksheet))
                {
                    // grab the namespaceuri from the worksheet element
                    this._namespaceUri = this._xmlReader.NamespaceURI;
                }

                if ((this._xmlReader.NodeType == XmlNodeType.Element) && (this._xmlReader.LocalName == XlsxWorksheet.N_dimension))
                {
                    string dimValue = this._xmlReader.GetAttribute(XlsxWorksheet.A_ref);

                    sheet.Dimension = new XlsxDimension(dimValue);
                    break;
                }

                if ((this._xmlReader.NodeType == XmlNodeType.Element) && (this._xmlReader.LocalName == XlsxWorksheet.N_col))
                {
                    cols++;
                }

                if ((this._xmlReader.NodeType == XmlNodeType.Element) && (this._xmlReader.LocalName == XlsxWorksheet.N_row))
                {
                    rows++;
                }
            }

            // if we didn't get a dimension element then use the calculated rows/cols to create it
            if (sheet.Dimension == null)
            {
                if ((rows == 9) || (cols == 0))
                {
                    sheet.IsEmpty = true;
                    return;
                }

                sheet.Dimension = new XlsxDimension(rows, cols);

                // we need to reset our position to sheet data
                this._xmlReader.Close();
                this._sheetStream.Close();
                this._sheetStream = this._zipWorker.GetWorksheetStream(sheet.Path);
                this._xmlReader = XmlReader.Create(this._sheetStream);
            }

            // read up to the sheetData element. if this element is empty then there aren't any rows and we need to null out dimension
            this._xmlReader.ReadToFollowing(XlsxWorksheet.N_sheetData, this._namespaceUri);
            if (this._xmlReader.IsEmptyElement)
            {
                sheet.IsEmpty = true;
            }
        }

        private bool ReadSheetRow(XlsxWorksheet sheet)
        {
            if (null == this._xmlReader)
            {
                return false;
            }

            if (this._emptyRowCount != 0)
            {
                this._cellsValues = new object[sheet.ColumnsCount];
                this._emptyRowCount--;
                this._depth++;

                return true;
            }

            if (this._savedCellsValues != null)
            {
                this._cellsValues = this._savedCellsValues;
                this._savedCellsValues = null;
                this._depth++;

                return true;
            }

            if (((this._xmlReader.NodeType == XmlNodeType.Element) && (this._xmlReader.LocalName == XlsxWorksheet.N_row))
                || this._xmlReader.ReadToFollowing(XlsxWorksheet.N_row, this._namespaceUri))
            {
                this._cellsValues = new object[sheet.ColumnsCount];

                int rowIndex = int.Parse(this._xmlReader.GetAttribute(XlsxWorksheet.A_r));
                if (rowIndex != this._depth + 1)
                {
                    if (rowIndex != this._depth + 1)
                    {
                        this._emptyRowCount = rowIndex - this._depth - 1;
                    }
                }

                bool hasValue = false;
                string a_s = string.Empty;
                string a_t = string.Empty;
                string a_r = string.Empty;
                int col = 0;
                int row = 0;

                while (this._xmlReader.Read())
                {
                    if (this._xmlReader.Depth == 2)
                    {
                        break;
                    }

                    if (this._xmlReader.NodeType == XmlNodeType.Element)
                    {
                        hasValue = false;

                        if (this._xmlReader.LocalName == XlsxWorksheet.N_c)
                        {
                            a_s = this._xmlReader.GetAttribute(XlsxWorksheet.A_s);
                            a_t = this._xmlReader.GetAttribute(XlsxWorksheet.A_t);
                            a_r = this._xmlReader.GetAttribute(XlsxWorksheet.A_r);
                            XlsxDimension.XlsxDim(a_r, out col, out row);
                        }
                        else if ((this._xmlReader.LocalName == XlsxWorksheet.N_v) || (this._xmlReader.LocalName == XlsxWorksheet.N_t))
                        {
                            hasValue = true;
                        }
                    }

                    if ((this._xmlReader.NodeType == XmlNodeType.Text) && hasValue)
                    {
                        double number;
                        object o = this._xmlReader.Value;

                        var style = NumberStyles.Any;
                        var culture = CultureInfo.InvariantCulture;

                        if (double.TryParse(o.ToString(), style, culture, out number))
                        {
                            o = number;
                        }

                        if ((null != a_t) && (a_t == XlsxWorksheet.A_s))
                        {
                            // if string
                            o = Helpers.ConvertEscapeChars(this._workbook.SST[int.Parse(o.ToString())]);
                        }
 // Requested change 4: missing (it appears that if should be else if)
                        else if ((null != a_t) && (a_t == XlsxWorksheet.N_inlineStr))
                        {
                            // if string inline
                            o = Helpers.ConvertEscapeChars(o.ToString());
                        }
                        else if (a_t == "b")
                        {
                            // boolean
                            o = this._xmlReader.Value == "1";
                        }
                        else if (null != a_s)
                        {
                            // if something else
                            XlsxXf xf = this._workbook.Styles.CellXfs[int.Parse(a_s)];
                            if (xf.ApplyNumberFormat && (o != null) && (o.ToString() != string.Empty) && this.IsDateTimeStyle(xf.NumFmtId))
                            {
                                o = Helpers.ConvertFromOATime(number);
                            }
                            else if (xf.NumFmtId == 49)
                            {
                                o = o.ToString();
                            }
                        }

                        if (col - 1 < this._cellsValues.Length)
                        {
                            this._cellsValues[col - 1] = o;
                        }
                    }
                }

                if (this._emptyRowCount > 0)
                {
                    this._savedCellsValues = this._cellsValues;
                    return this.ReadSheetRow(sheet);
                }

                this._depth++;

                return true;
            }

            this._xmlReader.Close();
            if (this._sheetStream != null)
            {
                this._sheetStream.Close();
            }

            return false;
        }

        private bool InitializeSheetRead()
        {
            if (this.ResultsCount <= 0)
            {
                return false;
            }

            this.ReadSheetGlobals(this._workbook.Sheets[this._resultIndex]);

            if (this._workbook.Sheets[this._resultIndex].Dimension == null)
            {
                return false;
            }

            this._isFirstRead = false;

            this._depth = 0;
            this._emptyRowCount = 0;

            return true;
        }

        private bool IsDateTimeStyle(int styleId)
        {
            return this._defaultDateTimeStyles.Contains(styleId);
        }

        #region IExcelDataReader Members

        public void Initialize(Stream fileStream)
        {
            this._zipWorker = new ZipWorker();
            this._zipWorker.Extract(fileStream);

            if (!this._zipWorker.IsValid)
            {
                this._isValid = false;
                this._exceptionMessage = this._zipWorker.ExceptionMessage;

                this.Close();

                return;
            }

            this.ReadGlobals();
        }

        public DataSet AsDataSet()
        {
            return this.AsDataSet(true);
        }

        public DataSet AsDataSet(bool convertOADateTime)
        {
            if (!this._isValid)
            {
                return null;
            }

            DataSet dataset = new DataSet();

            for (int ind = 0; ind < this._workbook.Sheets.Count; ind++)
            {
                DataTable table = new DataTable(this._workbook.Sheets[ind].Name);

                this.ReadSheetGlobals(this._workbook.Sheets[ind]);

                if (this._workbook.Sheets[ind].Dimension == null)
                {
                    continue;
                }

                this._depth = 0;
                this._emptyRowCount = 0;

                // DataTable columns
                if (!this._isFirstRowAsColumnNames)
                {
                    for (int i = 0; i < this._workbook.Sheets[ind].ColumnsCount; i++)
                    {
                        table.Columns.Add(null, typeof(Object));
                    }
                }
                else if (this.ReadSheetRow(this._workbook.Sheets[ind]))
                {
                    for (int index = 0; index < this._cellsValues.Length; index++)
                    {
                        if ((this._cellsValues[index] != null) && (this._cellsValues[index].ToString().Length > 0))
                        {
                            Helpers.AddColumnHandleDuplicate(table, this._cellsValues[index].ToString());
                        }
                        else
                        {
                            Helpers.AddColumnHandleDuplicate(table, string.Concat(COLUMN, index));
                        }
                    }
                }
                else
                {
                    continue;
                }

                table.BeginLoadData();

                while (this.ReadSheetRow(this._workbook.Sheets[ind]))
                {
                    table.Rows.Add(this._cellsValues);
                }

                if (table.Rows.Count > 0)
                {
                    dataset.Tables.Add(table);
                }

                table.EndLoadData();
            }

            dataset.AcceptChanges();
            Helpers.FixDataTypes(dataset);
            return dataset;
        }

        public bool IsFirstRowAsColumnNames
        {
            get
            {
                return this._isFirstRowAsColumnNames;
            }

            set
            {
                this._isFirstRowAsColumnNames = value;
            }
        }

        public bool IsValid
        {
            get
            {
                return this._isValid;
            }
        }

        public string ExceptionMessage
        {
            get
            {
                return this._exceptionMessage;
            }
        }

        public string Name
        {
            get
            {
                return (this._resultIndex >= 0) && (this._resultIndex < this.ResultsCount) ? this._workbook.Sheets[this._resultIndex].Name : null;
            }
        }

        public void Close()
        {
            this._isClosed = true;

            if (this._xmlReader != null)
            {
                this._xmlReader.Close();
            }

            if (this._sheetStream != null)
            {
                this._sheetStream.Close();
            }

            if (this._zipWorker != null)
            {
                this._zipWorker.Dispose();
            }
        }

        public int Depth
        {
            get
            {
                return this._depth;
            }
        }

        public int ResultsCount
        {
            get
            {
                return this._workbook == null ? -1 : this._workbook.Sheets.Count;
            }
        }

        public bool IsClosed
        {
            get
            {
                return this._isClosed;
            }
        }

        public bool NextResult()
        {
            if (this._resultIndex >= this.ResultsCount - 1)
            {
                return false;
            }

            this._resultIndex++;

            this._isFirstRead = true;

            return true;
        }

        public bool Read()
        {
            if (!this._isValid)
            {
                return false;
            }

            if (this._isFirstRead && !this.InitializeSheetRead())
            {
                return false;
            }

            return this.ReadSheetRow(this._workbook.Sheets[this._resultIndex]);
        }

        public int FieldCount
        {
            get
            {
                return (this._resultIndex >= 0) && (this._resultIndex < this.ResultsCount)
                           ? this._workbook.Sheets[this._resultIndex].ColumnsCount
                           : -1;
            }
        }

        public bool GetBoolean(int i)
        {
            if (this.IsDBNull(i))
            {
                return false;
            }

            return bool.Parse(this._cellsValues[i].ToString());
        }

        public DateTime GetDateTime(int i)
        {
            if (this.IsDBNull(i))
            {
                return DateTime.MinValue;
            }

            try
            {
                return (DateTime)this._cellsValues[i];
            }
            catch (InvalidCastException)
            {
                return DateTime.MinValue;
            }
        }

        public decimal GetDecimal(int i)
        {
            if (this.IsDBNull(i))
            {
                return decimal.MinValue;
            }

            return decimal.Parse(this._cellsValues[i].ToString());
        }

        public double GetDouble(int i)
        {
            if (this.IsDBNull(i))
            {
                return double.MinValue;
            }

            return double.Parse(this._cellsValues[i].ToString());
        }

        public float GetFloat(int i)
        {
            if (this.IsDBNull(i))
            {
                return float.MinValue;
            }

            return float.Parse(this._cellsValues[i].ToString());
        }

        public short GetInt16(int i)
        {
            if (this.IsDBNull(i))
            {
                return short.MinValue;
            }

            return short.Parse(this._cellsValues[i].ToString());
        }

        public int GetInt32(int i)
        {
            if (this.IsDBNull(i))
            {
                return int.MinValue;
            }

            return int.Parse(this._cellsValues[i].ToString());
        }

        public long GetInt64(int i)
        {
            if (this.IsDBNull(i))
            {
                return long.MinValue;
            }

            return long.Parse(this._cellsValues[i].ToString());
        }

        public string GetString(int i)
        {
            if (this.IsDBNull(i))
            {
                return null;
            }

            return this._cellsValues[i].ToString();
        }

        public object GetValue(int i)
        {
            return this._cellsValues[i];
        }

        public bool IsDBNull(int i)
        {
            return (null == this._cellsValues[i]) || (DBNull.Value == this._cellsValues[i]);
        }

        public object this[int i]
        {
            get
            {
                return this._cellsValues[i];
            }
        }

        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            this.Dispose(true);

            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (!this.disposed)
            {
                if (disposing)
                {
                    if (this._xmlReader != null)
                    {
                        ((IDisposable)this._xmlReader).Dispose();
                    }

                    if (this._sheetStream != null)
                    {
                        this._sheetStream.Dispose();
                    }

                    if (this._zipWorker != null)
                    {
                        this._zipWorker.Dispose();
                    }
                }

                this._zipWorker = null;
                this._xmlReader = null;
                this._sheetStream = null;

                this._workbook = null;
                this._cellsValues = null;
                this._savedCellsValues = null;

                this.disposed = true;
            }
        }

        ~ExcelOpenXmlReader()
        {
            this.Dispose(false);
        }

        #endregion

        #region  Not Supported IDataReader Members

        public DataTable GetSchemaTable()
        {
            throw new NotSupportedException();
        }

        public int RecordsAffected
        {
            get
            {
                throw new NotSupportedException();
            }
        }

        #endregion

        #region Not Supported IDataRecord Members

        public byte GetByte(int i)
        {
            throw new NotSupportedException();
        }

        public long GetBytes(int i, long fieldOffset, byte[] buffer, int bufferoffset, int length)
        {
            throw new NotSupportedException();
        }

        public char GetChar(int i)
        {
            throw new NotSupportedException();
        }

        public long GetChars(int i, long fieldoffset, char[] buffer, int bufferoffset, int length)
        {
            throw new NotSupportedException();
        }

        public IDataReader GetData(int i)
        {
            throw new NotSupportedException();
        }

        public string GetDataTypeName(int i)
        {
            throw new NotSupportedException();
        }

        public Type GetFieldType(int i)
        {
            throw new NotSupportedException();
        }

        public Guid GetGuid(int i)
        {
            throw new NotSupportedException();
        }

        public string GetName(int i)
        {
            throw new NotSupportedException();
        }

        public int GetOrdinal(string name)
        {
            throw new NotSupportedException();
        }

        public int GetValues(object[] values)
        {
            throw new NotSupportedException();
        }

        public object this[string name]
        {
            get
            {
                throw new NotSupportedException();
            }
        }

        #endregion
    }
}