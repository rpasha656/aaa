﻿namespace Schwab.RPS.Npi.Scanner
{
    using System;
    using System.IO;
    using System.Text;
    using System.Text.RegularExpressions;

    using Schwab.RPS.Npi.Scanner.Interfaces;

    /// <summary>
    /// Default scanner, scans stream as straight text.
    /// </summary>
    public class Default : IDocumentScanner
    {
        private Stream stream;

        public IDocumentScanner LoadStream(Stream stream)
        {
            this.stream = stream;
            return this;
        }

        public string GetText()
        {
            if (this.stream == null)
            {
                throw new NullReferenceException("Stream was not loaded into class");
            }

            var strContent = new StringBuilder();
            using (var sr = new StreamReader(this.stream, Encoding.UTF8))
            {
                strContent.Append(sr.ReadToEnd());
            }

            return strContent.ToString();
        }

        public Match Match(string regEx)
        {
            var textOfFile = this.GetText();
            var match = Regex.Match(textOfFile, regEx);
            return match;
        }

        public MatchCollection Matches(string regEx)
        {
            var text = this.GetText();
            var matches = Regex.Matches(text, regEx);
            return matches;
        }

        public void Dispose()
        {
            if (this.stream != null)
            {
                this.stream.Dispose();
                this.stream = null;
            }
        }
    }
}