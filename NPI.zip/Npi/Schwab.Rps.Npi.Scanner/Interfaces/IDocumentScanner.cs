﻿namespace Schwab.RPS.Npi.Scanner.Interfaces
{
    using System;
    using System.IO;
    using System.Text.RegularExpressions;

    public interface IDocumentScanner : IDisposable
    {
        IDocumentScanner LoadStream(Stream stream);

        string GetText();

        Match Match(string regEx);

        MatchCollection Matches(string regEx);
    }
}