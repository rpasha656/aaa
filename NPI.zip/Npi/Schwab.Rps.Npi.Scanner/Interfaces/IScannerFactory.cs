﻿namespace Schwab.RPS.Npi.Scanner.Interfaces
{
    using Schwab.RPS.Npi.Scanner.Enums;

    public interface IScannerFactory
    {
        ScanMode Mode { get; }

        IDocumentScanner Scanner();
    }
}