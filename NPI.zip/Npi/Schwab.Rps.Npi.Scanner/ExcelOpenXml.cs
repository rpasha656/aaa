﻿namespace Schwab.RPS.Npi.Scanner
{
    using System;
    using System.Data;
    using System.IO;
    using System.Text;
    using System.Text.RegularExpressions;

    using global::Excel;

    using Schwab.RPS.Npi.Scanner.Interfaces;

    public class ExcelOpenXml : IDocumentScanner
    {
        private Stream stream;

        public IDocumentScanner LoadStream(Stream stream)
        {
            this.stream = stream;
            return this;
        }

        private string IterateOverDataSetReturnString(DataSet dataSet)
        {
            var sb = new StringBuilder();
            const string Format = @"({0},{1},{2}): {3}";

            foreach (DataTable table in dataSet.Tables)
            {
                sb.AppendFormat(Environment.NewLine + "*** {0} ***" + Environment.NewLine, table.TableName);

                for (var r = 0; r < table.Rows.Count; r++)
                {
                    for (var c = 0; c < table.Columns.Count; c++)
                    {
                        var obj = table.Rows[r][c];
                        sb.AppendLine(string.Format(Format, table.TableName, r, c, obj));
                    }
                }
            }

            return string.IsNullOrWhiteSpace(sb.ToString()) ? null : sb.ToString();
        }

        public string GetText()
        {
            if (this.stream == null)
            {
                throw new NullReferenceException("Stream was not loaded into class");
            }

            IExcelDataReader excelFactory = null;
            try
            {
                using (excelFactory = ExcelReaderFactory.CreateOpenXmlReader(this.stream))
                {
                    var ds = excelFactory.AsDataSet(true);
                    var result = this.IterateOverDataSetReturnString(ds);
                    if (!excelFactory.IsClosed)
                    {
                        excelFactory.Close();
                    }

                    return result;
                }
            }
            finally
            {
                if (excelFactory != null)
                {
                    excelFactory.Dispose();
                }
            }
        }

        public Match Match(string regEx)
        {
            var text = this.GetText();
            var match = Regex.Match(text, regEx);
            return match;
        }

        public MatchCollection Matches(string regEx)
        {
            var text = this.GetText();
            var matches = Regex.Matches(text, regEx);
            return matches;
        }

        public void Dispose()
        {
            if (this.stream != null)
            {
                this.stream.Dispose();
                this.stream = null;
            }
        }
    }
}