﻿namespace Schwab.RPS.Npi.Scanner.Enums
{
    public enum ScanMode
    {
        Default = 0,

        MicrosoftWordDocument,

        MicrosoftWordXmlDocument,

        MicrosoftExcelDocument,

        MicrosoftExcelXmlDocument,

        MicrosoftPowerPoint,

        MicrosoftOfficeOpenXmlFormat,

        PortableDocumentFormat,

        OpticalCharacterRecognition,

        CompressedArchive,

        RichTextFileFormat
    }
}