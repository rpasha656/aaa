﻿namespace Schwab.RPS.Npi.Scanner
{
    using System;
    using System.IO;
    using System.Text;
    using System.Text.RegularExpressions;

    using iTextSharp.text.pdf;
    using iTextSharp.text.pdf.parser;

    using Schwab.RPS.Npi.Scanner.Interfaces;

    public class Pdf : IDocumentScanner
    {
        private Stream stream;

        public IDocumentScanner LoadStream(Stream stream)
        {
            this.stream = stream;
            return this;
        }

        public string GetText()
        {
            if (this.stream == null)
            {
                throw new NullReferenceException("Stream was not loaded into class");
            }

            var strContent = new StringBuilder();
            var pdfReader = new PdfReader(this.stream);
            var strategy = new SimpleTextExtractionStrategy();
            for (var pg = 1; pg <= pdfReader.NumberOfPages; pg++)
            {
                var currentText = PdfTextExtractor.GetTextFromPage(pdfReader, pg, strategy);

                currentText = Encoding.UTF8.GetString(

                    // ReSharper disable AccessToStaticMemberViaDerivedType
                    ASCIIEncoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(currentText))

                    // ReSharper restore AccessToStaticMemberViaDerivedType
                );

                strContent.Append(currentText);
                pdfReader.Close();
            }

            pdfReader.Close();
            return strContent.ToString();
        }

        public Match Match(string regEx)
        {
            var text = this.GetText();
            var match = Regex.Match(text, regEx);
            return match;
        }

        public MatchCollection Matches(string regEx)
        {
            var text = this.GetText();
            var matches = Regex.Matches(text, regEx);
            return matches;
        }

        public void Dispose()
        {
            if (this.stream != null)
            {
                this.stream.Dispose();
                this.stream = null;
            }
        }
    }
}