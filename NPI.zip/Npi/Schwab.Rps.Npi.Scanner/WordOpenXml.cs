﻿namespace Schwab.RPS.Npi.Scanner
{
    using System;
    using System.IO;
    using System.Text.RegularExpressions;

    using global::Word;

    using Schwab.RPS.Npi.Scanner.Interfaces;

    public class WordOpenXml : IDocumentScanner
    {
        private Stream stream;

        public IDocumentScanner LoadStream(Stream stream)
        {
            this.stream = stream;
            return this;
        }

        public string GetText()
        {
            if (this.stream == null)
            {
                throw new NullReferenceException("Stream was not loaded into class");
            }

            IWordReader wordFactory = null;
            try
            {
                using (wordFactory = WordReaderFactory.CreateOpenXmlReader(this.stream))
                {
                    var result = wordFactory.AsString();
                    return result;
                }
            }
            finally
            {
                if (wordFactory != null)
                {
                    wordFactory.Dispose();
                }
            }
        }

        public Match Match(string regEx)
        {
            var text = this.GetText();
            var match = Regex.Match(text, regEx);
            return match;
        }

        public MatchCollection Matches(string regEx)
        {
            var text = this.GetText();
            var matches = Regex.Matches(text, regEx);
            return matches;
        }

        public void Dispose()
        {
            if (this.stream != null)
            {
                this.stream.Dispose();
                this.stream = null;
            }
        }
    }
}