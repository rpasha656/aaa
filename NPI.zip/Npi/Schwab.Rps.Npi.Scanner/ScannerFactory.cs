﻿namespace Schwab.RPS.Npi.Scanner
{
    using System;
    using System.IO;

    using Schwab.RPS.Npi.Scanner.Enums;
    using Schwab.RPS.Npi.Scanner.Helpers;
    using Schwab.RPS.Npi.Scanner.Interfaces;

    public class ScannerFactory : IScannerFactory, IDisposable
    {
        private readonly FileInfo fileInfo;

        private Stream stream;

        private ScanMode mode;

        public ScannerFactory(string filePath)
        {
            this.fileInfo = new FileInfo(filePath);
            this.stream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            this.DetermineMode();
        }

        public ScannerFactory(string filePath, ScanMode mode)
        {
            this.fileInfo = new FileInfo(filePath);
            this.stream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            this.mode = mode;
        }

        public ScannerFactory(Stream stream, string filePath)
        {
            this.fileInfo = new FileInfo(filePath);
            this.stream = stream;
            this.DetermineMode();
        }

        public ScannerFactory(Stream stream, string filePath, ScanMode mode)
        {
            this.fileInfo = new FileInfo(filePath);
            this.stream = stream;
            this.mode = mode;
        }

        public ScanMode Mode
        {
            get
            {
                return this.mode;
            }
        }

        private void DetermineMode()
        {
            this.FillStream();
            if (this.stream != null)
            {
                this.mode = ModeFinder.GetMode(this.ConvertStream(), this.fileInfo.Name);
            }
        }

        private void FillStream()
        {
            if (this.stream == null)
            {
            }
        }

        private byte[] ConvertStream()
        {
            return this.stream != null ? this.stream.ReadToEnd() : null;
        }

        public void Dispose()
        {
            if (this.stream != null)
            {
                this.stream.Dispose();
                this.stream = null;
            }
        }

        public IDocumentScanner Scanner()
        {
            switch (this.mode)
            {
                case ScanMode.CompressedArchive:
                case ScanMode.MicrosoftOfficeOpenXmlFormat:
                    return new Zip().LoadStream(this.stream);
                case ScanMode.MicrosoftExcelDocument:
                    return new Excel().LoadStream(this.stream);
                case ScanMode.MicrosoftExcelXmlDocument:
                    return new ExcelOpenXml().LoadStream(this.stream);
                case ScanMode.PortableDocumentFormat:
                    return new Pdf().LoadStream(this.stream);
                case ScanMode.MicrosoftWordDocument:
                    return new Word().LoadStream(this.stream);
                case ScanMode.MicrosoftWordXmlDocument:
                    return new WordOpenXml().LoadStream(this.stream);
                case ScanMode.RichTextFileFormat:
                    return new RichTextFile().LoadStream(this.stream);
                default:
                    return new Default().LoadStream(this.stream);
            }
        }
    }
}