﻿namespace Schwab.RPS.Npi.Scanner.Helpers
{
    using System.IO;
    using System.Linq;

    using Schwab.RPS.Npi.Scanner.Enums;

    public static class ModeFinder
    {
        // ReSharper disable InconsistentNaming        
        private static readonly byte[] OFFICEX = { 80, 75, 3, 4, 20, 0, 6, 0 };

        private static readonly byte[] OFFICE = { 208, 207, 17, 224, 161, 177, 26, 225 };

        private static readonly byte[] PDF = { 37, 80, 68, 70 };

        private static readonly byte[] ZIP1 = { 80, 75, 3, 4 };

        private static readonly byte[] ZIP2 = { 80, 75, 5, 6 };

        private static readonly byte[] ZIP3 = { 80, 75, 7, 8 };

        private static readonly byte[] ZIP4 = { 87, 105, 110, 90, 105, 112 };

        private static readonly byte[] RTF = { 123, 92, 114, 116, 102, 49 };

        // image types
        private static readonly byte[] BMP = { 66, 77 };

        private static readonly byte[] GIF = { 71, 73, 70, 56 };

        private static readonly byte[] JPG = { 255, 216, 255 };

        private static readonly byte[] PNG = { 137, 80, 78, 71, 13, 10, 26, 10, 0, 0, 0, 13, 73, 72, 68, 82 };

        private static readonly byte[] TIFF = { 73, 73, 42, 0 };

        // ReSharper restore InconsistentNaming        
        public static ScanMode GetMode(byte[] file, string fileName)
        {
            // Ensure that the filename isn't empty or null
            if (string.IsNullOrWhiteSpace(fileName))
            {
                return ScanMode.Default;
            }

            // Get the file extension
            var extension = Path.GetExtension(fileName) == null ? string.Empty : Path.GetExtension(fileName).ToUpper();

            if (file.Take(8).SequenceEqual(OFFICE))
            {
                switch (extension)
                {
                    case ".DOC":
                        return ScanMode.MicrosoftWordDocument;
                    case ".XLS":
                        return ScanMode.MicrosoftExcelDocument;
                    default:
                        return ScanMode.Default;
                }
            }

            if (file.Take(8).SequenceEqual(OFFICEX))
            {
                switch (extension)
                {
                    case ".XLSX":
                        return ScanMode.MicrosoftExcelXmlDocument;
                    case ".DOCX":
                        return ScanMode.MicrosoftWordXmlDocument;
                    default:
                        return ScanMode.MicrosoftOfficeOpenXmlFormat;
                }
            }

            if (file.Take(6).SequenceEqual(RTF))
            {
                return ScanMode.RichTextFileFormat;
            }

            if (file.Take(4).SequenceEqual(PDF))
            {
                return ScanMode.PortableDocumentFormat;
            }

            if (file.Take(4).SequenceEqual(ZIP1) || file.Take(4).SequenceEqual(ZIP2) || file.Take(4).SequenceEqual(ZIP3)
                || file.Take(6).SequenceEqual(ZIP4))
            {
                return ScanMode.CompressedArchive;
            }

            if (file.Take(2).SequenceEqual(BMP) || file.Take(4).SequenceEqual(GIF) || file.Take(3).SequenceEqual(JPG)
                || file.Take(4).SequenceEqual(TIFF) || file.Take(16).SequenceEqual(PNG))
            {
                return ScanMode.OpticalCharacterRecognition;
            }

            return ScanMode.Default;
        }
    }
}