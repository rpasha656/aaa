﻿namespace Schwab.RPS.Npi.Scanner
{
    using System;
    using System.IO;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Xml;

    using Ionic.Zip;

    using Schwab.RPS.Npi.Scanner.Interfaces;

    public class Zip : IDocumentScanner
    {
        private Stream stream;

        public IDocumentScanner LoadStream(Stream stream)
        {
            this.stream = stream;
            return this;
        }

        public string GetText()
        {
            if (this.stream == null)
            {
                throw new NullReferenceException("Stream was not loaded into class");
            }

            var strContent = new StringBuilder();
            using (var zipFile = ZipFile.Read(this.stream))
            {
                foreach (var file in zipFile)
                {
                    var str = new MemoryStream();
                    var fileInfo = new FileInfo(file.FileName);
                    file.Extract(str);
                    str.Seek(0, SeekOrigin.Begin);
                    if (fileInfo.Extension.ToUpper().Equals(".XML"))
                    {
                        try
                        {
                            var xDoc = new XmlDocument();
                            xDoc.Load(str);
                            using (var sw = new StringWriter())
                            {
                                using (var xtw = XmlWriter.Create(sw))
                                {
                                    xDoc.WriteTo(xtw);
                                    xtw.Flush();
                                    strContent.AppendLine(sw.GetStringBuilder().ToString());
                                }
                            }
                        }
                        catch
                        {
                        }
                    }
                    else
                    {
                        try
                        {
                            using (var sr = new StreamReader(str, Encoding.UTF8))
                            {
                                strContent.Append(sr.ReadToEnd());
                            }
                        }
                        catch
                        {
                        }
                    }

                    str.Dispose();
                }

                zipFile.Dispose();
            }

            return strContent.ToString();
        }

        public Match Match(string regEx)
        {
            var text = this.GetText();
            var match = Regex.Match(text, regEx);
            return match;
        }

        public MatchCollection Matches(string regEx)
        {
            var text = this.GetText();
            var matches = Regex.Matches(text, regEx);
            return matches;
        }

        public void Dispose()
        {
            if (this.stream != null)
            {
                this.stream.Dispose();
                this.stream = null;
            }
        }
    }
}