﻿namespace Schwab.RPS.Npi.Scanner
{
    using System;
    using System.IO;
    using System.Text.RegularExpressions;

    using global::Word;

    using Schwab.RPS.Npi.Scanner.Interfaces;

    public class Word : IDocumentScanner
    {
        private Stream stream;

        public IDocumentScanner LoadStream(Stream stream)
        {
            this.stream = stream;
            return this;
        }

        public string GetText()
        {
            if (this.stream == null)
            {
                throw new NullReferenceException("Stream was not loaded into class");
            }

            using (var wordFactory = WordReaderFactory.CreateBinaryReader(this.stream))
            {
                return wordFactory.AsString();
            }
        }

        public Match Match(string regEx)
        {
            var text = this.GetText();
            var match = Regex.Match(text, regEx);
            return match;
        }

        public MatchCollection Matches(string regEx)
        {
            var text = this.GetText();
            var matches = Regex.Matches(text, regEx);
            return matches;
        }

        public void Dispose()
        {
            if (this.stream != null)
            {
                this.stream.Dispose();
                this.stream = null;
            }
        }
    }
}