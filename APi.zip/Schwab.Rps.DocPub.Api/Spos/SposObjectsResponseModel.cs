﻿//using System;
//using System.ComponentModel;
//using System.Xml.Serialization;

//namespace Schwab.Rps.DocPub.Api.Spos
//{
//    /// <remarks />
//    [Serializable]
//    [DesignerCategory("code")]
//    [XmlType(AnonymousType = true, Namespace = "http://s3.amazonaws.com/doc/2006-03-01/")]
//    [XmlRoot(Namespace = "http://s3.amazonaws.com/doc/2006-03-01/", IsNullable = false)]
//    public class ListBucketResult
//    {
//        private ListBucketResultContents[] _contentsField;

//        private bool _isTruncatedField;

//        private object _markerField;

//        private ushort _maxKeysField;
//        private string _nameField;

//        private object _prefixField;

//        /// <remarks />
//        public string Name
//        {
//            get { return this._nameField; }
//            set { this._nameField = value; }
//        }

//        /// <remarks />
//        public object Prefix
//        {
//            get { return this._prefixField; }
//            set { this._prefixField = value; }
//        }

//        /// <remarks />
//        public object Marker
//        {
//            get { return this._markerField; }
//            set { this._markerField = value; }
//        }

//        /// <remarks />
//        public ushort MaxKeys
//        {
//            get { return this._maxKeysField; }
//            set { this._maxKeysField = value; }
//        }

//        /// <remarks />
//        public bool IsTruncated
//        {
//            get { return this._isTruncatedField; }
//            set { this._isTruncatedField = value; }
//        }

//        /// <remarks />
//        [XmlElement("Contents")]
//        public ListBucketResultContents[] Contents
//        {
//            get { return this._contentsField; }
//            set { this._contentsField = value; }
//        }
//    }

//    /// <remarks />
//    [Serializable]
//    [DesignerCategory("code")]
//    [XmlType(AnonymousType = true, Namespace = "http://s3.amazonaws.com/doc/2006-03-01/")]
//    public class ListBucketResultContents
//    {
//        private string _eTagField;
//        private string _keyField;

//        private DateTime _lastModifiedField;

//        private ListBucketResultContentsOwner _ownerField;

//        private uint _sizeField;

//        private string _storageClassField;

//        /// <remarks />
//        public string Key
//        {
//            get { return this._keyField; }
//            set { this._keyField = value; }
//        }

//        /// <remarks />
//        public DateTime LastModified
//        {
//            get { return this._lastModifiedField; }
//            set { this._lastModifiedField = value; }
//        }

//        /// <remarks />
//        public string ETag
//        {
//            get { return this._eTagField; }
//            set { this._eTagField = value; }
//        }

//        /// <remarks />
//        public uint Size
//        {
//            get { return this._sizeField; }
//            set { this._sizeField = value; }
//        }

//        /// <remarks />
//        public string StorageClass
//        {
//            get { return this._storageClassField; }
//            set { this._storageClassField = value; }
//        }

//        /// <remarks />
//        public ListBucketResultContentsOwner Owner
//        {
//            get { return this._ownerField; }
//            set { this._ownerField = value; }
//        }
//    }

//    /// <remarks />
//    [Serializable]
//    [DesignerCategory("code")]
//    [XmlType(AnonymousType = true, Namespace = "http://s3.amazonaws.com/doc/2006-03-01/")]
//    public class ListBucketResultContentsOwner
//    {
//        private string _displayNameField;
//        private string _idField;

//        /// <remarks />
//        public string Id
//        {
//            get { return this._idField; }
//            set { this._idField = value; }
//        }

//        /// <remarks />
//        public string DisplayName
//        {
//            get { return this._displayNameField; }
//            set { this._displayNameField = value; }
//        }
//    }
//}