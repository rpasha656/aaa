﻿//using System.Collections.Generic;
//using System.Configuration;
//using System.IO;
//using System.IO.Compression;
//using System.Net.Http;
//using System.Threading.Tasks;
//using log4net;
//using Schwab.Wcfim.ServiceModel;
//using Schwab.Wcfim.WebApi;

//namespace Schwab.Rps.DocPub.Api.Spos
//{
//    public class SposDao : ISposDao
//    {
//        /// <summary>
//        /// The logger
//        /// </summary>
//        private readonly ILog _logger;

//        /// <summary>
//        /// The SPOS bucket
//        /// </summary>
//        private readonly string _bucket;

//        /// <summary>
//        /// The HttClient used to access SPOS
//        /// </summary>
//        private readonly HttpClient _client;

//        /// <summary>
//        /// Initializes a new instance of the <see cref="SposDao"/> class.
//        /// </summary>
//        public SposDao()
//        {
//            var serviceKey = ConfigurationManager.AppSettings["SPOS.ServiceKey"];
//            var portName = ConfigurationManager.AppSettings["SPOS.PortName"];
//            this._bucket = ConfigurationManager.AppSettings["SPOS.Bucket"];
//            this._client = HttpServiceFactoryManager.HttpServiceFactory.GetService<HttpClient>(serviceKey, portName);
//            this._logger = LogManager.GetLogger(typeof(SposDao));
//        }

//        /// <summary>
//        /// Constructor for testing purposes
//        /// </summary>
//        /// <param name="serviceKey">The service key string.</param>
//        /// <param name="portName">The service port name.</param>
//        /// <param name="bucket">The default bucket name.</param>
//        /// <param name="logger">The logger class</param>
//        public SposDao(string serviceKey, string portName, string bucket, ILog logger)
//        {
//            this._bucket = bucket;
//            this._client = HttpServiceFactoryManager.HttpServiceFactory.GetService<HttpClient>(serviceKey, portName);
//            this._logger = logger;
//        }

//        /// <summary>
//        /// Checks to see if the bucket that was set during construction is valid
//        /// </summary>
//        /// <returns>Returns true if exists, false if not</returns>
//        public Task<HttpResponseMessage> CheckForBucket()
//        {
//            using (ClientOperationContextScope ctxScope = new HttpClientOperationContextScope(this._client))
//            {
//                var ctx = ctxScope.Context;
//                // Manifest list for the SCHMS1 token (must be in this order)
//                ctx.Schms1Manifest = new List<string>
//                {
//                    "$verb",
//                    "$uri",
//                    "SCHMS1-Timestamp"
//                };
//                var sposUriPath = this._bucket;
//                // Create a new HttpRequestMessage with the HEAD method
//                var httpRequestMessage = new HttpRequestMessage(HttpMethod.Head, sposUriPath);
//                return this._client.SendAsync(httpRequestMessage);
//            }
//        }

//        /// <summary>
//        /// Checks for an object in SPOS using a key value
//        /// </summary>
//        /// <param name="key">The key name for the object</param>
//        /// <returns>Returns true if found, false if not found</returns>
//        public bool CheckForObject(string key)
//        {
//            using (ClientOperationContextScope ctxScope = new HttpClientOperationContextScope(this._client))
//            {
//                var ctx = ctxScope.Context;
//                // Manifest list for the SCHMS1 token (must be in this order)
//                ctx.Schms1Manifest = new List<string>
//                {
//                    "$verb",
//                    "$uri",
//                    "SCHMS1-Timestamp"
//                };
//                var sposUriPath = $"{this._bucket}/{key}";

//                using (var response = this._client.GetAsync(sposUriPath).Result)
//                {
//                    if (!response.IsSuccessStatusCode)
//                    {
//                        this._logger.Info($"Error checking for object in SPOS. Status Code: {response.StatusCode}. Object id: {key}");
//                        return false;
//                    }
//                    return true;
//                }
//            }
//        }

//        /// <summary>
//        /// Deletes a document from SPOS that corresponds to the provided key
//        /// </summary>
//        /// <param name="sposObjectFolderPath">The folder path to the object</param>
//        /// <param name="sposObjectKey">the object key</param>
//        public Task<HttpResponseMessage> DeleteDocumentFromSpos(string sposObjectFolderPath, string sposObjectKey)
//        {
//            using (ClientOperationContextScope ctxScope = new HttpClientOperationContextScope(this._client))
//            {
//                var ctx = ctxScope.Context;
//                // Manifest list for the SCHMS1 token (must be in this order)
//                IList<string> manifest = new List<string>
//                {
//                    "$verb",
//                    "$uri",
//                    "SCHMS1-Timestamp"
//                };
//                ctx.Schms1Manifest = manifest;
//                var sposUriPath = this._bucket + "/" + sposObjectFolderPath + sposObjectKey;
//                return this._client.DeleteAsync(sposUriPath);
//            }
//        }

//        /// <summary>
//        /// Reads the object from SPOS for the provided folder path and key and writes it to local disk for the provided file location
//        /// </summary>
//        /// <param name="sposObjectFolderPath">The folder path to the object</param>
//        /// <param name="sposObjectKey">the object key</param>
//        public Task<HttpResponseMessage> ReadDocumentFromSpos(string sposObjectFolderPath, string sposObjectKey)
//        {
//            using (ClientOperationContextScope ctxScope = new HttpClientOperationContextScope(this._client))
//            {
//                var ctx = ctxScope.Context;
//                // Manifest list for the SCHMS1 token (must be in this order)
//                ctx.Schms1Manifest = new List<string>
//                {
//                    "$verb",
//                    "$uri",
//                    "SCHMS1-Timestamp"
//                };
//                var sposUriPath = this._bucket + "/" + sposObjectFolderPath + sposObjectKey;
//                return this._client.GetAsync(sposUriPath);
//            }
//        }

//        /// <summary>
//        /// Retrieves the keys for the objects in bucket.
//        /// </summary>
//        /// <param name="maxKeys">The maximum number of keys to return. Defaults to 10.</param>
//        /// <param name="prefix">Returns only keys that start with this string. Defaults to empty string.</param>
//        /// <param name="marker">The object id to start the return list. Used for truncated lists. Defaults to empty string.</param>
//        public Task<HttpResponseMessage> RetrieveListOfObjects(int maxKeys = 10, string prefix = "", string marker = "")
//        {
//            using (ClientOperationContextScope ctxScope = new HttpClientOperationContextScope(this._client))
//            {
//                var ctx = ctxScope.Context;
//                // Manifest list for the SCHMS1 token (must be in this order)
//                ctx.Schms1Manifest = new List<string>
//                {
//                    "$verb",
//                    "$uri",
//                    "SCHMS1-Timestamp"
//                };
//                var sposUriPath = $"{this._bucket}/?prefix={prefix}&maxkeys={maxKeys}&marker={marker}";
//                return this._client.GetAsync(sposUriPath);
//            }
//        }

//        /// <summary>
//        /// When writing large files to spos, it makes sense to zip them first, using a streamable 
//        /// utility class like GZipStream
//        /// </summary>
//        /// <param name="sposObjectFolderPath">The subfolder in your SPOS bucket</param>
//        /// <param name="sposObjectKey">The key for the document</param>
//        /// <param name="file">A FileStream object to read from</param>
//        public Task<HttpResponseMessage> WriteBigDocumentToSpos(string sposObjectFolderPath, string sposObjectKey, Stream file)
//        {
//            using (ClientOperationContextScope ctxScope = new HttpClientOperationContextScope(this._client))
//            {
//                var ctx = ctxScope.Context;
//                // Manifest list for the SCHMS1 token (must be in this order)
//                ctx.Schms1Manifest = new List<string>
//                {
//                    "$verb",
//                    "$uri",
//                    "SCHMS1-Timestamp"
//                };
//                // A memory stream is required to generate the compress the data
//                using (var ms = new MemoryStream())
//                {
//                    //Compress the file using GZIPStream to MemoryStream
//                    using (var zips = new GZipStream(ms, CompressionMode.Compress, true))
//                    {
//                        //Read the bytes from the file stream to the GZipStream
//                        using (file)
//                        {
//                            file.CopyTo(zips);
//                        }
//                    }
//                    ms.Seek(0, SeekOrigin.Begin);
//                    var sposUriPath = this._bucket + "/" + sposObjectFolderPath + sposObjectKey;
//                    return this._client.PutAsync(sposUriPath, new StreamContent(ms));
//                }
//            }
//        }

//        /// <summary>
//        /// Writes a file from disk to SPOS
//        /// </summary>
//        /// <param name="sposObjectFolderPath">The folder path to the object</param>
//        /// <param name="sposObjectKey">the object key</param>
//        /// <param name="file"></param>
//        public Task<HttpResponseMessage> WriteDocumentToSpos(string sposObjectFolderPath, string sposObjectKey, Stream file)
//        {
//            using (ClientOperationContextScope ctxScope = new HttpClientOperationContextScope(this._client))
//            {
//                var ctx = ctxScope.Context;
//                // Manifest list for the SCHMS1 token (must be in this order)
//                IList<string> manifest = new List<string>
//                {
//                    "$verb",
//                    "$uri",
//                    "SCHMS1-Timestamp"
//                };
//                ctx.Schms1Manifest = manifest;
//                var sposUriPath = this._bucket + "/" + sposObjectFolderPath + sposObjectKey;
//                return this._client.PutAsync(sposUriPath, new StreamContent(file));
//            }
//        }
//    }
//}