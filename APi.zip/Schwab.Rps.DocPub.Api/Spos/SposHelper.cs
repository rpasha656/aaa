﻿//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Xml.Serialization;
//using log4net;

//namespace Schwab.Rps.DocPub.Api.Spos
//{
//    public class SposHelper
//    {
//        public SposHelper(ILog logger, ISposDao sposDao, string sposFolder)
//        {
//            this._logger = logger;
//            this._sposDao = sposDao;
//            this._sposFolder = sposFolder;
//        }

//        public SposHelper()
//        {
//            this._logger = LogManager.GetLogger(typeof(SposHelper));
//            this._sposDao = new SposDao();
//            // The folder in SPOS to store the document... Can be blank to store at root
//            this._sposFolder = "";
//            //this._sposFolder = "docPub/";
//        }

//        private readonly string _sposFolder;

//        private readonly ILog _logger;

//        private readonly ISposDao _sposDao;

//        /// <summary>
//        /// Check for Bucket: 
//        /// https://confluence.schwab.com/display/METS/SPOS+API+Guide#SPOSAPIGuide-CheckforBucket
//        /// </summary>
//        public async Task CheckForBucket()
//        {
//            this._logger.Info("Checking if bucket exists...");
//            using (var response = await this._sposDao.CheckForBucket())
//            {
//                if (response.IsSuccessStatusCode)
//                {
//                    this._logger.Info("Bucket exists!");
//                }
//                else
//                {
//                    this._logger.Info($"Error getting bucket data from SPOS. Status Code: {response.StatusCode}");
//                    throw new Exception("SPOS Error! Response code" + response.StatusCode);
//                }
//            }
//        }

//        /// <summary>
//        /// Retrieve List of Objects:
//        /// https://confluence.schwab.com/display/METS/SPOS+API+Guide#SPOSAPIGuide-RetrieveListofObjects
//        /// </summary>
//        public async Task<ListBucketResultContents[]> RetrieveListOfObjects()
//        {
//            this._logger.Info("Getting list of objects from bucket");
//            // *Note can only retrieve max of 1000 results. See RetrieveFullListOfKeys for  of getting all objects
//            using (var response = await this._sposDao.RetrieveListOfObjects(5))
//            {
//                if (!response.IsSuccessStatusCode)
//                {
//                    this._logger.Info($"Error getting list of objects from SPOS. Status Code: {response.StatusCode}");
//                    throw new Exception("SPOS Error! Response code" + response.StatusCode);
//                }

//                var result = await response.Content.ReadAsStringAsync();
//                var serializer = new XmlSerializer(typeof(ListBucketResult));
//                ListBucketResult objectsResponse;
//                using (var memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(result)))
//                {
//                    objectsResponse = (ListBucketResult) serializer.Deserialize(memoryStream);
//                    memoryStream.Close();
//                }

//                return objectsResponse.Contents;

//                //foreach (var sposObject in objectsResponse.Contents)
//                //{
//                //    _logger.Info(sposObject.Key);
//                //}
//            }
//        }

//        /// <summary>
//        /// Insert Object:
//        /// https://confluence.schwab.com/display/METS/SPOS+API+Guide#SPOSAPIGuide-InsertObject
//        /// </summary>
//        /// <param name="docName">Key to provide SPOS</param>
//        /// <param name="fileLocation">Location on computer to get file to put in SPOS</param>
//        public async void WriteDocumentToSpos(string docName, string fileLocation)
//        {
//            var fileStream = new FileStream(fileLocation, FileMode.Open);
//            await this.WriteDocumentToSpos(docName, fileStream);
//        }

//        /// <summary>
//        /// Insert Object:
//        /// https://confluence.schwab.com/display/METS/SPOS+API+Guide#SPOSAPIGuide-InsertObject
//        /// </summary>
//        /// <param name="docName">Key to provide SPOS</param>
//        /// <param name="stream">The stream to put in SPOS</param>
//        public async Task<bool> WriteDocumentToSpos(string docName, Stream stream )
//        {
//            this._logger.Info("Writing document to SPOS...");
//            using (var response = await this._sposDao.WriteDocumentToSpos(this._sposFolder, docName, stream))
//            {
//                this._logger.Info(response.IsSuccessStatusCode
//                    ? "Successfully wrote file to SPOS!"
//                    : $"Error getting bucket data from SPOS. Status Code: {response.StatusCode}");

//                return response.IsSuccessStatusCode;
//            }
//        }


//        /// <summary>
//        /// Insert Object:
//        /// https://confluence.schwab.com/display/METS/SPOS+API+Guide#SPOSAPIGuide-InsertObject
//        /// </summary>
//        /// <param name="docName">Key to provide SPOS</param>
//        /// <param name="fileLocation">Location on computer to get file to put in SPOS</param>
//        public async Task WriteLargeDocumentToSpos(string docName, string fileLocation)
//        {
//            this._logger.Info("Writing large document to SPOS...");
//            var file = new FileStream(fileLocation, FileMode.Open);
//            using (var response = await this._sposDao.WriteBigDocumentToSpos(this._sposFolder, docName, file))
//            {
//                this._logger.Info(response.IsSuccessStatusCode
//                    ? "Successfully wrote file to SPOS!"
//                    : $"Error getting bucket data from SPOS. Status Code: {response.StatusCode}");
//            }
//        }

//        /// <summary>
//        /// Read Object:
//        /// https://confluence.schwab.com/display/METS/SPOS+API+Guide#SPOSAPIGuide-RetrieveObject
//        /// </summary>
//        /// <param name="docName">Key to provide SPOS</param>
//        public async Task<byte[]> ReadDocumentFromSpos(string docName)
//        {
//            this._logger.Info("Reading document from SPOS...");
//            using (var response = await this._sposDao.ReadDocumentFromSpos(this._sposFolder, docName))
//            {
//                if (!response.IsSuccessStatusCode)
//                {
//                    this._logger.Info($"Error reading data from SPOS. Status Code: {response.StatusCode}, Key: {docName}");
//                    return new byte[] {};
//                }

//                return response.Content.ReadAsByteArrayAsync().Result;
//            }
//        }

//        /// <summary>
//        /// Read Object:
//        /// https://confluence.schwab.com/display/METS/SPOS+API+Guide#SPOSAPIGuide-RetrieveObject
//        /// </summary>
//        /// <param name="docName">Key to provide SPOS</param>
//        /// <param name="fileLocation">Location on computer to write the file received from SPOS</param>
//        public async Task ReadDocumentFromSpos(string docName, string fileLocation)
//        {
//            this._logger.Info("Reading document from SPOS...");
//            using (var response = await this._sposDao.ReadDocumentFromSpos(this._sposFolder, docName))
//            {
//                if (!response.IsSuccessStatusCode)
//                {
//                    this._logger.Info($"Error reading data from SPOS. Status Code: {response.StatusCode}, Key: {docName}");
//                    return;
//                }
//                Stream responseStream = response.Content.ReadAsStreamAsync().Result;
//                using (var output = File.OpenWrite(fileLocation + docName))
//                {
//                    responseStream.CopyTo(output);
//                }
//                this._logger.Info($"Successfully read an object from SPOS. Key: {docName}");
//            }
//        }

//        /// <summary>
//        /// Delete Object:
//        /// https://confluence.schwab.com/display/METS/SPOS+API+Guide#SPOSAPIGuide-DeleteObject
//        /// </summary>
//        /// <param name="docName">Key to provide SPOS</param>
//        public async Task DeleteDocumentFromSpos(string docName)
//        {
//            this._logger.Info("Deleting document from SPOS...");
//            using (var response = await this._sposDao.DeleteDocumentFromSpos(this._sposFolder, docName))
//            {
//                if (!response.IsSuccessStatusCode)
//                {
//                    this._logger.Info($"Error Deleting data from SPOS. Status Code: {response.StatusCode}, Key: {docName}");
//                    return;
//                }
//                this._logger.Info($"Successfully Deleted object from SPOS. Key: {docName}");
//            }
//        }

//        /// <summary>
//        /// Deletes all objects from the provided folder
//        /// </summary>
//        public async Task DeleteAllObjectsFromSpos()
//        {
//            this._logger.Info("Deleting all document from SPOS and folder: ...");
//            // Gather list of keys to delete
//            var keys = await this.RetrieveFullListOfKeys();
//            if (keys.Count == 0)
//            {
//                this._logger.Info("No objects to delete");
//                return;
//            }
//            // Delete all keys
//            foreach (var key in keys)
//            {
//                var deleteResponse = await this._sposDao.DeleteDocumentFromSpos(this._sposFolder, key);
//                if (!deleteResponse.IsSuccessStatusCode)
//                {
//                    this._logger.Info($"Error Deleting key {key}");
//                }
//            }
//            this._logger.Info($"Finished Deleting {keys.Count} keys");
//        }

//        /// <summary>
//        /// Gathers a list of keys from the provided folder in SPOS
//        /// </summary>
//        /// <returns>A full List of SPOS that were retrieved from SPOS</returns>
//        public async Task<List<string>> RetrieveFullListOfKeys()
//        {
//            // Get first set of keys
//            var getObjectsResponse = new List<ListBucketResult>();
//            var getObjResp = await this.GetListBucketResult(this._sposFolder, string.Empty);
//            getObjectsResponse.Add(getObjResp);

//            // Are there more keys to retrieve?
//            // SPOS can only return a max of 1000 keys per call
//            var containsMoreKeys = getObjResp.IsTruncated;
//            // marker tells SPOS where to start the next list of keys to return
//            var marker = getObjResp.Contents[getObjResp.Contents.Length - 1].Key;
            
//            // keep calling SPOS until we get the full list of keys
//            while (containsMoreKeys)
//            {
//                var getMoreObjResp = await this.GetListBucketResult(this._sposFolder, marker);
//                getObjectsResponse.Add(getMoreObjResp);
//                containsMoreKeys = getMoreObjResp.IsTruncated;
//                if (containsMoreKeys)
//                {
//                    marker = getMoreObjResp.Contents[getMoreObjResp.Contents.Length - 1].Key;
//                }
//            }

//            // Get just the keys from the combined responses 
//            var contents = getObjectsResponse.SelectMany(listBucketResult => listBucketResult.Contents).ToList();
//            var keys = contents.Select(content => content.Key).ToList();
//            // remove all folders
//            keys.RemoveAll(key => key.EndsWith("/"));
//            return keys;
//        }

//        /// <summary>
//        /// Retrieves a ListBucketResult for a single call to SPOS
//        /// </summary>
//        /// <param name="prefix">The "folder" to retrieve the keys from</param>
//        /// <param name="marker">The marker if retrieving from a truncated List</param>
//        /// <returns></returns>
//        public async Task<ListBucketResult> GetListBucketResult(string prefix, string marker)
//        {
//            using (var response = await this._sposDao.RetrieveListOfObjects(1000, prefix, marker))
//            {
//                if (!response.IsSuccessStatusCode)
//                {
//                    throw new Exception("Bad response form SPOS! HTTP Status Code " + response.StatusCode);
//                }
//                var result = response.Content.ReadAsStringAsync().Result;
//                var serializer = new XmlSerializer(typeof(ListBucketResult));
//                using (var memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(result)))
//                {
//                    var objectsRespnse = (ListBucketResult) serializer.Deserialize(memoryStream);
//                    memoryStream.Close();
//                    return objectsRespnse;
//                }
//            }
//        }
//    }
//}