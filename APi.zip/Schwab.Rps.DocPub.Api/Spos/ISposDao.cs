//using System.IO;
//using System.Net.Http;
//using System.Threading.Tasks;

//namespace Schwab.Rps.DocPub.Api.Spos
//{
//    public interface ISposDao
//    {
//        /// <summary>
//        /// Checks to see if the bucket that was set during construction is valid
//        /// </summary>
//        /// <returns>Returns true if exists, false if not</returns>
//        Task<HttpResponseMessage> CheckForBucket();

//        /// <summary>
//        /// Checks for an object in SPOS using a key value
//        /// </summary>
//        /// <param name="key">The key name for the object</param>
//        /// <returns>Returns true if found, false if not found</returns>
//        bool CheckForObject(string key);

//        /// <summary>
//        /// Deletes a document from SPOS that corresponds to the provided key
//        /// </summary>
//        /// <param name="sposObjectFolderPath">The folder path to the object</param>
//        /// <param name="sposObjectKey">the object key</param>
//        Task<HttpResponseMessage> DeleteDocumentFromSpos(string sposObjectFolderPath, string sposObjectKey);

//        /// <summary>
//        /// Reads the object from SPOS for the provided folder path and key and writes it to local disk for the provided file location
//        /// </summary>
//        /// <param name="sposObjectFolderPath">The folder path to the object</param>
//        /// <param name="sposObjectKey">the object key</param>
//        Task<HttpResponseMessage> ReadDocumentFromSpos(string sposObjectFolderPath, string sposObjectKey);

//        /// <summary>
//        /// Retrieves the keys for the objects in bucket.
//        /// </summary>
//        /// <param name="maxKeys">The maximum number of keys to return. Defaults to 10.</param>
//        /// <param name="prefix">Returns only keys that start with this string. Defaults to empty string.</param>
//        /// <param name="marker">The object id to start the return list. Used for truncated lists. Defaults to empty string.</param>
//        Task<HttpResponseMessage> RetrieveListOfObjects(int maxKeys = 10, string prefix = "", string marker = "");

//        /// <summary>
//        /// When writing large files to spos, it makes sense to zip them first, using a streamable 
//        /// utility class like GZipStream
//        /// </summary>
//        /// <param name="sposObjectFolderPath">The subfolder in your SPOS bucket</param>
//        /// <param name="sposObjectKey">The key for the document</param>
//        /// <param name="file">A FileStream object to read from</param>
//        Task<HttpResponseMessage> WriteBigDocumentToSpos(string sposObjectFolderPath, string sposObjectKey, Stream file);

//        /// <summary>
//        /// Writes a file from disk to SPOS
//        /// </summary>
//        /// <param name="sposObjectFolderPath">The folder path to the object</param>
//        /// <param name="sposObjectKey">the object key</param>
//        /// <param name="file"></param>
//        Task<HttpResponseMessage> WriteDocumentToSpos(string sposObjectFolderPath, string sposObjectKey, Stream file);
//    }
//}