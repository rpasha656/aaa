﻿
namespace Schwab.Rps.DocPub.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using DocPubServiceReference;
    using System.Web.Http;
    using Newtonsoft.Json;
    using Microsoft.Practices.ServiceLocation;
    using Microsoft.Practices.Unity;
    using System.Net.Http;
    using System.Net;

    /// <summary>
    /// Categories Controller
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.Controller" />   
    [RoutePrefix("api/Categories")]
    public class CategoriesController : ApiController
    {
        /// <summary>
        /// The logger
        /// </summary>
        //private readonly ILogger _logger;


        /// <summary>
        /// The memory cache.
        /// </summary>
        //private readonly IMemoryCache _memoryCache;

        /// <summary>
        /// Initializes a new instance of the <see cref="CategoriesController"/> class.
        /// </summary>
        /// <param name="fileMetadata">
        /// The file metadata.
        /// </param>
        /// <param name="logger">
        /// The logger.
        /// </param>
        /// <param name="memCache">
        /// The mem Cache.
        /// </param>
        //public CategoriesController(IFileMetadata fileMetadata, ILoggingService logger, IMemoryCache memCache)
        //{
        //    this.FileMetadata = fileMetadata;
        //    this._logger = logger;
        //    this._memoryCache = memCache;
        //}

        /// <summary>
        /// The Category Operation Name.
        /// </summary>
        public enum CategoryOperationName
        {
            /// <summary>
            /// Added
            /// </summary>
            CategoryAdded = 200,

            /// <summary>
            /// Updated
            /// </summary>
            CategoryUpdated = 201,

            /// <summary>
            /// Deleted
            /// </summary>
            CategoryDeleted = 202
        }

        /// <summary>
        /// The Sub Category Operation Name.
        /// </summary>
        public enum SubCategoryOperationName
        {
            /// <summary>
            /// Added
            /// </summary>
            SubCategoryAdded= 300,

            /// <summary>
            /// Updated
            /// </summary>
            SubCategoryUpdated = 301,

            /// <summary>
            /// Deleted
            /// </summary>
            SubCategoryDeleted = 302
        }

        /// <summary>
        /// Gets or sets the add file metadata.
        /// </summary>
        /// <value>
        /// The add file metadata.
        /// </value>
        public IFileMetadata FileMetadata { get; set; }

        /// <summary>
        /// Gets all Categories and SubCategories.
        /// </summary>    
        /// <returns>Categories and SubCategories in Json format</returns>
        //[HttpGet]
        [Route("")]
        public IHttpActionResult Get()
        {
            try
            {
                IFileMetadata fileMetadata = new FileMetadataClient();               

                //_logger.Info("Calling the FileMetadata method to get all Categories and SubCategories");                

                var getCategories = fileMetadata.GetCategoriesAsync();
                ////var getCategories = this.SetGetCategoriesMemoryCache();
                var categories = getCategories.Result;

                if (!categories.Any())
                {
                    return BadRequest();                   
                }

                //_logger.Info("Categories and SubCategories records have been fetched");
                return Ok(categories);           
               
            }
            catch (Exception ex)
            {
                //_logger.Error(ex.Message);
                return StatusCode(HttpStatusCode.InternalServerError);
            }    
        }

        [HttpPost]
        [Route("")]
        public IHttpActionResult Post([FromBody] CategoryDataContract categoryDataContract)
        {
            IFileMetadata fileMetadata = new FileMetadataClient();
            //this._logger.Info("Calling the Category method");

            if (categoryDataContract == null)
            {
                //this._logger.Error("Empty CategoryDataContract object");
                return this.BadRequest();
            }

            try
            {
                var result = fileMetadata.AddUpdateCategoryAsync(categoryDataContract).Result;
                if (result < 0)
                {
                    //this._logger.Info("Record has not been added into category");
                    return this.BadRequest();
                }
                                
                Audit("Category Id: ", categoryDataContract.Id, fileMetadata,result, categoryDataContract.IsActive);

                //this._logger.Info("Record has been added into Category");
                return this.Ok(result);

            }
            catch (Exception ex)
            {
                //this._logger.Error(ex.Message);
                return this.StatusCode(HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("{categoryId}/subcategories")] 
        public IHttpActionResult Post(int categoryId, [FromBody] SubCategoryWebApiDataContract subCategoryWebApiDataContract)
        {
            if (subCategoryWebApiDataContract == null || categoryId <= 0)
            {
                //this._logger.Error("Empty SubCategoryDataContract object");
                return this.BadRequest();
            }

            return AddUpdateSubCategories(categoryId, subCategoryWebApiDataContract, 0);
        }

        [HttpPost]
        [Route("{categoryId}/subcategories/{subCategoryId}")]
        public IHttpActionResult Post(int categoryId, [FromBody] SubCategoryWebApiDataContract subCategoryWebApiDataContract, int subCategoryId)
        {
            if (subCategoryWebApiDataContract == null || categoryId <= 0 || subCategoryId <= 0)
            {
                //this._logger.Error("Empty SubCategoryDataContract object");
                return this.BadRequest();
            }

            return AddUpdateSubCategories(categoryId, subCategoryWebApiDataContract, subCategoryId);
        }

        public IHttpActionResult AddUpdateSubCategories(int categoryId, [FromBody] SubCategoryWebApiDataContract subCategoryWebApiDataContract,  int subCategoryId)
        {
            IFileMetadata fileMetadata = new FileMetadataClient();
            SubCategoryDataContract subCategoryDataContract = new SubCategoryDataContract();

            //this._logger.Info("Calling the SubCategory method");         

            try
            {
                subCategoryDataContract.CategoryId = categoryId;
                if (subCategoryId>0) subCategoryDataContract.Id = subCategoryId;
                subCategoryDataContract.Name = subCategoryWebApiDataContract.Name;
                subCategoryDataContract.CreatedBy = subCategoryWebApiDataContract.CreatedBy;
                subCategoryDataContract.Description = subCategoryWebApiDataContract.Description;
                subCategoryDataContract.IsActive = subCategoryWebApiDataContract.IsActive;

                var result = fileMetadata.AddUpdateSubCategoryAsync(subCategoryDataContract).Result;
                if (result < 0)
                {
                    //this._logger.Info("Record has not been added into category");
                    return this.BadRequest();
                }

                Audit("Sub Category Id: ", subCategoryDataContract.Id, fileMetadata, result, subCategoryDataContract.IsActive);

                //this._logger.Info("Record has been added into Category");
                return this.Ok(result);

            }
            catch (Exception ex)
            {
                //this._logger.Error(ex.Message);
                return this.StatusCode(HttpStatusCode.InternalServerError);
            }
        }

        public int Audit( string id,int updateID, IFileMetadata fileMetadata,int insertedID, bool isActive=true)
        {
            int auditResult;
            AuditDataContract auditDataContract = new AuditDataContract();
            //this._logger.Info("Calling the Audit method");

            try
            {               
                auditDataContract.UserId = "UserId1";
                auditDataContract.PlanId = "";
                auditDataContract.FileMetadataId = 0;
                auditDataContract.CreatedOn = DateTime.Now;
                
                if (updateID > 0)
                {            
                    if (isActive)
                    {
                        auditDataContract.Description = id + updateID + " has been updated.";
                        auditDataContract.OperationId = (id == "Category Id: ") ? Convert.ToInt16(CategoryOperationName.CategoryUpdated) : Convert.ToInt16(SubCategoryOperationName.SubCategoryUpdated);
                    }
                    else
                    {
                        auditDataContract.Description = id + updateID + " has been deleted.";
                        auditDataContract.OperationId = (id == "Category Id: ") ? Convert.ToInt16(CategoryOperationName.CategoryDeleted) : Convert.ToInt16(SubCategoryOperationName.SubCategoryDeleted);
                    } 
                    auditResult = fileMetadata.AddAuditInformationAsync(auditDataContract).Result;
                    if (auditResult <= 0)
                    {
                        //this._logger.Info("Record has not been updated into Audit");
                        return 0;
                    }
                    //this._logger.Info("Record has been updated into Audit");
                }
                else
                {                   
                    auditDataContract.Description = id + insertedID + " has been added.";
                    auditDataContract.OperationId = (id == "Category Id: ") ? Convert.ToInt16(CategoryOperationName.CategoryAdded) : Convert.ToInt16(SubCategoryOperationName.SubCategoryAdded);
                    auditResult = fileMetadata.AddAuditInformationAsync(auditDataContract).Result;                
                    if (auditResult <= 0)
                    {
                        //this._logger.Info("Record has not been added into Audit");
                        return 0;
                    }
                    //this._logger.Info("Record has been added into Audit");
                }

                return auditResult;
            }
            catch (Exception ex)
            {
                //this._logger.Error(ex.Message);
                return 0;
            }
        }

        public class SubCategoryWebApiDataContract
        {         
            /// <summary>
            /// Gets or sets the Name.
            /// </summary>
            /// <value>
            /// The SubCategory Name.
            /// </value>      
            public string Name { get; set; }            

            /// <summary>
            /// Gets or sets the Description.
            /// </summary>
            /// <value>
            /// The SubCategory Description.
            /// </value>       
            public string Description { get; set; }

            /// <summary>
            /// Gets or sets the IsActive.
            /// </summary>
            /// <value>
            /// The SubCategory IsActive.
            /// </value>      
            public bool IsActive { get; set; }

            /// <summary>
            /// Gets or sets the CreatedBy.
            /// </summary>
            /// <value>
            /// The Category CreatedBy.
            /// </value>        
            public string CreatedBy { get; set; }
        }

        /// <summary>
        /// The set get categories memory cache.
        /// </summary>
        /// <returns>
        /// The <see cref="Task"/>.
        /// </returns>
        //private Task<CategoryDataContract[]> SetGetCategoriesMemoryCache()
        //{           
        //    string key = "CategoriesMemoryKey-Cache";
        //    Task<CategoryDataContract[]> getCategories;

        //    if (this._memoryCache != null)
        //    {                
        //        if (!this._memoryCache.TryGetValue(key, out getCategories))
        //        {
        //            getCategories = this.FileMetadata.GetCategoriesAsync();
        //            this._memoryCache.Set(key, getCategories, new MemoryCacheEntryOptions().SetAbsoluteExpiration(TimeSpan.FromMinutes(1)));
        //            this._logger.LogInformation("Categories and SubCategories records have been added in Cache");
        //        }
        //        else
        //        {
        //            getCategories = this._memoryCache.Get(key) as Task<CategoryDataContract[]>;
        //            this._logger.LogInformation("Categories and SubCategories records have been retrieved from in Cache");
        //        }
        //    }
        //    else
        //    {
        //        getCategories = this.FileMetadata.GetCategoriesAsync();
        //    }
        //    return getCategories;
        //}
    }
}
