namespace Schwab.Rps.DocPub.Api.Controllers
{
    public partial class Enums
    {
        public enum Status
        {
            Undefined = 0,
            Uploaded = 1,
            UploadFailed = 2,
            NeedsReview = 3,
            ReadyToPublish = 4,
            Deleted = 5,
            FailedReview = 6,
            Published = 7,
            Archived = 8
        }

        public enum FileType
        {
            undefined = 0,
            txt = 1,
            pdf = 2,
            xlsx = 3,
            xls = 4,
            docx = 5,
            doc = 6,
            csv = 7,
            ppt = 8,
            pptx = 9,
            rtf = 10,
            tif = 11,
            zip = 12,
            tiff = 13
        }

        /// <summary>
        /// The Operation Name.
        /// </summary>
        public enum OperationName
        {
            /// <summary>
            /// Added
            /// </summary>
            DocumentUploaded = 100,

            /// <summary>
            /// Updated
            /// </summary>
            DocumentUpdated = 101,

            /// <summary>
            /// Deleted
            /// </summary>
            DocumentDeleted = 102
        }
    }
}