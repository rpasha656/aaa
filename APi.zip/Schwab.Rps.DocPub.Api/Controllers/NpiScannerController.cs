﻿
namespace Schwab.Rps.DocPub.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Web.Http;
    using Newtonsoft.Json;
    using Microsoft.Practices.ServiceLocation;
    using Microsoft.Practices.Unity;
    using System.Net.Http;
    using System.Net;
    using NpiServiceReference;

    [RoutePrefix("api/NpiScanner")]
    public class NpiScannerController : ApiController
    {
        /// <summary>
        /// The logger
        /// </summary>
        //private readonly ILogger _logger;

        /// <summary>
        /// The memory cache.
        /// </summary>
        //private readonly IMemoryCache _memoryCache;

        /// <summary>
        /// Initializes a new instance of the <see cref="NpiScannerController"/> class.
        /// </summary>
        /// <param name="npiScanner">The Npi Scanner.</param>
        /// <param name="logger">The logger.</param>
        /// <param name="memCache">The mem Cache.</param>
        //public NpiScannerController(INpiScanner npiScanner, ILogger<NpiScannerController> logger, IMemoryCache memCache)
        //{
        //    this.NpiScanner = npiScanner;
        //    this._logger = logger;
        //    this._memoryCache = memCache;
        //}


        /// <summary>
        /// Gets or sets the NpiScanner data.
        /// </summary>
        /// <value>
        /// The NpiScanner.
        /// </value>
        public INpiScanner NpiScanner { get; set; }

        /// <summary>
        /// Gets Npi Scan results
        /// </summary>
        /// <param name="npiScannerInputDataContract">The identifier.</param>
        /// <returns>Npi Scan results</returns>
        [Route("Scanitems")]
        public IHttpActionResult GetScanitems(string fileName, string planName, string sposUri)
        {
            try
            {
                npiScannerInputDataContract npiScannerInput = new npiScannerInputDataContract();
                npiScannerInput.FileName = fileName;
                npiScannerInput.PlanName = planName;
                npiScannerInput.SposUri = sposUri;
                INpiScanner npiScanner = new NpiScannerClient();
                var npiScannerFileMatches = npiScanner.GetNpiScannerAsync(npiScannerInput);
                var scanList = npiScannerFileMatches.Result;

                if (!scanList.Any())
                {
                    return this.BadRequest();
                }

                return this.Ok(scanList);
            }
            catch (Exception ex)
            {

                return this.StatusCode(HttpStatusCode.InternalServerError);
            }
        }

        [HttpPost]
        [Route("NpiScanMatch")]
        public IHttpActionResult PostNpiScanMatch([FromBody] npiScannerMatchInputDataContract npiMatchDataContracts)
        {
            try
            {
                INpiScanner npiScanner = new NpiScannerClient();
                var npiScannerFileMatcheList = npiScanner.GetNpiScannerMatchAsync(npiMatchDataContracts);
                var scanMatchList = npiScannerFileMatcheList.Result;

                if (scanMatchList == null)
                {
                    return this.BadRequest();
                }

                return this.Ok(scanMatchList);
            }
            catch (Exception ex)
            {

                return this.StatusCode(HttpStatusCode.InternalServerError);
            }
        }

    }
}
