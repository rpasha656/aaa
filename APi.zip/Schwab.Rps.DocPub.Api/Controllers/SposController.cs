﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Net;
//using System.Net.Http;
//using System.Web.Http;
//using Schwab.Rps.DocPub.Api.Spos;

//namespace Schwab.Rps.DocPub.Api.Controllers
//{
//    public class SposController : ApiController
//    {
//        private readonly SposHelper _sposHelper = new SposHelper();

//        // GET: api/Spos/5
//        public byte[] Get(string id)
//        {
//            return this._sposHelper.ReadDocumentFromSpos(id).Result;
//        }
//    }
//}
