﻿
using System.Configuration;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using AutoMapper;
//using Schwab.Rps.DocPub.Api.Spos;

namespace Schwab.Rps.DocPub.Api.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using DocPubServiceReference;
    using System.Web.Http;
    using Newtonsoft.Json;
    using Microsoft.Practices.ServiceLocation;
    using Microsoft.Practices.Unity;
    using System.Net.Http;
    using System.Net;

    /// <summary>
    /// FileMetadata controller
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.Controller" />
    [RoutePrefix("api/files")]
    public class FilesController : ApiController
    {
        /// <summary>
        /// The logger
        /// </summary>
        //private readonly ILogger _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="FilesController"/> class.
        /// </summary>
        /// <param name="fileMetadata">The file metadata.</param>
        /// <param name="logger">The logger.</param>
        //public FilesController(IFileMetadata fileMetadata, ILogger<FilesController> logger)
        //    this._logger = logger;
        //}
               
        //private readonly SposHelper _sposHelper = new SposHelper();
        private readonly AuditDataContract _auditDataContract = new AuditDataContract();



        /// <summary>
        /// Gets or sets the add file metadata.
        /// </summary>
        /// <value>
        /// The add file metadata.
        /// </value>
        public IFileMetadata FileMetadata { get; set; }

        /// <summary>
        /// Posts the specified file metadata data contract.
        /// </summary>
        /// <param name="fileMetadata">The file metadata data contract.</param>
        /// <returns>FileMeta Id</returns>
        [HttpPost]
        [Route("")]
        public IHttpActionResult Post([FromBody] FileMetadata fileMetadata)
        {
            IFileMetadata fileMetadataClient = new FileMetadataClient();
            //this._logger.Info("Calling the FileMetadata method");

            if (fileMetadata == null)
            {
                //this._logger.Error("Empty FileMetaDataContract object");
                return this.BadRequest();
            }

            try
            {
                string fileName = fileMetadata.FileName;
                string fileNameWithoutExtension = fileName.Substring(0, fileName.LastIndexOf('.'));
                string fileExtension = fileName.Substring(fileName.LastIndexOf('.') + 1, fileName.Length - (fileName.LastIndexOf('.') + 1));

                string docName = $"{fileMetadata.PlanName}_{fileNameWithoutExtension}_{DateTime.Now:yyyyMMddHHmmss}.{fileExtension}";
                Stream stream = new MemoryStream(fileMetadata.FileStream);

                //fileMetadata.SposUrl = GetSposUrl(docName);
                fileMetadata.SposId = docName;

                Enums.FileType fileExtensionId;
                Enum.TryParse(fileExtension, out fileExtensionId);

                fileMetadata.FileExtensionId = Enum.IsDefined(typeof(Enums.FileType), fileExtensionId) ? (int) fileExtensionId : 0;
                fileMetadata.StatusId = Convert.ToInt16(Enums.Status.Uploaded);

                //  Mapper.Initialize(cfg => cfg.CreateMap<FileMetadata, FileMetadataDataContract>());
                var config = new MapperConfiguration(cfg => cfg.CreateMap<FileMetadata, FileMetadataDataContract>());
                var mapper = config.CreateMapper();
                FileMetadataDataContract fileMetadataDataContract = mapper.Map<FileMetadataDataContract>(fileMetadata);

                int result = fileMetadataClient.AddFileMetadataAsync(fileMetadataDataContract).Result;
                if (result <= 0)
                {
                    //this._logger.Info("Record has not been added into FileMetadata");
                    return this.BadRequest();
                }

                this.Audit(this._auditDataContract, fileMetadataDataContract, result);

                //this.WriteDocumentToSpos(docName, stream, fileMetadataClient, fileMetadataDataContract);

                //this._logger.Info("Record has been added into FileMetadata");
                return this.Ok(result);
            }
            catch (Exception ex)
            {
                //this._logger.Error(ex.Message);
                return this.StatusCode(HttpStatusCode.InternalServerError);
            }
        }

        //private static string GetSposUrl(string docName)
        //{
        //    return $"{ConfigurationManager.AppSettings["SPOS.BaseAddress"]}{ConfigurationManager.AppSettings["SPOS.Bucket"]}/{docName}";
        //}

        //private void WriteDocumentToSpos(string docName, Stream stream, IFileMetadata fileMetadata, FileMetadataDataContract fileMetadataDataContract)
        //{
        //    var result = this._sposHelper.WriteDocumentToSpos(docName, stream).Result;

        //    // if SPOS file upload failed
        //    if (result == false)
        //    {
        //        fileMetadataDataContract.StatusId = (int) Enums.Status.UploadFailed;
        //        var fileMetadataId = fileMetadata.AddFileMetadataAsync(fileMetadataDataContract).Result;
               
        //        this.Audit(this._auditDataContract, fileMetadataDataContract, fileMetadataId);

        //    }
        //}

        /// <summary>
        /// Gets the FileMetadata by Status and no.of expiry days
        /// </summary>
        /// <param name="status">The status.</param>
        /// <param name="days">The expiry days.</param>
        /// <returns>File Metadata Json Object</returns>         
        [Route("{status}/{days}")]
        public IHttpActionResult Get(int status, int days)
        {
            try
            {
                //this._logger.Info("Calling the FileMetadata method to get all FileMetadata info filtered by status and no. of days");

                IFileMetadata fileMetadata = new FileMetadataClient();
                var getFileMetadataInfo = fileMetadata.GetFileMetadataByFiltersAsync(status, days);
                var fileMetadataInfo = getFileMetadataInfo.Result;

                var fileMetadatalists = from fileMeta in fileMetadataInfo
                                        group fileMeta by fileMeta.PlanName into planGroup
                                        orderby planGroup.Key
                                        select planGroup;

                var planList = new List<FileMetadataByPlan>();

                foreach (var fileMeta in fileMetadatalists)
                {
                    var plan = new FileMetadataByPlan();

                    foreach (var fileMetaItem in fileMeta)
                    {
                        plan.PlanName = fileMetaItem.PlanName;

                        var fileMetas = from file in fileMetadataInfo
                                        where file.PlanName == fileMetaItem.PlanName
                                        select file;
                        plan.FileMetadatalist.AddRange(GetFileMetadataInfo(fileMetas));
                        break;
                    }
                    planList.Add(plan);
                }

                var fileMetadataByPlan = new FileMetadataByStatusAndExpiry() { FileMetadataByPlan = planList };

                if (fileMetadataByPlan.FileMetadataByPlan.Count <= 0)
                {
                    return this.BadRequest();
                }

                //this._logger.Info("FileMetadata records have been fetched");
                return this.Ok(fileMetadataByPlan);
            }
            catch (Exception ex)
            {
                //this._logger.Error(ex.Message);
                return StatusCode(HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Gets the FileMetadata by Status and no.of expiry days
        /// </summary>
        /// <param name="status">The status.</param>
        /// <param name="days">The expiry days.</param>
        /// <returns>File Metadata Json Object</returns>         
        [Route("{fileMetadataId}")]
        public IHttpActionResult Get(int fileMetadataId)
        {
            try
            {
                //this._logger.Info("Calling the FileMetadata method to get all FileMetadata info filtered by status and no. of days");

                IFileMetadata fileMetadata = new FileMetadataClient();
                var getFileMetadataInfo = fileMetadata.GetFileMetadataByFileMetadataIdAsync(fileMetadataId);

                var fileMetadataInfo = getFileMetadataInfo.Result;
                if (fileMetadataInfo == null)
                {
                    return this.BadRequest();
                }

                //this._logger.Info("FileMetadata records have been fetched");
                return this.Ok(fileMetadataInfo);
            }
            catch (Exception ex)
            {
                //this._logger.Error(ex.Message);
                return StatusCode(HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// Gets the file metadata information.
        /// </summary>
        /// <param name="fileMetadatalist">The filemetadata list.</param>
        /// <returns>File Metadata List</returns>
        public List<FileMetadataList> GetFileMetadataInfo(IEnumerable<FileMetadataDataContract> fileMetadatalist)
        {
            var fileMetadataRecords = new List<FileMetadataList>();

            foreach (var fileMetadata in fileMetadatalist)
            {
                var file = new FileMetadataList()
                {
                    Id = fileMetadata.Id,
                    AccessedOn = fileMetadata.AccessedOn.ToString("MM/dd/yyyy"),
                    ExpirationDate = fileMetadata.ExpirationDate.ToString("MM/dd/yyyy"),
                    FileExtensionId = fileMetadata.FileExtensionId,
                    FileName = fileMetadata.FileName,
                    DisplayName = fileMetadata.DisplayName,
                    PlanName = fileMetadata.PlanName,
                    StatusDate = fileMetadata.StatusDate.ToString("MM/dd/yyyy"),
                    SposUrl = fileMetadata.SposUrl,
                    StatusId = fileMetadata.StatusId,
                    StatusName = fileMetadata.StatusName
                };

                fileMetadataRecords.Add(file);
            }

            return fileMetadataRecords;
        }


        /// <summary>
        /// File Metadata By status and expiry days
        /// </summary>
        public class FileMetadataByStatusAndExpiry
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="FileMetadataByStatusAndExpiry"/> class.
            /// </summary>
            public FileMetadataByStatusAndExpiry()
            {
                this.FileMetadataByPlan = new List<FileMetadataByPlan>();
            }

            /// <summary>
            /// Gets or sets the FileMetadataByPlan.
            /// </summary>
            /// <value>
            /// The FileMetadatalist.
            /// </value>
            public List<FileMetadataByPlan> FileMetadataByPlan { get; set; }
        }

        /// <summary>
        /// File MetadataList Class
        /// </summary>
        public class FileMetadataByPlan
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="FileMetadataByPlan"/> class.
            /// </summary>
            public FileMetadataByPlan()
            {
                this.FileMetadatalist = new List<FileMetadataList>();
            }

            /// <summary>
            /// Gets or sets the name of the plan.
            /// </summary>
            /// <value>
            /// The name of the plan.
            /// </value>
            public string PlanName { get; set; }

            /// <summary>
            /// Gets or sets the FileMetadataList.
            /// </summary>
            /// <value>
            /// The FileMetadatalist.
            /// </value>
            public List<FileMetadataList> FileMetadatalist { get; set; }
        }

        /// <summary>
        /// File MetadataList Class
        /// </summary>
        public class FileMetadataList
        {
            /// <summary>
            /// Gets or sets the accessed on.
            /// </summary>
            /// <value>
            /// The accessed on.
            /// </value>
            public string AccessedOn { get; set; }

            /// <summary>
            /// Gets or sets the expiration date.
            /// </summary>
            /// <value>
            /// The expiration date.
            /// </value>
            public string ExpirationDate { get; set; }

            /// <summary>
            /// Gets or sets the file extension identifier.
            /// </summary>
            /// <value>
            /// The file extension identifier.
            /// </value>
            public int FileExtensionId { get; set; }

            /// <summary>
            /// Gets or sets the name of the file.
            /// </summary>
            /// <value>
            /// The name of the file.
            /// </value>
            public string FileName { get; set; }

            /// <summary>
            /// Gets or sets the Display name.
            /// </summary>
            /// <value>
            /// The status name.
            /// </value>
            public string DisplayName { get; set; }

            /// <summary>
            /// Gets or sets the name of the plan.
            /// </summary>
            /// <value>
            /// The name of the plan.
            /// </value>
            public string PlanName { get; set; }

            /// <summary>
            /// Gets or sets the publication date.
            /// </summary>
            /// <value>
            /// The publication date.
            /// </value>
            public string StatusDate { get; set; }

            /// <summary>
            /// Gets or sets the spos identifier.
            /// </summary>
            /// <value>
            /// The SPOS identifier.
            /// </value>
            public int SposId { get; set; }

            /// Gets or sets the spos url.
            /// </summary>
            /// <value>
            /// The SPOS url.
            /// </value>
            public string SposUrl { get; set; }

            /// <summary>
            /// Gets or sets the status identifier.
            /// </summary>
            /// <value>
            /// The status identifier.
            /// </value>
            public int StatusId { get; set; }

            /// <summary>
            /// Gets or sets the status name.
            /// </summary>
            /// <value>
            /// The status name.
            /// </value>
            public string StatusName { get; set; }

            /// <summary>
            /// Gets or sets the identifier.
            /// </summary>
            /// <value>
            /// The identifier.
            /// </value>           
            public int Id { get; set; }

        }

        /// <summary>
        /// Audit Method
        /// </summary>
        public int Audit(AuditDataContract auditDataContract, FileMetadataDataContract fileMetadata, int fileMetadataId)
        {
            int auditResult;
            //this._logger.Info("Calling the Audit method");

            try
            {
                auditDataContract.PlanId = fileMetadata.PlanName;
                auditDataContract.UserId = "UserId1";
                if (fileMetadata.Id > 0)
                {
                    auditDataContract.FileMetadataId = fileMetadata.Id;
                    auditDataContract.Description = "File Metadata Id:" + fileMetadata.Id + " document has been updated.";
                    auditDataContract.OperationId = Convert.ToInt16(Enums.OperationName.DocumentUpdated);
                    auditResult = this.FileMetadata.AddAuditInformationAsync(auditDataContract).Result;
                    if (auditResult <= 0)
                    {
                        //this._logger.Info("Record has not been updated into Audit");
                        return 0;
                    }
                    //this._logger.Info("Record has been updated into Audit");
                }
                else
                {
                    auditDataContract.FileMetadataId = fileMetadataId;
                    auditDataContract.Description = "File Metadata Id:" + fileMetadataId + " document has been added.";
                    auditDataContract.OperationId = Convert.ToInt16(Enums.OperationName.DocumentUploaded);
                    auditResult = this.FileMetadata.AddAuditInformationAsync(auditDataContract).Result;
                    if (auditResult <= 0)
                    {
                        //this._logger.Info("Record has not been added into Audit");
                        return 0;
                    }
                    //this._logger.Info("Record has been added into Audit");
                }

                return auditResult;
            }
            catch (Exception ex)
            {
                //this._logger.Error(ex.Message);
                return 0;
            }
        }
    }
}