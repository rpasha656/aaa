﻿CREATE TABLE [dbo].[FileAccessHistory]
(
	[UserId] VARCHAR(100) NOT NULL, 
    [FileMetadataId] INT NOT NULL, 
    [AccessedOn] DATE NOT NULL 
	CONSTRAINT [FK_FileMetadata_Id] FOREIGN KEY ([FileMetadataId]) REFERENCES [dbo].[FileMetadata] ([Id])
)
