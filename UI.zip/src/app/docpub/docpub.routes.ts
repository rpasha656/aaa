import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DocpubComponent, UploadComponent, CategoryEdit, ReviewerComponent } from './index';
const DocpubRoutes: Routes = [
  { path: '', component: DocpubComponent },
  { path: ':planname', component: DocpubComponent },
  { path: 'upload', component: UploadComponent },
  { path: 'upload/:planname', component: UploadComponent },
  { path: 'upload/:planname/:id', component: UploadComponent },
  { path: 'categoryedit/:planname', component: CategoryEdit },
  { path: 'reviewer/:planname', component: ReviewerComponent }
];

@NgModule({
  declarations: [
  ],
  imports: [RouterModule.forChild(DocpubRoutes)],
  exports: [RouterModule],
  providers: []
})
export class DocpubRoutingModule { }
