import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { ReactiveFormsModule } from '@angular/forms';
import {
    DocpubComponent, UploadComponent, FileListingComponent, FileMetadataService, TableSortable,
    PdfViewerComponent, OrderBy, SearchPipe, Safe, DocpubRoutingModule, CategoryEdit, ReviewerComponent
} from './index';
@NgModule({
    declarations: [
        DocpubComponent,
        UploadComponent,
        FileListingComponent,
        TableSortable,
        OrderBy,
        SearchPipe,
        PdfViewerComponent,
        CategoryEdit,
        ReviewerComponent,
        Safe
    ],
    imports: [
        FormsModule,
        CommonModule,
        HttpModule,
        ReactiveFormsModule,
        DocpubRoutingModule

    ],
    providers: [FileMetadataService],
    exports: [
        DocpubComponent,
        UploadComponent,
        FileListingComponent,
        DocpubRoutingModule,
        CategoryEdit,
        ReviewerComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DocpubModule {
}
