import { Component } from '@angular/core';
import { FileMetadataService, FileMetadataByPlans, FileMetadataModel } from './index';
@Component({
    selector: 'as-reviewer',
    template: require('./reviewer.component.html')
})
export class ReviewerComponent {
    public fileMetadataByPlans: FileMetadataByPlans[];
    public fileMetadatalist: FileMetadataModel[];
    public sorting: any;
    public columns: any[];
    public showNoRowsMessage: boolean;
    public showfilelisting: Boolean;
    constructor(private filemetadataService: FileMetadataService) {
        this.fileMetadataByPlans = [new FileMetadataByPlans(this.fileMetadatalist)];
        this.getFileMetadataByFilter(2, 0);
        this.columns = [
            {
                display: 'Document', // The text to display
                variable: 'displayName', // The name of the key that's apart of the data array                
                typehref: true,
                htmltext: '',
                width: '22%'

            },
            {
                display: 'Filename', // The text to display
                variable: 'fileName', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: '',
                width: '20%'
            },
            {
                display: 'Size (MB)', // The text to display
                variable: 'FileSize', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: '',
                width: '5%'
            },
            {
                display: 'Status', // The text to display
                variable: 'statusName', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: '',
                width: '8%'
            },
            {
                display: 'Status Date', // The text to display
                variable: 'statusDate', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: '',
                width: '9%'
            },
            {
                display: 'Downloaded', // The text to display
                variable: 'LastDownLoaded', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: '',
                width: '10%'
            },
            {
                display: 'Expires', // The text to display
                variable: 'expirationDate', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: '',
                width: '8%'
            },
            {
                display: 'Published By', // The text to display
                variable: 'UserId', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: '',
                width: '11%'
            },
            {
                display: '', // The text to display
                variable: '', // The name of the key that's apart of the data array
                typehref: false,
                htmltext: `Test`,
                width: '8%'
            }
        ];
        this.sorting = {
            column: 'fileName', // to match the variable of one of the columns
            descending: false
        };
    }
    onChange(reviewtype: string) {
        if (reviewtype === 'Deleted') {
            this.getFileMetadataByFilter(4, 14);
        }
        else if (reviewtype === 'Expires in 60 days') {
            this.getFileMetadataByFilter(2, 60);
        }
        else {
            this.getFileMetadataByFilter(2, 0);
        }
    }
    getFileMetadataByFilter(status: number, numberofdays: number) {
        this.filemetadataService.getFileMetadataByFilters(status, numberofdays)
            .subscribe(res => this.populateFileListing(res.fileMetadataByPlan, true),
            err => this.populateFileListing(err, false));
    }
    populateFileListing(fileListingData: any, isSuccess: boolean) {
        this.fileMetadataByPlans = [];
        this.fileMetadataByPlans = fileListingData;
        this.showfilelisting = isSuccess ? true : false;
        this.showNoRowsMessage = !this.showfilelisting;
    };
}
