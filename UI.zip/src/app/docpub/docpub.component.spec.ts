import {
    TestBed, inject
} from '@angular/core/testing';
import { Component } from '@angular/core';
import { DocpubModule } from './index';
import { UploadComponent } from './upload.component';
import { FileMetadataService } from './services/filemetadata.service';
@Component({
    selector: 'as-test',
    template: '<as-docpub></as-docpub>'
})
class TestComponent {
}

describe('UploadComponent', () => {
    beforeEach(() => {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 300000;
        TestBed.configureTestingModule({
            declarations: [TestComponent],
            imports: [DocpubModule],
            providers: [FileMetadataService, UploadComponent
            ]
        });
    });
    it('Testing getCategories',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.getCategories());
        }));
    it('Testing  getFileMetadatalisting',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.getFileMetadatalisting('HUM'));
        }));
    it('Testing  addFileMetaData',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.addFileMetaData());
        }));
    it('Testing  delete from reviewer sceen',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.addFileMetaData('onSubmit(form,4)'));
        }));
    it('Testing  addFileMetaData',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.addFileMetaData());
        }));
    it('Testing  addCategory',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.addCategory());
        }));
    it('Testing  updateCategory',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.updateCategory());
        }));
    it('Testing  addSubCategory',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.addSubCategory());
        }));
    it('Testing  updateSubCategory',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.updateSubCategory());
        }));
    it('Testing  getFileMetadataByFilters',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.getFileMetadataByFilters());
        }));

});
