﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class FileMetadataService {
    // Resolve HTTP using the constructor
    constructor(private http: Http) { }
    // private instance variable to hold base url   
    // Fetch all existing comments
    addFileMetaData(filemetadata: Object) {
        let filemetadataString = JSON.stringify(filemetadata); // Stringify payload
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON        
        let options = new RequestOptions({ headers: headers }); // Create a request option
        return this.http.post('https://localhost:44344//api/files', filemetadataString, options) // ...using post request
            .map((res: Response) => res.json()); // ...and calling .json() on the response to return data            
    }
    getCategories() {
        // let filemetadataString = JSON.stringify(filemetadata); // Stringify payload
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option

        return this.http.get('https://localhost:44344/api/Categories', options) // ...using post request
            .map((res: Response) => res.json()); // ...and calling .json() on the response to return data
    }
    getFileMetadatalisting(id: string) {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers }); // Create a request option        
        return this.http.get('https://localhost:44344/api/plans/planbyid?id=' + id, options) // ...using post request
            .map((res: Response) => res.json());
    }
    getFileMetadataById(id: number) {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers }); // Create a request option        
        return this.http.get('https://localhost:44344/api/files/' + id, options) // ...using post request
            .map((res: Response) => res.json());
    }
    getFileMetadataByFilters(id: number, numberofdays: number) {
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers }); // Create a request option        
        return this.http.get('https://localhost:44344/api/files/' + id + '/' + numberofdays, options) // ...using post request
            .map((res: Response) => res.json());
    }
    addCategory(category: any) {
        // let filemetadataString = JSON.stringify(filemetadata); // Stringify payload
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option

        return this.http.post('https://localhost:44344/api/Categories', category, options) // ...using post request
            .map((res: Response) => res.json()); // ...and calling .json() on the response to return data
    }
    updateCategory(category: any) {
        // let filemetadataString = JSON.stringify(filemetadata); // Stringify payload
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option

        return this.http.post('https://localhost:44344/api/Categories', category, options) // ...using post request
            .map((res: Response) => res.json()); // ...and calling .json() on the response to return data
    }
    addSubCategory(categoryId: number, subcategory: any) {
        // let filemetadataString = JSON.stringify(filemetadata); // Stringify payload
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option

        return this.http.post('https://localhost:44344/api/Categories/' + categoryId + '/subcategories', subcategory, options)
            // ...using post request
            .map((res: Response) => res.json()); // ...and calling .json() on the response to return data
    }
    updateSubCategory(categoryId: number, subcategoryId: number, subcategory: any) {
        // let filemetadataString = JSON.stringify(filemetadata); // Stringify payload
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option

        return this.http.post
            ('https://localhost:44391/api/Categories/' + categoryId + '/subcategories/' + subcategoryId, subcategory, options)
            // ...using post request
            .map((res: Response) => res.json()); // ...and calling .json() on the response to return data
    }
}
