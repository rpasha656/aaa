import { Pipe } from '@angular/core';

@Pipe({ name: 'asSearch' })
export class SearchPipe {
    transform(value: any, args: string): any {
        let filter = args.toLocaleLowerCase();
        if (filter && Array.isArray(value)) {
            return value.filter(item => {
                for (let field in item) {
                    if (item[field].toString().toLocaleLowerCase().indexOf(filter) !== -1) {
                        return true;
                    }
                }
                return false;
            });
        } else {
            return value;
        }
    }
}
