import { Component, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';
@Component({
    selector: 'as-tablesortable',
    template: require('./tableSortable.html')
})
export class TableSortable {

    @Input() columns: any[];
    @Input() data: any[];
    @Input() sort: any;
    public response: Response;
    public selectedPlan: string;
    constructor(private route: ActivatedRoute) {
        this.route.params.subscribe((params: { planname: string }) => this.selectedPlan = params.planname);
    }
    selectedClass(columnName: string) {
        return columnName === this.sort.column ? 'sort-' + this.sort.descending : false;
    }

    changeSorting(columnName: void) {
        let sort = this.sort;
        if (sort.column === columnName) {
            sort.descending = !sort.descending;
        } else {
            sort.column = columnName;
            sort.descending = false;
        }
    }

    convertSorting(): string {
        return this.sort.descending ? '-' + this.sort.column : this.sort.column;
    }
    downloadFile(sposid: string) {
        console.log(sposid);
    }
}
