import { Component, Inject } from '@angular/core';
import { Title, PubSubServiceContract } from 'microui-contracts';
import { ActivatedRoute } from '@angular/router';
import { FileMetadataService } from './index';
@Component({
    moduleId: module.id,
    selector: 'as-docpub',
    template: require('./docpub.component.html')
})
export class DocpubComponent {
    public selectedPlanName: string;
    public showNoRowsMessage: Boolean;
    public showfilelisting: Boolean;
    public fileMetadataListing: any;
    constructor(private pubsub: PubSubServiceContract, @Inject(Title) public title: string,
        private filemetadataService: FileMetadataService, private route: ActivatedRoute) {
        this.route.params.subscribe((params: { planname: string }) => this.selectedPlanName = params.planname);
        if (this.selectedPlanName === undefined || this.selectedPlanName === 'undefined') {
            this.selectedPlanName = 'Select';
        }
        else {
            this.getFileMetadatalisting(this.selectedPlanName);
        }
    }
    getFileMetadatalisting(planname: string) {
        this.showNoRowsMessage = false;
        this.filemetadataService.getFileMetadatalisting(planname).subscribe(res => this.populateFileListing(res.categories, true),
            err => this.populateFileListing(err, false));
    };
    populateFileListing(fileListingData: any, isSuccess: boolean) {
        this.fileMetadataListing = fileListingData;
        this.showfilelisting = isSuccess ? true : false;
        this.showNoRowsMessage = !this.showfilelisting;
        console.log(this.showNoRowsMessage);
    };
}
