import { Component } from '@angular/core';
declare var $: any;
import { ActivatedRoute } from '@angular/router';
import { FileMetadataService, FileMetadataListing, SubCategories } from './index';
@Component({
    selector: 'as-edit-category',
    template: require('./category-edit.component.html')
})
export class CategoryEdit {
    public tableData: FileMetadataListing[];
    public Category = '';
    public oldText = '';
    public oldSubcategory = '';
    public subCategories: SubCategories[];
    public singleSubCategories: SubCategories;
    public subJsonData: Object[];
    public category: FileMetadataListing[];
    public singleCategory: FileMetadataListing;
    public selectedCategory: FileMetadataListing;
    public selectedPlanName: string;
    public categoryToDelete: FileMetadataListing;
    public subCategoryToDelete: SubCategories;
    public operation: string;
    constructor(private filemetadataService: FileMetadataService, private route: ActivatedRoute) {
        this.selectedCategory = new FileMetadataListing(this.subCategories);
        this.singleCategory = new FileMetadataListing(this.subCategories);
        this.singleSubCategories = new SubCategories([]);
        this.route.params.subscribe((params: { planname: string }) => this.selectedPlanName = params.planname);
        this.getCategories();
        this.categoryToDelete = new FileMetadataListing(this.subCategories);
        this.subCategoryToDelete = new SubCategories([]);
        this.operation = '';
    }
    loadCategory(data: any) {
        this.tableData = [new FileMetadataListing(this.subCategories)];
        this.tableData = data;
        this.selectedCategory = this.tableData[0];
        this.subCategories = this.selectedCategory.subCategories;
    }
    addCategory() {
        this.singleCategory = new FileMetadataListing([]);
        let obj = this.singleCategory;
        obj.name = this.Category;
        this.tableData.push(obj);
        this.Category = '';
        this.selectedCategory = this.tableData[this.tableData.length - 1];
        this.subCategories = this.selectedCategory.subCategories;
        this.addCategoryToService(this.selectedCategory);
    }
    addSubCategory(row, id) {
        if (this.selectedCategory.hasOwnProperty('name')) {
            let eleId: string = 'addSubcategory';
            let inputValue = (<HTMLInputElement>document.getElementById(eleId)).value;
            if (inputValue.length > 0) {
                this.singleSubCategories = new SubCategories([]);
                let obj = this.singleSubCategories;
                obj.name = inputValue;
                let index = this.tableData.indexOf(this.selectedCategory);
                let keyName = 'subCategories';
                this.tableData[index][keyName].push(obj);
                (<HTMLInputElement>document.getElementById(eleId)).value = '';
                this.addSubCategoryToService(this.selectedCategory.id, obj);
            }
        } else {
            let eleId: string = 'addSubcategory';
            (<HTMLInputElement>document.getElementById(eleId)).value = '';
        }

    }

    deleteCategory(category, operation) {
        if (operation === 'deleteCategory') {
            this.categoryToDelete = category;
        }
        else {
            this.subCategoryToDelete = category;
        }
        this.operation = operation;
        $('#deleteCategoryModal').modal();
    }
    deleteSubCategory(subCategory, operation) {
        if (operation === 'deleteSubCategory') {
            this.subCategoryToDelete = subCategory;
        }
        else {
            this.categoryToDelete = subCategory;
        }
        this.operation = operation;
        $('#deleteModal').modal();

    }
    confirmDeleteCategory() {
        let index = (this.tableData.indexOf(this.categoryToDelete));
        if (index > -1) {
            // this.tableData.splice(index, 1);
            this.subCategories = [];
            let obj = this.singleCategory;
            obj.id = this.categoryToDelete.id;
            obj.name = this.categoryToDelete.name;
            obj.isactive = false;
            this.updateCategoryToService(obj, this.operation);
        }
    }
    confirmDeleteSubcategory() {
        let index = this.subCategories.indexOf(this.subCategoryToDelete);
        if (index > -1) {
            // this.subCategories.splice(index, 1);
            let obj = this.singleSubCategories;
            obj.name = this.subCategoryToDelete.name;
            obj.id = this.subCategoryToDelete.id;
            obj.isactive = false;
            this.updateSubCategoryToService(this.selectedCategory.id, obj.id, obj, this.operation);
        }
    }

    enableSubCategory(row) {
        let index = this.tableData.indexOf(row);
        this.selectedCategory = this.tableData[index];
        this.subCategories = this.tableData[index].subCategories;
    }

    beginEdit(el: HTMLElement, index: string): void {
        this.oldText = this.tableData[index].name;
        this.tableData[index].editable = true;
    }
    beginsubCategoryEdit(el: Object, indexCat: string): void {
        let subcategory: any = this.subCategories;
        let index = (subcategory.indexOf(el));
        if (index > -1) {
            this.oldSubcategory = subcategory[index].name;
            subcategory[index].editable = true;
        }
    }
    editCategoryDone(newText, index: string): void {
        newText.editable = false;
        this.singleSubCategories = new SubCategories([]);
        let obj = this.singleSubCategories;
        obj.name = newText.name;
        obj.id = newText.id;
        this.updateCategoryToService(obj, this.operation);
    }
    editsubCategoryDone(row, indexCat: string): void {
        let subcategory: any = this.subCategories;
        let index = (subcategory.indexOf(row));
        if (index > -1) {
            subcategory[index].editable = false;
            this.singleSubCategories = new SubCategories([]);
            let obj = this.singleSubCategories;
            obj.name = subcategory[index].name;
            obj.id = subcategory[index].id;
            this.updateSubCategoryToService(this.selectedCategory.id, obj.id, obj, this.operation);
        }
    }
    editCategoryCancel(newText, index: string): void {
        console.log('edit cancel');
        newText.name = this.oldText;
        newText.editable = false;
        this.oldText = '';
    }
    editsubCategoryCancel(newText, indexCat: string): void {
        newText.name = this.oldSubcategory;
        newText.editable = false;
        this.oldSubcategory = '';
    }
    getCategories() {
        this.filemetadataService.getCategories().subscribe(res => this.loadCategory(res));
    }
    addCategoryToService(category: any) {
        this.filemetadataService.addCategory(category).subscribe(res => this.selectedCategory.id = res);
    }
    updateCategoryToService(category: any, operation: string) {
        this.filemetadataService.updateCategory(category).subscribe(res => {
            if (res !== 0 && operation === 'deleteCategory') {
                let index = (this.tableData.indexOf(this.categoryToDelete));
                if (index > -1) {
                    this.tableData.splice(index, 1);
                }
            }
        });
    }
    addSubCategoryToService(categoryId: number, subcategory: any) {
        this.filemetadataService.addSubCategory(categoryId, subcategory).subscribe(res => subcategory.id = res);
    }
    updateSubCategoryToService(categoryId: number, subcategoryId: number, subcategory: any, operation: string) {
        this.filemetadataService.updateSubCategory(categoryId, subcategoryId, subcategory).subscribe(res => {
            if (res !== 0 && operation === 'deleteSubCategory') {
                let index = this.subCategories.indexOf(this.subCategoryToDelete);
                if (index > -1) {
                    this.subCategories.splice(index, 1);
                }
            }
        });
    }
}
